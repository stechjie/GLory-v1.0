﻿extends "res://scenes/prep/PrepUI.gd"

func _maybe_start_pending_treasure() -> void:
	# 联机局：候选完全由服务端发放（match_state.pending_treasure / resume payload）。
	# 客户端既不能自己开抽奖，也不能在候选为空时本地补摇——这两条都是「自发宝物」，
	# 会绕开服务端的归属记录：真去选时 _rpc_treasure_choice 会以 not_offered 拒收，
	# 玩家看到的是一个点了没反应的界面。宁可不显示，也不显示一个假的。
	if NetworkService.team_active:
		return
	if bool(GameState.pending_treasure.get("active", false)):
		if GameState.pending_treasure.get("candidates", []).is_empty() and TreasureService.can_draw():
			GameState.pending_treasure.candidates = TreasureService.roll_candidates(3)
		return
	var completed_round := maxi(0, GameState.round_index - 1)
	if completed_round in GameState.claimed_treasure_rounds:
		return
	if RoundService.is_treasure_round(completed_round) and TreasureService.can_draw():
		GameState.pending_treasure = {
			"active": true,
			"round": completed_round,
			"candidates": TreasureService.roll_candidates(3),
			"refresh_index": 0,
		}

func _pick_treasure(tid: String) -> void:
	# 联机局：只发意图，等服务端授权后才真正入袋（与黄金祭坛 _on_golden_altar 同一模式）。
	# 本地不做乐观加入——宝物会立刻改变羁绊、经济和图鉴，抢跑后被服务端拒收就要回滚
	# 一串副作用，回滚比等一个 RTT 贵得多。
	if NetworkService.team_active:
		_connect_treasure_signals()
		NetworkService.request_treasure_choice(tid)
		return
	TreasureService.add_owned(tid)
	_claim_pending_treasure_round()
	GameState.pending_treasure.active = false
	SaveManager.save_run()
	_refresh_all()
	if GameState.tutorial_mode:
		TutorialMode.sync()

func _connect_treasure_signals() -> void:
	if not NetworkService.treasure_granted.is_connected(_on_treasure_granted):
		NetworkService.treasure_granted.connect(_on_treasure_granted)
	if not NetworkService.treasure_denied.is_connected(_on_treasure_denied):
		NetworkService.treasure_denied.connect(_on_treasure_denied)
	if not NetworkService.treasure_offer_changed.is_connected(_on_treasure_offer_changed):
		NetworkService.treasure_offer_changed.connect(_on_treasure_offer_changed)

# 服务端授权入袋。走 add_owned 而不是直接覆盖 owned_treasures：它还负责图鉴
# mark_seen 与联动解锁，绕过去会让玩家少解锁东西。
func _on_treasure_granted(tid: String, owned: Array) -> void:
	# 以服务端列表为准同步（helper 内部走 add_owned，保留图鉴/联动副作用）。
	# 不要只 add_owned(tid)：那样本地多出来的项永远裁不掉，两边会一直漂。
	var before := GameState.owned_treasures.size()
	TreasureService.sync_owned_from_server(owned)
	if before + 1 != GameState.owned_treasures.size():
		# 本地曾经存在一条没走 intent 的入袋路径（单机/教学代码漏进联机分支），
		# 或者上一次同步漏了。必须能从日志看出来，不能静默被 helper 抹平。
		push_warning("[NET] treasure owned resynced: local %d -> %d (server=%d, granted=%s)" % [
			before, GameState.owned_treasures.size(), owned.size(), tid])
	_claim_pending_treasure_round()
	GameState.pending_treasure.active = false
	SaveManager.save_run()
	_refresh_all()

func _on_treasure_denied(reason: String) -> void:
	# 不静默：拒收后界面必须回到一个玩家能理解的状态，否则就是「点了没反应」。
	show_message(tr("net_err_treasure_denied") % reason)
	_refresh_all()

func _on_treasure_offer_changed(candidates: Array, refresh_index: int) -> void:
	GameState.pending_treasure.candidates = candidates.duplicate()
	GameState.pending_treasure.refresh_index = refresh_index
	SaveManager.save_run()
	_refresh_all()

func _refresh_treasure_candidates() -> void:
	var cost := TreasureService.refresh_cost(int(GameState.pending_treasure.get("refresh_index", 0)), TreasureService.has_set("money"))
	if GameState.gold < cost:
		return
	GameState.gold -= cost
	# 联机局：钱仍在本地扣（金币还没有权威账本，见 A5/P1），但候选必须由服务端重摇——
	# 本地摇出来的东西不在服务端 offer 里，选的时候会被 not_offered 拒收。
	if NetworkService.team_active:
		_connect_treasure_signals()
		NetworkService.request_treasure_refresh()
		SaveManager.save_run()
		_refresh_all()
		return
	GameState.pending_treasure.refresh_index = int(GameState.pending_treasure.get("refresh_index", 0)) + 1
	GameState.pending_treasure.candidates = TreasureService.roll_candidates(3)
	SaveManager.save_run()
	_refresh_all()

func _claim_pending_treasure_round() -> void:
	var completed_round := int(GameState.pending_treasure.get("round", 0))
	if completed_round > 0 and completed_round not in GameState.claimed_treasure_rounds:
		GameState.claimed_treasure_rounds.append(completed_round)

func _on_start_battle() -> void:
	# 教学：当前步还不能开战时，给提示并直接返回——不要触发 _emit_battle_request_once，
	# 否则一次性发射锁 _battle_launch_emitted 会被烧掉，导致之后真到可开战步时按钮无反应。
	if GameState.tutorial_mode and not TutorialMode.can_start_battle():
		show_message(TutorialMode.follow_arrow_hint())
		return
	RaceRelationService.finalize_for_battle(GameState.board_slots, GameState.bench_slots)
	SaveManager.save_run()
	if NetworkService.team_active:
		# 3v3: the button is "准备" — toggle ready and stay in prep. The round
		# launches for everyone (team_round_start) once all players are ready.
		var my := NetworkService.team_local_slot
		var is_ready := my >= 0 and my < NetworkService.team_ready.size() and bool(NetworkService.team_ready[my])
		NetworkService.team_set_ready(not is_ready)
		_refresh_all()
		return
	_emit_battle_request_once()

func _emit_battle_request_once() -> void:
	if _battle_launch_emitted:
		return
	RaceRelationService.finalize_for_battle(GameState.board_slots, GameState.bench_slots)
	_battle_launch_emitted = true
	battle_requested.emit()

func _has_any_board_unit() -> bool:
	for cell in GameState.board_slots:
		if cell != null:
			return true
	for cell in GameState.mercenary_slots:
		if cell != null:
			return true
	return false

func _mark_online_board_changed() -> void:
	RaceRelationService.reconcile_board(GameState.board_slots, GameState.bench_slots, false, true)
	if NetworkService.team_active:
		# 3v3：改棋盘就取消准备，免得被锁在编辑到一半的状态。
		# 判断依据必须是 local_ready_intent()，不能直接读 team_ready（C24）——
		# 后者要等服务器广播回来才更新，"按下准备 → 回包到达前挪棋子"这段窗口里
		# 它还是 false，取消请求根本不会发出，而服务器已经按已准备锁盘了。
		if NetworkService.local_ready_intent():
			NetworkService.team_set_ready(false)

func _on_network_session_changed() -> void:
	_refresh_formation_status()
	_refresh_merc_panel()

func _on_golden_altar() -> void:
	if not GameState.owned_treasures.has("money_golden_altar"):
		return
	# 联机局：祭坛拿服务端权威的法阵 HP 换金币，本地扣 HP 会被下一份 match_state
	# 覆盖掉（代价蒸发、金币白拿）。所以只发意图，等服务端扣完 HP 授权后才加金币。
	if NetworkService.team_active:
		if not NetworkService.altar_result.is_connected(_on_altar_result):
			NetworkService.altar_result.connect(_on_altar_result)
		NetworkService.request_golden_altar()
		return
	# 单机：本地就是权威，直接结算。
	if GameState.player_formation_hp <= NetworkService.ALTAR_MIN_HP or GameState.golden_altar_uses >= NetworkService.ALTAR_MAX_USES_PER_ROUND:
		return
	GameState.player_formation_hp -= 1
	GameState.gold += NetworkService.ALTAR_GOLD
	GameState.golden_altar_uses += 1
	SaveManager.save_run()
	_refresh_all()

# 服务端对祭坛请求的裁决。uses < 0 表示这是队友用祭坛导致的共享 HP 同步，
# 本人不加金币、只刷新显示。
func _on_altar_result(granted: bool, team_hp: int, uses: int) -> void:
	if uses < 0:
		_refresh_all()
		return
	if not granted:
		_refresh_all()
		return
	GameState.team_hp = team_hp
	GameState.golden_altar_uses = uses
	GameState.gold += NetworkService.ALTAR_GOLD
	SaveManager.save_run()
	_refresh_all()

func _on_generous_fate_gamble() -> void:
	if not GameState.owned_treasures.has("money_generous_fate"):
		return
	if GameState.gamble_used:
		return
	var before := GameState.gold
	GameState.gamble_used = true
	var fraud_fate := TreasureService.has_linkage("link_fraud_fate")
	var win_chance := 0.60 if fraud_fate else 0.50
	var loss_keep := 0.50 if fraud_fate else 0.20
	if randf() < win_chance:
		GameState.gold = before * 2
	else:
		GameState.gold = maxi(0, int(floor(float(before) * loss_keep)))
	SaveManager.save_run()
	_refresh_all()



