extends RefCounted
class_name SkillVFXConfig

# 返回 Array[Dictionary]，每项: {path, offset, delay, scale, duration}
static func get_textures(unit_id: String) -> Array[Dictionary]:
	var b := "res://assets/vfx/skills/"
	match unit_id:
		# ── 神族 ──────────────────────────────────────────
		"god_priest":
			return _tex(b + "god_priest/", [
				"god_priest_holy_ring.png",
				"god_priest_soft_spark.png",
			], 0.65)
		"god_priestess":
			return _tex(b + "god_priestess/", [
				"god_priestess_decree.png",
				"god_priestess_decree_mark.png",
			], 0.65)
		"god_guard":
			return _tex(b + "god_guard/", [
				"god_guard_crystal_panel.png",
				"god_guard_taunt_rune.png",
			], 0.55)
		"god_aurora":
			return _tex(b + "god_aurora/", [
				"god_aurora_arrow_trail.png",
				"god_aurora_true_hit.png",
			], 0.40)
		"god_angel":
			return _tex(b + "god_angel/", [
				"god_angel_immunity_feathers.png",
				"god_angel_shelter_wing.png",
			], 0.65)
		"god_arbiter":
			return _tex(b + "god_arbiter/", [
				"god_arbiter_verdict_slash_v7.png",
				"god_arbiter_verdict_impact_v7.png",
			], 0.42)
		"god_archangel":
			return _tex(b + "god_archangel/", [
				"god_archangel_covenant_sigla.png",
				"god_archangel_mercy_ribbon.png",
			], 0.70)
		"god_king":
			return _tex(b + "god_king/", [
				"god_king_judgement_line.png",
				"god_king_royal_impact.png",
			], 0.50)
		# ── 暗族 ──────────────────────────────────────────
		# Every dark-race piece now owns a hand-painted layer set under
		# UnitSkillVFXComposer3D (dark_imp_curse, dark_mage_silence, ...).
		# Their old two-texture entries are gone so the new and old styles can
		# never play on top of each other.
		# ── 亡灵 ──────────────────────────────────────────
		"undead_poison":
			return _tex(b + "undead_poison/", [
				"undead_poison_miasma_cone.png",
				"undead_poison_spore_orb.png",
				"undead_poison_puddle.png",
			], 0.55)
		"undead_parasite":
			return _tex(b + "undead_parasite/", [
				"undead_parasite_cute_pod.png",
				"undead_parasite_cute_thread.png",
				"undead_parasite_cute_mark.png",
			], 0.50)
		"undead_spike":
			return _tex(b + "undead_spike/", [
				"undead_spike_bone_dart.png",
				"undead_spike_armor_break.png",
				"undead_spike_stack_pin.png",
			], 0.42)
		"undead_fly":
			return _tex(b + "undead_fly/", [
				"undead_fly_poison_feather.png",
				"undead_fly_evasion_spark.png",
				"undead_fly_dodge_afterimage.png",
			], 0.45)
		"undead_bomb":
			return _tex(b + "undead_bomb/", [
				"undead_bomb_core_pop.png",
				"undead_bomb_poison_ring.png",
				"undead_bomb_soul_fragment.png",
			], 0.48)
		"undead_titan":
			return _tex(b + "undead_titan/", [
				"undead_titan_reflect_spike.png",
				"undead_titan_armor_plate.png",
				"undead_titan_stack_badge.png",
			], 0.50)
		"undead_mother":
			return _tex(b + "undead_mother/", [
				"undead_mother_dark_orb.png",
				"undead_mother_dark_book.png",
				"undead_mother_death_mark.png",
			], 0.60)
		# ── 人族 ──────────────────────────────────────────
		"human_militia":
			return _tex(b + "human_militia/", [
				"human_militia_shield_bash.png",
				"human_militia_impact_ring.png",
				"human_militia_charge_dust_start.png",
			], 0.40)
		"human_merchant":
			return _tex(b + "human_merchant/", [
				"human_merchant_contract_slip.png",
				"human_merchant_coin_spark.png",
				"human_merchant_coin_trail.png",
			], 0.55)
		"human_archer":
			return _tex(b + "human_archer/", [
				"human_archer_arrow_trail.png",
				"human_archer_charge_wind.png",
				"human_archer_pierce_flash.png",
				"human_archer_star_crack.png",
				"human_archer_leaf_spark.png",
			], 0.40)
		"human_swordsman":
			# Keep only the two authored slash silhouettes. They are deliberately
			# compact but readable at the distant battle camera; spawned at the
			# actual hit target by front_cone_stun.
			return [
				{"path": b + "human_swordsman/human_swordsman_slash_a.png", "role": "hit", "offset": Vector2.ZERO, "delay": 0.0, "scale": 0.42, "duration": 0.54, "alpha": 0.88, "particles": 0, "spin": 0.0, "flatten": false, "drift": Vector2.ZERO, "stretch": Vector2(0.78, 0.78), "glow": false},
				{"path": b + "human_swordsman/human_swordsman_slash_b.png", "role": "hit", "offset": Vector2.ZERO, "delay": 0.10, "scale": 0.34, "duration": 0.48, "alpha": 0.74, "particles": 0, "spin": 0.0, "flatten": false, "drift": Vector2.ZERO, "stretch": Vector2(0.78, 0.78), "glow": false},
			]
		"human_mage":
			return _tex(b + "human_mage/", [
				"human_mage_element_orb.png",
				"human_mage_element_burst.png",
				"human_mage_element_trail.png",
				"human_mage_element_residue.png",
			], 0.50)
		"human_cleric":
			return _tex(b + "human_cleric/", [
				"human_cleric_life_mark.png",
				"human_cleric_heal_ribbon.png",
				"human_cleric_prayer_wisp.png",
				"cleric_final_contact.png",
			], 0.60)
		"human_death_servant":
			return _tex(b + "human_death_servant/", [
				"human_death_servant_guard_sigils.png",
				"human_death_servant_blood_chain.png",
				"human_death_servant_oath_crack.png",
				"human_death_servant_sacrifice_burst.png",
			], 0.55)
		"human_king":
			# One readable target-bound sword only. The old light-column and
			# contact overlays were overexposed and are intentionally excluded.
			return [{
				"path": b + "human_king/human_king_heaven_sword.png",
				"role": "hit",
				"offset": Vector2(0.0, -56.0),
				"delay": 0.0,
				"scale": 0.44,
				"duration": 0.62,
				"alpha": 0.78,
				"glow": false,
				"particles": 0,
				"spin": 0.0,
				"flatten": false,
				"drift": Vector2(0.0, 42.0),
				"stretch": Vector2(0.72, 0.72),
			}]
		"boss_apocalypse":
			return _boss_tex("res://assets/vfx/boss/", ["boss_apocalypse_chargeup.png", "boss_apocalypse_shield.png", "boss_apocalypse_blast.png"], [0.0, 0.18, 1.72], [0.68, 0.64, 0.78], [2.0, 1.45, 0.62])
		"boss_meteor_caster":
			return _boss_tex("res://assets/vfx/boss/", ["boss_meteor_warning.png", "boss_meteor_trail.png", "boss_meteor_explosion.png"], [0.0, 0.42, 1.18], [0.60, 0.48, 0.66], [1.35, 0.82, 0.62])
		"boss_mirror_lord":
			return _boss_tex("res://assets/vfx/boss/", ["boss_mirror_split.png", "boss_mirror_clone.png", "boss_mirror_slash.png"], [0.0, 0.16, 0.52], [0.64, 0.52, 0.58], [0.75, 1.25, 0.55])
		"boss_holy_priest":
			return _boss_tex("res://assets/vfx/boss/", ["boss_holy_purify.png", "boss_holy_heal.png", "boss_holy_shield.png"], [0.0, 0.18, 0.36], [0.64, 0.58, 0.62], [0.85, 1.0, 1.25])
		"boss_thunder_core":
			return _boss_tex("res://assets/vfx/boss/", ["boss_thunder_stack.png", "boss_thunder_counter.png", "boss_thunder_overload.png"], [0.0, 0.22, 0.58], [0.56, 0.60, 0.66], [1.4, 0.58, 0.7])
		"boss_twin_gate":
			return _boss_tex("res://assets/vfx/boss/", ["boss_twin_timer.png", "boss_twin_revive.png", "boss_twin_link.png"], [0.0, 0.42, 0.12], [0.52, 0.62, 0.58], [1.6, 0.8, 1.35])
		"boss_blood_demon":
			return _boss_tex("res://assets/vfx/boss/", ["boss_blood_rage.png", "boss_blood_lifesteal.png", "boss_blood_overflow.png"], [0.0, 0.18, 0.52], [0.60, 0.52, 0.66], [1.4, 0.58, 0.65])
		"boss_soul_devourer":
			return _boss_tex("res://assets/vfx/boss/", ["boss_soul_devour.png", "boss_soul_fragment.png", "boss_soul_growth.png"], [0.0, 0.22, 0.48], [0.64, 0.42, 0.58], [1.3, 0.6, 1.35])
		"boss_rage_beast":
			return _boss_tex("res://assets/vfx/boss/", ["boss_rage_stack.png", "boss_rage_aura.png", "boss_rage_burst.png"], [0.0, 0.20, 0.56], [0.54, 0.64, 0.66], [1.6, 1.35, 0.65])
	return []

static func _boss_tex(folder: String, names: Array, delays: Array, scales: Array, durations: Array) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for i in names.size():
		var name := str(names[i])
		var role := _boss_role_for_name(name)
		result.append({
			"path": folder + name,
			"role": role,
			"offset": Vector2.ZERO,
			"delay": float(delays[i]),
			"scale": float(scales[i]),
			"duration": float(durations[i]),
			"alpha": 0.82,
			"boss": true,
			"glow": true,
			"particles": 5 if role == "hit" else 1,
			"spin": 0.0,
			"flatten": false,
			"drift": Vector2(randf_range(-18.0, 18.0), randf_range(-12.0, 12.0)),
			"stretch": Vector2(1.16, 0.88) if role == "hit" else Vector2(1.08, 0.94),
			"pulse": 1.16 if role == "hit" else 1.09,
		})
	return result

static func _boss_role_for_name(name: String) -> String:
	var n := name.to_lower()
	if n.contains("blast") or n.contains("explosion") or n.contains("burst") or n.contains("counter") or n.contains("slash") or n.contains("purify") or n.contains("overflow"):
		return "hit"
	if n.contains("trail") or n.contains("link"):
		return "projectile"
	return "cast"

static func _tex(folder: String, names: Array, dur: float) -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	var delay := 0.0
	for name in names:
		var role := _role_for_name(name)
		var cfg := {
			"path":     folder + name,
			"role":     role,
			"offset":   _offset_for_name(name, role),
			"delay":    delay,
			"scale":    _scale_for_name(name, role),
			"duration": _duration_for_name(name, role, dur),
			"alpha":    _alpha_for_role(role),
			"glow":     true,
			"particles": _particles_for_name(name, role),
			"spin":     _spin_for_name(name, role),
			"flatten":  role == "foot",
			"drift":    _drift_for_name(name, role),
		}
		result.append(cfg)
		delay += 0.07
	return result

static func _role_for_name(name: String) -> String:
	var n := name.to_lower()
	if n.contains("trail") or n.contains("bolt") or n.contains("dart") or n.contains("feather") or n.contains("heart_spike") or n.contains("ribbon") or n.contains("thread") or n.contains("line"):
		return "projectile"
	if n.contains("life_mark") or n.contains("residue") or n.contains("puddle") or n.contains("ring") or n.contains("rift") or n.contains("crack"):
		return "foot"
	if n.contains("mark") or n.contains("stars") or n.contains("armor_break") or n.contains("armor_plate") or n.contains("stack") or n.contains("badge") or n.contains("pin") or n.contains("sigla") or n.contains("book"):
		return "head"
	if n.contains("dark_orb") or n.contains("spore_orb") or n.contains("hit") or n.contains("burst") or n.contains("impact") or n.contains("flash") or n.contains("spark") or n.contains("slash") or n.contains("sword") or n.contains("column") or n.contains("flame") or n.contains("pop"):
		return "hit"
	return "cast"

static func _scale_for_name(name: String, role: String) -> float:
	var n := name.to_lower()
	if n == "undead_spike_bone_dart.png":
		return 0.14
	if n.begins_with("undead_spike_"):
		return 0.24
	if n.contains("sword") or n.contains("column"):
		return 0.62
	if role == "projectile":
		return 0.42
	if role == "foot":
		return 0.62
	if role == "head":
		return 0.42
	if role == "hit":
		return 0.54
	return 0.50

static func _duration_for_name(name: String, role: String, fallback: float) -> float:
	var n := name.to_lower()
	if n.contains("residue"):
		return 2.5
	if n.contains("curse"):
		return 4.0
	if n.contains("silence"):
		return 1.2
	if n.contains("stun") or n.contains("stars"):
		return 1.0
	if n.contains("ghost_face") or n.contains("backstep"):
		return 1.5
	if n.contains("stack") or n.contains("pin") or n.contains("badge"):
		return 5.0
	if role == "foot":
		return maxf(fallback, 1.2)
	if role == "head":
		return maxf(fallback, 0.9)
	return fallback

static func _alpha_for_role(role: String) -> float:
	if role == "foot":
		return 0.82
	if role == "projectile":
		return 0.95
	return 1.0

static func _particles_for_name(name: String, role: String) -> int:
	var n := name.to_lower()
	if role == "projectile":
		return 0
	if n.contains("spark") or n.contains("fragment") or n.contains("spore") or n.contains("burst") or n.contains("impact") or n.contains("hit") or n.contains("pop"):
		return 8
	if role == "hit":
		return 5
	if role == "head":
		return 3
	return 0

static func _spin_for_name(name: String, role: String) -> float:
	var n := name.to_lower()
	if n.contains("stars") or n.contains("ring") or n.contains("sigla") or n.contains("book"):
		return 0.35
	if role == "hit":
		return 0.08
	return 0.0

static func _offset_for_name(name: String, role: String) -> Vector2:
	var n := name.to_lower()
	if n.contains("sword"):
		return Vector2(0.0, -56.0)
	if n.contains("column"):
		return Vector2(0.0, -24.0)
	if role == "foot":
		return Vector2(0.0, 8.0)
	return Vector2.ZERO

static func _drift_for_name(name: String, role: String) -> Vector2:
	var n := name.to_lower()
	if n.contains("sword"):
		return Vector2(0.0, 48.0)
	if n.contains("column"):
		return Vector2(0.0, -8.0)
	if role == "head":
		return Vector2(0.0, -10.0)
	if role == "hit":
		return Vector2(0.0, -4.0)
	return Vector2.ZERO
