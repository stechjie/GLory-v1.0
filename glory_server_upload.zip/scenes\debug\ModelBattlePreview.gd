extends Node3D

const UNIT_DATA_PATH := "res://data/units/race_units.json"
const MONSTER_DATA_PATH := "res://data/pve/pve_monsters.json"
const MERCENARY_DATA_PATH := "res://data/mercenary/mercenaries.json"
const BOSS_DATA_PATH := "res://data/boss/bosses.json"
const FORMATION_BOSS_DATA_PATH := "res://data/formation/formation_allies.json"
const VFX_LIGHTNING_ARC := preload("res://effects/vfx3d/VFXLightningArc.gd")
const VFX_LIGHTNING_BALL := preload("res://effects/vfx3d/VFXLightningBall.gd")
const VFX_TARGET_IMPACT := preload("res://effects/vfx3d/VFXTargetImpact.gd")
const VFX_SHOCKWAVE := preload("res://effects/vfx3d/VFXShockwave.gd")
const VFX_SMOKE_BURST := preload("res://effects/vfx3d/VFXSmokeBurst.gd")
const VFX_MASKED_PARTICLE := preload("res://effects/vfx3d/modules/VFXMaskedParticle3D.gd")
const VFX_RIBBON_TRAIL := preload("res://effects/vfx3d/modules/VFXRibbonTrail3D.gd")
const VFX_IMPACT_FLASH := preload("res://effects/vfx3d/modules/VFXImpactFlash3D.gd")
const VFX_DEBRIS_BURST := preload("res://effects/vfx3d/modules/VFXDebrisBurst3D.gd")
const VFX_GROUND_RESIDUE := preload("res://effects/vfx3d/modules/VFXGroundResidue3D.gd")
const VFX_LAYERED_SHOCKWAVE := preload("res://effects/vfx3d/modules/VFXShockwave3D.gd")
const VFX_SPRITE_FLIPBOOK := preload("res://effects/vfx3d/modules/VFXSpriteFlipbook3D.gd")
const VFX_SHAPE_DISTORTION := preload("res://effects/vfx3d/modules/VFXShapeDistortion3D.gd")
const VFX_DIRECTIONAL_BURST := preload("res://effects/vfx3d/modules/VFXDirectionalBurst3D.gd")
const VFX_LIGHT_PULSE := preload("res://effects/vfx3d/modules/VFXLightPulse3D.gd")
const VFX_CAMERA_FEEDBACK := preload("res://effects/vfx3d/modules/VFXCameraFeedback3D.gd")
const VFX_HIT_STOP := preload("res://effects/vfx3d/modules/VFXHitStopController.gd")
const VFX_PATH_RIBBON := preload("res://effects/vfx3d/modules/VFXPathRibbon3D.gd")
const VFX_SLASH_ARC := preload("res://effects/vfx3d/modules/VFXSlashArc3D.gd")
const VFX_SLASH_RING := preload("res://effects/vfx3d/modules/VFXSlashRing3D.gd")
const VFX_ENERGY_BURST := preload("res://effects/vfx3d/modules/VFXEnergyBurst3D.gd")
const VFX_GROUND_SIGIL := preload("res://effects/vfx3d/modules/VFXGroundSigil3D.gd")
const VFX_PORTAL := preload("res://effects/vfx3d/modules/VFXPortal3D.gd")
const VFX_PROJECTILE_3D := preload("res://effects/vfx3d/modules/VFXProjectile3D.gd")
const VFX_METEOR_STRIKE := preload("res://effects/vfx3d/modules/VFXMeteorStrike3D.gd")
const VFX_BARRIER_SHIELD := preload("res://effects/vfx3d/modules/VFXBarrierShield3D.gd")
const VFX_FALLING_PILLAR := preload("res://effects/vfx3d/modules/VFXFallingPillar3D.gd")
const VFX_ROAR_CONE := preload("res://effects/vfx3d/modules/VFXRoarCone3D.gd")
const VFX_STATUS_EFFECT := preload("res://effects/vfx3d/modules/VFXStatusEffect3D.gd")
const VFX_TRACKED_LINK := preload("res://effects/vfx3d/modules/VFXTrackedLink3D.gd")
const VFX_VORTEX_FIELD := preload("res://effects/vfx3d/modules/VFXVortexField3D.gd")
const VFX_SUMMON_SPAWN := preload("res://effects/vfx3d/modules/VFXSummonSpawn3D.gd")
const VFX_AFTERIMAGE_DASH := preload("res://effects/vfx3d/modules/VFXAfterimageDash3D.gd")
const VFX_RACE_BASIC_ATTACK := preload("res://effects/vfx3d/modules/VFXRaceBasicAttack3D.gd")
const VFX_MOTHER_EXECUTE := preload("res://effects/vfx3d/modules/VFXMotherExecute3D.gd")
const BOSS_SKILL_COMPOSER := preload("res://effects/vfx3d/boss/BossSkillVFXComposer3D.gd")
const UNIT_SKILL_COMPOSER := preload("res://effects/vfx3d/units/UnitSkillVFXComposer3D.gd")
const VFX_COMPOSITION := preload("res://effects/vfx3d/core/VFXComposition3D.gd")
const VFX_PREVIEW_RECORDER := preload("res://effects/vfx3d/preview/VFXPreviewRecorder.gd")
const VFX_VALIDATION := preload("res://effects/vfx3d/core/VFXValidationReport.gd")
const VFX_V2_REGISTRY := preload("res://effects/vfx3d/vfxv2/VFXV2Registry.gd")
const PROFILE_SHOCKWAVE := preload("res://effects/vfx3d/profiles/examples/shockwave_layered_example.tres")
const PROFILE_FLIPBOOK := preload("res://effects/vfx3d/profiles/examples/flipbook_energy_example.tres")
const PROFILE_DISTORTION := preload("res://effects/vfx3d/profiles/examples/shape_distortion_example.tres")
const PROFILE_DIRECTIONAL := preload("res://effects/vfx3d/profiles/examples/directional_burst_example.tres")
const PROFILE_DEBRIS := preload("res://effects/vfx3d/profiles/examples/debris_layered_example.tres")
const PROFILE_LIGHT := preload("res://effects/vfx3d/profiles/examples/light_pulse_example.tres")
const PROFILE_CAMERA := preload("res://effects/vfx3d/profiles/examples/camera_feedback_example.tres")
const PROFILE_HIT_STOP := preload("res://effects/vfx3d/profiles/examples/hit_stop_example.tres")
const PROFILE_PATH_RIBBON := preload("res://effects/vfx3d/profiles/examples/path_ribbon_slash_example.tres")
const PROFILE_SLASH_ARC := preload("res://effects/vfx3d/profiles/examples/slash_arc_heavy_example.tres")
const PROFILE_SLASH_RING := preload("res://effects/vfx3d/profiles/examples/slash_ring_boss_example.tres")
const PROFILE_ENERGY_BURST := preload("res://effects/vfx3d/profiles/examples/energy_burst_heavy_example.tres")
const PROFILE_GROUND_SIGIL := preload("res://effects/vfx3d/profiles/examples/ground_sigil_arcane_example.tres")
const PROFILE_PORTAL := preload("res://effects/vfx3d/profiles/examples/portal_verdant_example.tres")
const PROFILE_PROJECTILE_3D := preload("res://effects/vfx3d/profiles/examples/projectile_fire_example.tres")
const PROFILE_METEOR_STRIKE := preload("res://effects/vfx3d/profiles/examples/meteor_strike_example.tres")
const PROFILE_BARRIER_SHIELD := preload("res://effects/vfx3d/profiles/examples/barrier_shield_example.tres")
const PROFILE_FALLING_PILLAR := preload("res://effects/vfx3d/profiles/examples/falling_pillar_example.tres")
const PROFILE_ROAR_CONE := preload("res://effects/vfx3d/profiles/examples/roar_cone_example.tres")
const PROFILE_STATUS_STUN := preload("res://effects/vfx3d/profiles/examples/status_stun_example.tres")
const PROFILE_TRACKED_LINK := preload("res://effects/vfx3d/profiles/examples/tracked_link_example.tres")
const PROFILE_VORTEX_SHADOW := preload("res://effects/vfx3d/profiles/examples/vortex_shadow_example.tres")
const PROFILE_SUMMON_SPAWN := preload("res://effects/vfx3d/profiles/examples/summon_spawn_example.tres")
const PROFILE_AFTERIMAGE_DASH := preload("res://effects/vfx3d/profiles/examples/afterimage_dash_example.tres")
const PROFILE_BASIC_GOD := preload("res://effects/vfx3d/profiles/examples/basic_attack_god.tres")
const PROFILE_BASIC_HUMAN := preload("res://effects/vfx3d/profiles/examples/basic_attack_human.tres")
const PROFILE_BASIC_DARK := preload("res://effects/vfx3d/profiles/examples/basic_attack_dark.tres")
const PROFILE_BASIC_UNDEAD := preload("res://effects/vfx3d/profiles/examples/basic_attack_undead.tres")
const PROFILE_MOTHER_EXECUTE := preload("res://effects/vfx3d/profiles/examples/mother_execute_example.tres")
const RECIPE_FULL_STAGES := preload("res://effects/vfx3d/recipes/examples/full_skill_stages_demo.tres")
const PROFILE_SUMMON_TEAM_A := preload("res://effects/vfx3d/profiles/formation/summon_formation_red.tres")
const PROFILE_SUMMON_TEAM_B := preload("res://effects/vfx3d/profiles/formation/summon_formation_blue.tres")
const FINAL_ROUND_BOARD := preload("res://assets/board/2_5d/battlefield_final_round.png")
const FORMATION_SOURCE_TAG := "法阵Boss"
const BOSS_STAGE_SLOT_X := 1.75
const BOSS_STAGE_RISE := 0.42
const BOSS_STAGE_RISE_TIME := 0.40
const TARGET_HEIGHT := 1.32
const TARGET_WIDTH := 1.06
const ATTACK_PERIOD := 2.2
const ATTACK_WINDOW := 0.34
const WALK_IN_TIME := 0.85
const SPAWN_DEPTH := 1.72
const ENGAGE_DEPTH := 0.48
const CAMERA_MIN_HEIGHT := 4.8
const CAMERA_MIN_DISTANCE := 7.2
const CAMERA_FRAME_MARGIN := 1.85
const SIDE_LEFT := -1
const SIDE_RIGHT := 1
const SIDE_BOTH := 0
const FALLBACK_MODELS := [
	{"id": "pve_land_rock_beast", "name": "岩甲兽", "source": "怪物", "model": "res://assets/models/monsters/land/pve_land_rock_beast_animated/pve_land_rock_beast_animated.tscn", "model_visual_scale": 1.0, "model_base_yaw": 180.0},
	{"id": "pve_sky_wind_falcon", "name": "风刃隼", "source": "怪物", "model": "res://assets/models/monsters/sky/pve_sky_wind_falcon_animated/pve_sky_wind_falcon_animated.tscn", "model_visual_scale": 1.0, "model_base_yaw": 180.0}
]

@onready var left_slot: Node3D = $Stage/LeftSlot
@onready var right_slot: Node3D = $Stage/RightSlot
@onready var camera: Camera3D = $Camera3D
@onready var canvas_layer: CanvasLayer = $CanvasLayer
@onready var info_label: Label = $CanvasLayer/InfoLabel
@onready var hit_flash: MeshInstance3D = $Stage/HitFlash

var rng := RandomNumberGenerator.new()
var model_entries: Array = []
var units: Array = []
var selected_left_index := 0
var selected_right_index := 1
var phase_time := 0.0
var last_cycle := -1
var last_attack_cycle := -1
var preview_names := ""
var auto_fight_enabled := true
var camera_target := Vector3(0.0, 0.68, 0.0)
var camera_height := 5.4
var camera_distance := 8.4
var camera_yaw_deg := 0.0
var camera_fov := 48.0
var left_model_select: OptionButton
var right_model_select: OptionButton
var auto_button: Button
var skill_button: Button
var vfx_select: OptionButton
var vfx_status_label: Label
var vfx_preview_root: Node3D
var vfx_preview_effect: Node3D
var vfx_recorder: VFXPreviewRecorder
var vfx_v2_select: OptionButton
var vfx_v2_status_label: Label
var vfx_v2_preview_effect: Node3D
var boss_stage_active := false
var boss_stage_scale := 1.0
# ally_1 ships without any textures, so start on ally_2 which is fully textured.
var boss_stage_ally_index := 1
var boss_stage_scale_button: Button
var boss_stage_ally_button: Button
var boss_stage_root: Node3D
var board_default_texture: Texture2D

func _ready() -> void:
	rng.randomize()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 7.2
	camera.fov = 39.0
	camera.near = 0.03
	camera.far = 80.0
	camera.look_at(Vector3(0.0, 0.72, 0.0), Vector3.UP)
	_setup_info_label()
	_build_control_panel()
	_build_vfx_test_panel()
	_build_vfx_v2_test_panel()
	model_entries = _load_model_entries()
	_populate_model_selects()
	_select_default_models()
	_ensure_preview_camera_current()
	_load_selected_pair()

func _process(delta: float) -> void:
	phase_time += delta
	if auto_fight_enabled and not boss_stage_active:
		var cycle := int(floor(phase_time / ATTACK_PERIOD))
		var cycle_pos: float = fmod(phase_time, ATTACK_PERIOD)
		if cycle != last_cycle:
			last_cycle = cycle
			last_attack_cycle = -1
			_play_action_for_side("run", SIDE_BOTH, false)
		if cycle_pos >= WALK_IN_TIME and cycle != last_attack_cycle:
			last_attack_cycle = cycle
			_play_action_for_side("attack", SIDE_BOTH, false)
	_animate_units()
	_update_hit_flash()
	_update_camera_controls(delta)
	_ensure_preview_camera_current()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		var mouse_button := event as InputEventMouseButton
		match mouse_button.button_index:
			MOUSE_BUTTON_WHEEL_UP:
				camera_distance = maxf(1.0, camera_distance - 0.55)
				_apply_preview_camera()
				_update_label()
			MOUSE_BUTTON_WHEEL_DOWN:
				camera_distance = minf(30.0, camera_distance + 0.55)
				_apply_preview_camera()
				_update_label()
		return
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
		var motion := event as InputEventMouseMotion
		camera_yaw_deg = wrapf(camera_yaw_deg - motion.relative.x * 0.18, -180.0, 180.0)
		camera_height = clampf(camera_height - motion.relative.y * 0.018, 0.35, 18.0)
		_apply_preview_camera()
		_update_label()
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_R:
				_load_random_pair()
			KEY_1:
				_play_action_for_side("idle", SIDE_BOTH, true)
			KEY_2:
				_play_action_for_side("attack", SIDE_BOTH, true)
			KEY_3:
				_play_action_for_side("run", SIDE_BOTH, true)
			KEY_SPACE:
				_play_action_for_side("attack", SIDE_BOTH, true)
			KEY_B:
				_on_boss_stage_pressed()
			KEY_H:
				_frame_preview_camera()
				_update_label()
			KEY_ESCAPE:
				get_tree().quit()

func _setup_info_label() -> void:
	info_label.offset_left = 16.0
	info_label.offset_top = 14.0
	info_label.offset_right = 980.0
	info_label.offset_bottom = 220.0
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info_label.add_theme_font_size_override("font_size", 14)

func _build_control_panel() -> void:
	var panel := PanelContainer.new()
	panel.name = "ModelControlPanel"
	panel.anchor_left = 1.0
	panel.anchor_top = 0.0
	panel.anchor_right = 1.0
	panel.anchor_bottom = 0.0
	panel.offset_left = -560.0
	panel.offset_top = 14.0
	panel.offset_right = -16.0
	panel.offset_bottom = 184.0
	canvas_layer.add_child(panel)

	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 6)
	panel.add_child(rows)

	var select_row := HBoxContainer.new()
	select_row.add_theme_constant_override("separation", 8)
	rows.add_child(select_row)

	var left_label := Label.new()
	left_label.text = "左模型"
	select_row.add_child(left_label)
	left_model_select = OptionButton.new()
	left_model_select.custom_minimum_size = Vector2(210.0, 0.0)
	left_model_select.item_selected.connect(_on_left_model_selected)
	select_row.add_child(left_model_select)

	var right_label := Label.new()
	right_label.text = "右模型"
	select_row.add_child(right_label)
	right_model_select = OptionButton.new()
	right_model_select.custom_minimum_size = Vector2(210.0, 0.0)
	right_model_select.item_selected.connect(_on_right_model_selected)
	select_row.add_child(right_model_select)

	var left_action_row := HBoxContainer.new()
	left_action_row.add_theme_constant_override("separation", 6)
	rows.add_child(left_action_row)
	_add_button(left_action_row, "左 Idle", _on_left_idle_pressed)
	_add_button(left_action_row, "左 Attack", _on_left_attack_pressed)
	_add_button(left_action_row, "左 Run", _on_left_run_pressed)
	_add_button(left_action_row, "右 Idle", _on_right_idle_pressed)
	_add_button(left_action_row, "右 Attack", _on_right_attack_pressed)
	_add_button(left_action_row, "右 Run", _on_right_run_pressed)

	var both_action_row := HBoxContainer.new()
	both_action_row.add_theme_constant_override("separation", 6)
	rows.add_child(both_action_row)
	_add_button(both_action_row, "双 Idle", _on_both_idle_pressed)
	_add_button(both_action_row, "双 Attack", _on_both_attack_pressed)
	_add_button(both_action_row, "双 Run", _on_both_run_pressed)
	_add_button(both_action_row, "随机", _on_random_pressed)
	auto_button = _add_button(both_action_row, "自动战斗 ON", _on_auto_fight_pressed)
	skill_button = _add_button(both_action_row, "Skill", _on_skill_pressed)

func _build_vfx_test_panel() -> void:
	var panel := PanelContainer.new()
	panel.name = "VFXTestPanel"
	panel.anchor_left = 0.0
	panel.anchor_top = 1.0
	panel.anchor_right = 0.0
	panel.anchor_bottom = 1.0
	panel.offset_left = 16.0
	panel.offset_top = -214.0
	panel.offset_right = 516.0
	panel.offset_bottom = -16.0
	canvas_layer.add_child(panel)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 5)
	panel.add_child(rows)
	var title := Label.new()
	title.text = "VFX CHECK"
	title.add_theme_font_size_override("font_size", 14)
	rows.add_child(title)
	var select_row := HBoxContainer.new()
	select_row.add_theme_constant_override("separation", 6)
	rows.add_child(select_row)
	var label := Label.new()
	label.text = "VFX"
	select_row.add_child(label)
	vfx_select = OptionButton.new()
	vfx_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vfx_select.add_item("Lightning Arc")
	vfx_select.add_item("Lightning Ball")
	vfx_select.add_item("Target Impact Burst")
	vfx_select.add_item("Shockwave")
	vfx_select.add_item("Smoke Burst")
	vfx_select.add_item("Module: Masked Particle")
	vfx_select.add_item("Module: Ribbon Trail")
	vfx_select.add_item("Module: Impact Flash")
	vfx_select.add_item("Module: Debris Burst")
	vfx_select.add_item("Module: Ground Residue")
	vfx_select.add_item("Module: Layered Shockwave")
	vfx_select.add_item("Module: Sprite Flipbook")
	vfx_select.add_item("Module: Shape Distortion")
	vfx_select.add_item("Module: Directional Burst")
	vfx_select.add_item("Module: Light Pulse")
	vfx_select.add_item("Module: Camera Feedback")
	vfx_select.add_item("Module: Hit Stop")
	vfx_select.add_item("Module: Path Ribbon")
	vfx_select.add_item("Module: Slash Arc")
	vfx_select.add_item("Module: Slash Ring")
	vfx_select.add_item("Architecture: Timeline + Curves")
	vfx_select.add_item("Recipe: Full Skill Stages")
	vfx_select.add_item("Module: Energy Burst")
	vfx_select.add_item("Module: Ground Sigil")
	vfx_select.add_item("Module: Portal")
	vfx_select.add_item("Module: Projectile 3D")
	vfx_select.add_item("Module: Meteor Strike")
	vfx_select.add_item("Module: Barrier Shield")
	vfx_select.add_item("Module: Falling Pillar")
	vfx_select.add_item("Module: Roar Cone")
	vfx_select.add_item("Boss: Apocalypse Charge + Verdict")
	vfx_select.add_item("Boss: Element Meteor")
	vfx_select.add_item("Boss: Thunder Overload Counter")
	vfx_select.add_item("Boss: Mirror Clone + Slash")
	vfx_select.add_item("Boss: Holy Purify")
	vfx_select.add_item("Boss: Rage Milestone")
	vfx_select.add_item("Boss: Blood Rage + Lifesteal")
	vfx_select.add_item("Boss: Soul Devour")
	vfx_select.add_item("Boss: Twin Timer + Revive")
	vfx_select.add_item("Validation: Moving Target Projectile")
	vfx_select.add_item("Module: Status Effect")
	vfx_select.add_item("Unit Status: Silence Emblem")
	vfx_select.add_item("Unit Status: Poison Emblem")
	vfx_select.add_item("Module: Tracked Link")
	vfx_select.add_item("Module: Vortex Field")
	vfx_select.add_item("Module: Summon Spawn")
	vfx_select.add_item("Module: Afterimage Dash")
	vfx_select.add_item("Unit Basic: God Ranged")
	vfx_select.add_item("Unit Basic: God Melee")
	vfx_select.add_item("Unit Basic: Human Ranged")
	vfx_select.add_item("Unit Basic: Human Melee")
	vfx_select.add_item("Unit Basic: Dark Ranged")
	vfx_select.add_item("Unit Basic: Dark Melee")
	vfx_select.add_item("Unit Basic: Undead Ranged")
	vfx_select.add_item("Unit Basic: Undead Melee")
	vfx_select.add_item("Unit Skill: Silence Bolt")
	vfx_select.add_item("Unit Skill: Poison Dart")
	vfx_select.add_item("Unit Skill: Mother Execute")
	vfx_select.add_item("Unit Skill: Stun Hit")
	vfx_select.add_item("Unit Skill: Attribute Bolt")
	select_row.add_child(vfx_select)
	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 6)
	rows.add_child(action_row)
	_add_button(action_row, "Play VFX", _on_vfx_play_pressed)
	_add_button(action_row, "Clear", _on_vfx_clear_pressed)
	_add_button(action_row, "Auto Fight", _on_vfx_auto_pressed)
	var playback_row := HBoxContainer.new()
	playback_row.add_theme_constant_override("separation", 5)
	rows.add_child(playback_row)
	_add_button(playback_row, "Pause", _on_vfx_pause_pressed)
	_add_button(playback_row, "Step", _on_vfx_step_pressed)
	_add_button(playback_row, "0.25x", _on_vfx_quarter_speed_pressed)
	_add_button(playback_row, "0.5x", _on_vfx_half_speed_pressed)
	_add_button(playback_row, "1x", _on_vfx_normal_speed_pressed)
	var capture_row := HBoxContainer.new()
	capture_row.add_theme_constant_override("separation", 5)
	rows.add_child(capture_row)
	_add_button(capture_row, "Screenshot", _on_vfx_screenshot_pressed)
	_add_button(capture_row, "Shot @ 0.5s", _on_vfx_fixed_screenshot_pressed)
	_add_button(capture_row, "Validate", _on_vfx_validate_pressed)
	var stage_row := HBoxContainer.new()
	stage_row.add_theme_constant_override("separation", 5)
	rows.add_child(stage_row)
	_add_button(stage_row, "BossStage", _on_boss_stage_pressed)
	boss_stage_scale_button = _add_button(stage_row, "体型 1x", _on_boss_stage_scale_pressed)
	boss_stage_ally_button = _add_button(stage_row, "友军 2/5", _on_boss_stage_ally_pressed)
	_add_button(stage_row, "还原战场", _on_boss_stage_reset_pressed)
	vfx_status_label = Label.new()
	vfx_status_label.text = "Select an effect and press Play VFX"
	vfx_status_label.add_theme_font_size_override("font_size", 11)
	rows.add_child(vfx_status_label)
	vfx_preview_root = Node3D.new()
	vfx_preview_root.name = "VFXPreviewRoot"
	$Stage.add_child(vfx_preview_root)
	vfx_recorder = VFX_PREVIEW_RECORDER.new()
	vfx_recorder.name = "VFXPreviewRecorder"
	add_child(vfx_recorder)

func _build_vfx_v2_test_panel() -> void:
	var panel := PanelContainer.new()
	panel.name = "VFXV2TestPanel"
	panel.anchor_left = 1.0
	panel.anchor_top = 1.0
	panel.anchor_right = 1.0
	panel.anchor_bottom = 1.0
	panel.offset_left = -430.0
	panel.offset_top = -176.0
	panel.offset_right = -16.0
	panel.offset_bottom = -16.0
	canvas_layer.add_child(panel)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 5)
	panel.add_child(rows)
	var title := Label.new()
	title.text = "VFX v2 · Binbun original isolated preview"
	title.add_theme_font_size_override("font_size", 13)
	rows.add_child(title)
	var select_row := HBoxContainer.new()
	rows.add_child(select_row)
	var label := Label.new()
	label.text = "VFX v2"
	select_row.add_child(label)
	vfx_v2_select = OptionButton.new()
	vfx_v2_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for entry in VFX_V2_REGISTRY.names():
		vfx_v2_select.add_item(entry)
	select_row.add_child(vfx_v2_select)
	var action_row := HBoxContainer.new()
	rows.add_child(action_row)
	_add_button(action_row, "Play VFX v2", _on_vfx_v2_play_pressed)
	_add_button(action_row, "Clear v2", _on_vfx_v2_clear_pressed)
	var hint := Label.new()
	hint.text = "Binbun originals only · no battle skill replacement"
	hint.add_theme_font_size_override("font_size", 10)
	rows.add_child(hint)
	vfx_v2_status_label = Label.new()
	vfx_v2_status_label.text = "Select a V2 module and press Play"
	vfx_v2_status_label.add_theme_font_size_override("font_size", 10)
	rows.add_child(vfx_v2_status_label)

func _on_vfx_v2_play_pressed() -> void:
	_clear_all_preview_nodes()
	if vfx_v2_select == null:
		return
	var index := vfx_v2_select.get_selected_id()
	var fx: Node3D = VFX_V2_REGISTRY.create(index)
	fx.name = "PreviewVFXV2_%d" % index
	vfx_preview_root.add_child(fx)
	vfx_v2_preview_effect = fx
	var profile: VFXProfile3D = VFX_V2_REGISTRY.profile(index)
	var origin := left_slot.position + Vector3(0.0, 0.66, 0.0)
	var target := right_slot.position + Vector3(0.0, 0.42, 0.0)
	if index >= 18:
		fx.call("play_recipe", VFX_V2_REGISTRY.recipe(index), {"origin": origin, "target": target, "profile": profile})
		vfx_v2_status_label.text = "Playing: %s" % VFX_V2_REGISTRY.names()[index]
		return
	if index >= 7:
		var external_kinds := ["starter_hit_01", "starter_hit_02", "starter_fire", "starter_explosion", "starter_smoke_01", "starter_smoke_02", "starter_muzzle", "starter_loot_01", "starter_loot_02", "demo_orb_03", "demo_orb_04"]
		fx.call("play_external", external_kinds[index - 7], target, target, profile)
		vfx_v2_status_label.text = "Playing: %s" % VFX_V2_REGISTRY.names()[index]
		return
	if index >= 5:
		fx.call("play_recipe", VFX_V2_REGISTRY.recipe(index), {"origin": origin, "target": target, "profile": profile})
		vfx_v2_status_label.text = "Playing: %s" % VFX_V2_REGISTRY.names()[index]
		return
	var kinds := ["projectile", "beam", "slash", "portal", "loot"]
	fx.call("play_reference", kinds[index], origin, target, profile)
	vfx_v2_status_label.text = "Playing: %s" % VFX_V2_REGISTRY.names()[index]

func _on_vfx_v2_clear_pressed() -> void:
	_clear_vfx_v2_preview()
	if vfx_v2_status_label != null:
		vfx_v2_status_label.text = "VFX v2 cleared"

func _clear_vfx_v2_preview() -> void:
	_clear_all_preview_nodes()

func _clear_all_preview_nodes() -> void:
	# Imported/reference effects may spawn children and outlive their root handle.
	# Clear the actual preview container so no stale VFX can remain on the board.
	if vfx_preview_root != null and is_instance_valid(vfx_preview_root):
		for child in vfx_preview_root.get_children():
			if is_instance_valid(child):
				child.queue_free()
	vfx_preview_effect = null
	vfx_v2_preview_effect = null

func _on_vfx_play_pressed() -> void:
	_clear_all_preview_nodes()
	if vfx_select == null:
		return
	var target := Vector3(0.0, 0.18, 0.0)
	match vfx_select.get_selected_id():
		0:
			var lightning := VFX_LIGHTNING_ARC.new()
			lightning.name = "PreviewLightningArc"
			vfx_preview_root.add_child(lightning)
			vfx_preview_effect = lightning
			lightning.play_arc(Vector3(0.0, 4.25, 0.0), target)
			vfx_status_label.text = "Playing: Lightning Arc"
		1:
			var ball := VFX_LIGHTNING_BALL.new()
			ball.name = "PreviewLightningBall"
			vfx_preview_root.add_child(ball)
			vfx_preview_effect = ball
			ball.play_ball(Vector3(-1.15, 0.0, 0.0), target)
			vfx_status_label.text = "Playing: Lightning Ball"
		2:
			_play_preview_impact(target)
		3:
			var shockwave := VFX_SHOCKWAVE.new()
			shockwave.name = "PreviewShockwave"
			vfx_preview_root.add_child(shockwave)
			vfx_preview_effect = shockwave
			shockwave.play_shockwave(target, Color(1.0, 0.28, 0.06))
			vfx_status_label.text = "Playing: Shockwave"
		4:
			var smoke := VFX_SMOKE_BURST.new()
			smoke.name = "PreviewSmokeBurst"
			vfx_preview_root.add_child(smoke)
			vfx_preview_effect = smoke
			smoke.play_smoke(target, Color(0.22, 0.26, 0.32))
			vfx_status_label.text = "Playing: Smoke Burst"
		5:
			var particles := VFX_MASKED_PARTICLE.new()
			particles.name = "PreviewMaskedParticle"
			vfx_preview_root.add_child(particles)
			vfx_preview_effect = particles
			particles.play_burst(target, Color(0.30, 0.84, 1.0), 18, 3.0, 0.48)
			vfx_status_label.text = "Playing: Module Masked Particle"
		6:
			var ribbon := VFX_RIBBON_TRAIL.new()
			ribbon.name = "PreviewRibbonTrail"
			vfx_preview_root.add_child(ribbon)
			vfx_preview_effect = ribbon
			ribbon.play_trail(target + Vector3(0.72, 0.44, 0.0), Vector3.RIGHT, Color(0.20, 0.72, 1.0), 1.25, 0.90)
			vfx_status_label.text = "Playing: Module Ribbon Trail"
		7:
			var flash := VFX_IMPACT_FLASH.new()
			flash.name = "PreviewImpactFlash"
			vfx_preview_root.add_child(flash)
			vfx_preview_effect = flash
			flash.play_flash(target, Color(1.0, 0.44, 0.08), 1.25, 0.46)
			vfx_status_label.text = "Playing: Module Impact Flash"
		8:
			var debris := VFX_DEBRIS_BURST.new()
			debris.name = "PreviewDebrisBurst"
			vfx_preview_root.add_child(debris)
			vfx_preview_effect = debris
			debris.play_profile(PROFILE_DEBRIS, {"target": target})
			vfx_status_label.text = "Playing: Layered Debris Burst profile"
		9:
			var residue := VFX_GROUND_RESIDUE.new()
			residue.name = "PreviewGroundResidue"
			vfx_preview_root.add_child(residue)
			vfx_preview_effect = residue
			residue.play_residue(target, Color(0.20, 0.68, 1.0), 1.35, 1.25)
			vfx_status_label.text = "Playing: Module Ground Residue"
		10:
			var layered_wave := VFX_LAYERED_SHOCKWAVE.new()
			vfx_preview_root.add_child(layered_wave)
			vfx_preview_effect = layered_wave
			layered_wave.play_profile(PROFILE_SHOCKWAVE, {"target": target})
			vfx_status_label.text = "Playing: Layered Shockwave profile"
		11:
			var flipbook := VFX_SPRITE_FLIPBOOK.new()
			vfx_preview_root.add_child(flipbook)
			vfx_preview_effect = flipbook
			flipbook.play_profile(PROFILE_FLIPBOOK, {"target": target})
			vfx_status_label.text = "Playing: Sprite Flipbook profile"
		12:
			var shape := VFX_SHAPE_DISTORTION.new()
			vfx_preview_root.add_child(shape)
			vfx_preview_effect = shape
			shape.play_profile(PROFILE_DISTORTION, {"target": target, "direction": Vector3.RIGHT})
			vfx_status_label.text = "Playing: Shape Distortion profile"
		13:
			var burst := VFX_DIRECTIONAL_BURST.new()
			vfx_preview_root.add_child(burst)
			vfx_preview_effect = burst
			burst.play_profile(PROFILE_DIRECTIONAL, {"target": target, "direction": Vector3.RIGHT})
			vfx_status_label.text = "Playing: Directional Burst profile"
		14:
			var pulse := VFX_LIGHT_PULSE.new()
			vfx_preview_root.add_child(pulse)
			vfx_preview_effect = pulse
			pulse.play_profile(PROFILE_LIGHT, {"target": target})
			vfx_status_label.text = "Playing: Light Pulse profile"
		15:
			var feedback := VFX_CAMERA_FEEDBACK.new()
			vfx_preview_root.add_child(feedback)
			vfx_preview_effect = feedback
			feedback.play_profile(PROFILE_CAMERA, {"camera": camera})
			vfx_status_label.text = "Playing: Camera Feedback profile"
		16:
			var hit_stop := VFX_HIT_STOP.new()
			vfx_preview_root.add_child(hit_stop)
			vfx_preview_effect = hit_stop
			hit_stop.play_profile(PROFILE_HIT_STOP, {})
			vfx_status_label.text = "Playing: Preview-only Hit Stop profile"
		17:
			var path_ribbon := VFX_PATH_RIBBON.new()
			path_ribbon.name = "PreviewPathRibbon"
			vfx_preview_root.add_child(path_ribbon)
			vfx_preview_effect = path_ribbon
			var path_points := PackedVector3Array()
			for i in range(21):
				var t := float(i) / 20.0
				path_points.append(target + Vector3(lerpf(-1.2, 1.15, t), 0.42 + sin(t * PI) * 0.78 + sin(t * PI * 3.0) * 0.04, 0.0))
			path_ribbon.play_path(path_points, Vector3.FORWARD, PROFILE_PATH_RIBBON)
			vfx_status_label.text = "Playing: Path Ribbon profile"
		18:
			var slash_arc := VFX_SLASH_ARC.new()
			slash_arc.name = "PreviewSlashArc"
			vfx_preview_root.add_child(slash_arc)
			vfx_preview_effect = slash_arc
			slash_arc.play_profile(PROFILE_SLASH_ARC, {"target": target + Vector3(0.0, 0.32, 0.0), "direction": Vector3.RIGHT})
			vfx_status_label.text = "Playing: Heavy Slash Arc profile"
		19:
			var slash_ring := VFX_SLASH_RING.new()
			slash_ring.name = "PreviewSlashRing"
			vfx_preview_root.add_child(slash_ring)
			vfx_preview_effect = slash_ring
			slash_ring.play_profile(PROFILE_SLASH_RING, {"target": target})
			vfx_status_label.text = "Playing: Boss Slash Ring profile"
		20, 21:
			var composition := VFX_COMPOSITION.new()
			composition.name = "PreviewFullStagesComposition"
			vfx_preview_root.add_child(composition)
			vfx_preview_effect = composition
			composition.play_recipe(RECIPE_FULL_STAGES, {"target": target, "direction": Vector3.RIGHT, "camera": camera})
			vfx_status_label.text = "Playing: staggered Timeline + Curve recipe" if vfx_select.get_selected_id() == 20 else "Playing: Full Skill Stages recipe"
		22:
			var energy_burst := VFX_ENERGY_BURST.new()
			energy_burst.name = "PreviewEnergyBurst"
			vfx_preview_root.add_child(energy_burst)
			vfx_preview_effect = energy_burst
			energy_burst.play_profile(PROFILE_ENERGY_BURST, {"target": target, "direction": Vector3.RIGHT})
			vfx_status_label.text = "Playing: Heavy Energy Burst profile"
		23:
			var ground_sigil := VFX_GROUND_SIGIL.new()
			ground_sigil.name = "PreviewGroundSigil"
			vfx_preview_root.add_child(ground_sigil)
			vfx_preview_effect = ground_sigil
			ground_sigil.play_profile(PROFILE_GROUND_SIGIL, {"target": target})
			vfx_status_label.text = "Playing: Arcane Ground Sigil profile"
		24:
			var portal := VFX_PORTAL.new()
			portal.name = "PreviewPortal"
			vfx_preview_root.add_child(portal)
			vfx_preview_effect = portal
			portal.play_profile(PROFILE_PORTAL, {"target": target})
			vfx_status_label.text = "Playing: Verdant Portal profile"
		25:
			var projectile_3d := VFX_PROJECTILE_3D.new()
			projectile_3d.name = "PreviewProjectile3D"
			vfx_preview_root.add_child(projectile_3d)
			vfx_preview_effect = projectile_3d
			projectile_3d.play_profile(PROFILE_PROJECTILE_3D, {"origin": Vector3(-0.52, 0.72, 0.0), "target": Vector3(1.25, 0.48, 0.0)})
			vfx_status_label.text = "Playing: Layered Fire Projectile profile"
		26:
			var meteor_strike := VFX_METEOR_STRIKE.new()
			meteor_strike.name = "PreviewMeteorStrike"
			vfx_preview_root.add_child(meteor_strike)
			vfx_preview_effect = meteor_strike
			meteor_strike.play_profile(PROFILE_METEOR_STRIKE, {"target": Vector3(1.25, 0.18, 0.0)})
			vfx_status_label.text = "Playing: Meteor Strike profile"
		27:
			var barrier_shield := VFX_BARRIER_SHIELD.new()
			barrier_shield.name = "PreviewBarrierShield"
			vfx_preview_root.add_child(barrier_shield)
			vfx_preview_effect = barrier_shield
			barrier_shield.play_profile(PROFILE_BARRIER_SHIELD, {"target": Vector3(-0.52, 0.18, 0.0)})
			vfx_status_label.text = "Playing: Broken Arc Barrier profile"
		28:
			var falling_pillar := VFX_FALLING_PILLAR.new()
			falling_pillar.name = "PreviewFallingPillar"
			vfx_preview_root.add_child(falling_pillar)
			vfx_preview_effect = falling_pillar
			falling_pillar.play_profile(PROFILE_FALLING_PILLAR, {"target": Vector3(1.25, 0.18, 0.0)})
			vfx_status_label.text = "Playing: Falling Pillar profile"
		29:
			var roar_cone := VFX_ROAR_CONE.new()
			roar_cone.name = "PreviewRoarCone"
			vfx_preview_root.add_child(roar_cone)
			vfx_preview_effect = roar_cone
			roar_cone.play_profile(PROFILE_ROAR_CONE, {"origin": Vector3(-0.52, 0.62, 0.0), "target": Vector3(1.25, 0.46, 0.0)})
			vfx_status_label.text = "Playing: Directional Roar Cone profile"
		30:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("apocalypse_charge", Vector3(-.52,.18,0), Vector3(-.52,.18,0))
			await get_tree().create_timer(1.95).timeout
			if is_instance_valid(boss_fx): boss_fx.play_skill("apocalypse_complete", Vector3(-.52,.18,0), Vector3(1.25,.18,0), {"targets":[Vector3(1.25,.18,0)]})
			vfx_status_label.text = "Playing: Apocalypse charge and lane-local verdict"
		31:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("element_meteor", Vector3(-.52,.18,0), Vector3(1.25,.18,0))
			vfx_status_label.text = "Playing: Element Meteor composite"
		32:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("overload_counter", left_slot.position, right_slot.position, {"target_node": right_slot})
			vfx_status_label.text = "Playing: Thunder overload counter composite"
		33:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("mirror_spawn", Vector3(-.52,.18,0), Vector3(-.52,.18,0))
			await get_tree().create_timer(.45).timeout
			if is_instance_valid(boss_fx): boss_fx.play_skill("mirror_slash", Vector3(-.52,.40,0), Vector3(1.25,.22,0))
			vfx_status_label.text = "Playing: Mirror spawn and target slash"
		34:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("holy_purify", Vector3(-.52,.18,0), Vector3(-.52,.18,0), {"targets":[Vector3(-.52,.18,0),Vector3(-1.15,.18,0)]})
			vfx_status_label.text = "Playing: Holy purify ally layers"
		35:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("rage_milestone", Vector3(-.52,.18,0), Vector3(1.25,.18,0), {"stacks":10})
			vfx_status_label.text = "Playing: Rage milestone roar"
		36:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("blood_rage", Vector3(-.52,.18,0), Vector3(-.52,.18,0))
			await get_tree().create_timer(.34).timeout
			if is_instance_valid(boss_fx): boss_fx.play_skill("blood_lifesteal", Vector3(-.52,.18,0), Vector3(1.25,.18,0))
			vfx_status_label.text = "Playing: Blood rage and lifesteal return"
		37:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("soul_devour", Vector3(-.52,.18,0), Vector3(1.25,.18,0))
			vfx_status_label.text = "Playing: Soul fragment victim to Boss"
		38:
			var boss_fx := _boss_composer_preview()
			boss_fx.play_skill("twin_timer", Vector3(-.52,.18,0), Vector3(1.25,.18,0))
			await get_tree().create_timer(1.2).timeout
			if is_instance_valid(boss_fx): boss_fx.play_skill("twin_revive", Vector3(-.52,.18,0), Vector3(-.52,.18,0))
			vfx_status_label.text = "Playing: Twin timer, link and revive"
		39:
			var moving_ball := VFX_LIGHTNING_BALL.new()
			moving_ball.name = "MovingTargetLightningBall"
			vfx_preview_root.add_child(moving_ball)
			vfx_preview_effect = moving_ball
			moving_ball.play_ball(left_slot.position, right_slot.position, right_slot)
			vfx_status_label.text = "Playing: exact moving model target tracking"
		40:
			var status_fx := VFX_STATUS_EFFECT.new()
			status_fx.name = "PreviewStatusEffect"
			vfx_preview_root.add_child(status_fx)
			vfx_preview_effect = status_fx
			status_fx.play_profile(PROFILE_STATUS_STUN, {"target": left_slot.position, "target_node": left_slot})
			vfx_status_label.text = "Playing: persistent upper-body Stun status profile"
		41:
			var silence_status := VFX_STATUS_EFFECT.new()
			silence_status.name = "PreviewSilenceStatus"
			vfx_preview_root.add_child(silence_status)
			vfx_preview_effect = silence_status
			var silence_profile := PROFILE_STATUS_STUN.duplicate_runtime()
			silence_profile.parameters = {"status_type":"silence"}
			silence_profile.size = .82
			silence_profile.duration = 3.0
			silence_status.play_profile(silence_profile, {"target":right_slot.position, "target_node":right_slot})
			vfx_status_label.text = "Playing: readable Silence emblem"
		42:
			var poison_status := VFX_STATUS_EFFECT.new()
			poison_status.name = "PreviewPoisonStatus"
			vfx_preview_root.add_child(poison_status)
			vfx_preview_effect = poison_status
			var poison_profile := PROFILE_STATUS_STUN.duplicate_runtime()
			poison_profile.parameters = {"status_type":"poison"}
			poison_profile.size = .82
			poison_profile.duration = 3.0
			poison_status.play_profile(poison_profile, {"target":right_slot.position, "target_node":right_slot})
			vfx_status_label.text = "Playing: readable Poison emblem"
		43:
			var link_fx := VFX_TRACKED_LINK.new()
			link_fx.name = "PreviewTrackedLink"
			vfx_preview_root.add_child(link_fx)
			vfx_preview_effect = link_fx
			link_fx.play_profile(PROFILE_TRACKED_LINK, {"origin": left_slot.position, "target": right_slot.position, "origin_node": left_slot, "target_node": right_slot})
			vfx_status_label.text = "Playing: dynamic two-target Tracked Link profile"
		44:
			var vortex_fx := VFX_VORTEX_FIELD.new()
			vortex_fx.name = "PreviewVortexField"
			vfx_preview_root.add_child(vortex_fx)
			vfx_preview_effect = vortex_fx
			vortex_fx.play_profile(PROFILE_VORTEX_SHADOW, {"target": right_slot.position})
			vfx_status_label.text = "Playing: layered Shadow Vortex Field profile"
		45:
			var summon_fx := VFX_SUMMON_SPAWN.new()
			summon_fx.name = "PreviewSummonSpawn"
			vfx_preview_root.add_child(summon_fx)
			vfx_preview_effect = summon_fx
			summon_fx.play_profile(PROFILE_SUMMON_SPAWN, {"target": target})
			vfx_status_label.text = "Playing: staged Summon Spawn profile"
		46:
			var dash_fx := VFX_AFTERIMAGE_DASH.new()
			dash_fx.name = "PreviewAfterimageDash"
			vfx_preview_root.add_child(dash_fx)
			vfx_preview_effect = dash_fx
			dash_fx.play_profile(PROFILE_AFTERIMAGE_DASH, {"origin": left_slot.position + Vector3(0.0, 0.22, 0.0), "target": right_slot.position + Vector3(0.0, 0.22, 0.0)})
			vfx_status_label.text = "Playing: directional Afterimage Dash profile"
		47:_preview_race_basic(PROFILE_BASIC_GOD,"god","ranged")
		48:_preview_race_basic(PROFILE_BASIC_GOD,"god","melee")
		49:_preview_race_basic(PROFILE_BASIC_HUMAN,"human","ranged")
		50:_preview_race_basic(PROFILE_BASIC_HUMAN,"human","melee")
		51:_preview_race_basic(PROFILE_BASIC_DARK,"dark","ranged")
		52:_preview_race_basic(PROFILE_BASIC_DARK,"dark","melee")
		53:_preview_race_basic(PROFILE_BASIC_UNDEAD,"undead","ranged")
		54:_preview_race_basic(PROFILE_BASIC_UNDEAD,"undead","melee")
		55:
			var silence_fx:=UNIT_SKILL_COMPOSER.new()
			silence_fx.name="PreviewSilenceBolt"
			vfx_preview_root.add_child(silence_fx)
			vfx_preview_effect=silence_fx
			silence_fx.play_skill("silence_bolt",left_slot.position+Vector3(0.0,.18,0.0),right_slot.position+Vector3(0.0,.18,0.0),{"target_node":right_slot})
			vfx_status_label.text="Playing: Shadow Mage Silence Bolt"
		56:
			var poison_fx:=UNIT_SKILL_COMPOSER.new()
			poison_fx.name="PreviewPoisonDart"
			vfx_preview_root.add_child(poison_fx)
			vfx_preview_effect=poison_fx
			poison_fx.play_skill("poison_attack",left_slot.position+Vector3(0.0,.18,0.0),right_slot.position+Vector3(0.0,.18,0.0),{"target_node":right_slot})
			vfx_status_label.text="Playing: Undead Poison Dart"
		57:
			var mother_fx:=VFX_MOTHER_EXECUTE.new();mother_fx.name="PreviewMotherExecute";vfx_preview_root.add_child(mother_fx);vfx_preview_effect=mother_fx
			mother_fx.play_profile(PROFILE_MOTHER_EXECUTE,{"origin":left_slot.position,"target":right_slot.position,"origin_node":left_slot,"target_node":right_slot})
			vfx_status_label.text="Playing: Mother book and victim soul devour"
		58:
			var stun_fx:=UNIT_SKILL_COMPOSER.new();stun_fx.name="PreviewStunHit";vfx_preview_root.add_child(stun_fx);vfx_preview_effect=stun_fx
			stun_fx.play_skill("stun",left_slot.position+Vector3(0.0,.22,0.0),right_slot.position+Vector3(0.0,.22,0.0),{"target_node":right_slot})
			vfx_status_label.text="Playing: readable Stun Hit + status emblem"
		59:
			var attribute_fx:=UNIT_SKILL_COMPOSER.new();attribute_fx.name="PreviewAttributeBolt";vfx_preview_root.add_child(attribute_fx);vfx_preview_effect=attribute_fx
			attribute_fx.play_skill("random_attribute_bolt",left_slot.position+Vector3(0.0,.30,0.0),right_slot.position+Vector3(0.0,.30,0.0),{"target_node":right_slot,"attribute":"fire"})
			vfx_status_label.text="Playing: authored Attribute Bolt"

func _preview_race_basic(profile:VFXProfile3D,race:String,mode:String)->void:
	var fx:=VFX_RACE_BASIC_ATTACK.new();fx.name="PreviewBasic_%s_%s"%[race,mode];vfx_preview_root.add_child(fx);vfx_preview_effect=fx
	fx.play_profile(profile,{"origin":left_slot.position+Vector3(0.0,.62,0.0),"target":right_slot.position+Vector3(0.0,.34,0.0),"target_node":right_slot,"race":race,"mode":mode})
	vfx_status_label.text="Playing: %s %s basic attack"%[race,mode]

func _boss_composer_preview() -> BossSkillVFXComposer3D:
	var boss_fx := BOSS_SKILL_COMPOSER.new()
	boss_fx.name = "PreviewBossSkillComposer"
	vfx_preview_root.add_child(boss_fx)
	vfx_preview_effect = boss_fx
	return boss_fx

func _play_preview_impact(target: Vector3) -> void:
	var root := Node3D.new()
	root.name = "PreviewTargetImpact"
	vfx_preview_root.add_child(root)
	vfx_preview_effect = root
	var core := VFX_TARGET_IMPACT.make(Color(1.0, 0.48, 0.10), 1.05)
	core.position = target + Vector3(0.0, 0.035, 0.0)
	core.scale = Vector3.ONE * 0.35
	root.add_child(core)
	var sparks := VFX_TARGET_IMPACT.burst(Color(1.0, 0.62, 0.16), 28, 3.5, 0.42)
	sparks.position = target + Vector3(0.0, 0.12, 0.0)
	root.add_child(sparks)
	var tween := root.create_tween()
	tween.set_parallel(true)
	tween.tween_property(core, "scale", Vector3.ONE * 1.55, 0.42)
	tween.tween_property(core.material_override, "shader_parameter/progress", 1.0, 0.42)
	tween.chain().tween_callback(root.queue_free)
	vfx_status_label.text = "Playing: Target Impact Burst"

func _on_vfx_clear_pressed() -> void:
	_clear_vfx_preview()
	if vfx_status_label != null:
		vfx_status_label.text = "VFX cleared"

func _on_vfx_auto_pressed() -> void:
	auto_fight_enabled = not auto_fight_enabled
	if vfx_status_label != null:
		vfx_status_label.text = "Auto Fight: %s" % ("ON" if auto_fight_enabled else "OFF")

func _on_vfx_pause_pressed() -> void:
	if vfx_recorder != null:
		var is_paused := vfx_recorder.toggle_pause()
		vfx_status_label.text = "VFX preview paused" if is_paused else "VFX preview resumed"

func _on_vfx_step_pressed() -> void:
	if vfx_recorder != null:
		vfx_recorder.step_frame()
		vfx_status_label.text = "Advanced one rendered frame"

func _on_vfx_quarter_speed_pressed() -> void:
	_set_vfx_preview_speed(0.25)

func _on_vfx_half_speed_pressed() -> void:
	_set_vfx_preview_speed(0.5)

func _on_vfx_normal_speed_pressed() -> void:
	_set_vfx_preview_speed(1.0)

func _set_vfx_preview_speed(speed: float) -> void:
	if vfx_recorder != null:
		vfx_recorder.set_playback_speed(speed)
		vfx_status_label.text = "VFX preview speed: %.2fx" % speed

func _on_vfx_screenshot_pressed() -> void:
	if vfx_recorder == null:
		return
	var path := await vfx_recorder.capture_now(get_viewport(), "vfx_manual")
	vfx_status_label.text = "Saved: %s" % ProjectSettings.globalize_path(path) if not path.is_empty() else "Screenshot failed"

func _on_vfx_fixed_screenshot_pressed() -> void:
	if vfx_recorder == null:
		return
	var path := await vfx_recorder.capture_at_time(get_viewport(), 0.5, "vfx_050")
	vfx_status_label.text = "Saved fixed-time shot: %s" % ProjectSettings.globalize_path(path) if not path.is_empty() else "Screenshot failed"

func _on_vfx_validate_pressed() -> void:
	var recipe: Resource = RECIPE_FULL_STAGES if vfx_select != null and vfx_select.get_selected_id() >= 17 else null
	var report := VFX_VALIDATION.validate(vfx_preview_effect, recipe)
	var warnings: PackedStringArray = report.get("warnings", PackedStringArray())
	if warnings.is_empty():
		vfx_status_label.text = "Validation PASS | layers %d | particles %d" % [report.visual_layers, report.particles]
	else:
		vfx_status_label.text = "Validation: %s" % " | ".join(warnings)

func _clear_vfx_preview() -> void:
	_clear_all_preview_nodes()
	if vfx_recorder != null:
		vfx_recorder.restore_normal_speed()

func _on_boss_stage_pressed() -> void:
	var entry := _find_formation_ally_entry()
	if entry.is_empty():
		if vfx_status_label != null:
			vfx_status_label.text = "BossStage: formation_allies.json 里没有可用模型"
		return
	_clear_vfx_preview()
	_clear_boss_stage()
	_apply_board_texture(FINAL_ROUND_BOARD)
	auto_fight_enabled = false
	_update_auto_button()
	boss_stage_active = true
	_clear_slot(left_slot)
	_clear_slot(right_slot)
	units.clear()
	phase_time = 0.0
	last_cycle = -1
	last_attack_cycle = -1
	hit_flash.visible = false
	boss_stage_root = Node3D.new()
	boss_stage_root.name = "BossStageSummon"
	$Stage.add_child(boss_stage_root)
	# Place both slots before spawning so _spawn_unit's look_at faces them at each other.
	left_slot.position = Vector3(float(SIDE_LEFT) * BOSS_STAGE_SLOT_X, 0.0, 0.0)
	right_slot.position = Vector3(float(SIDE_RIGHT) * BOSS_STAGE_SLOT_X, 0.0, 0.0)
	# Two circles side by side on the final-round board: A on the red half, B on the blue half.
	_begin_formation_summon(left_slot, entry, SIDE_LEFT, PROFILE_SUMMON_TEAM_A)
	_begin_formation_summon(right_slot, entry, SIDE_RIGHT, PROFILE_SUMMON_TEAM_B)
	preview_names = "BossStage 法阵召唤：%s（体型 %.0fx）" % [str(entry.get("name", "法阵友军")), boss_stage_scale]
	_frame_preview_camera()
	_update_label()
	if vfx_status_label != null:
		vfx_status_label.text = "BossStage: A/B 双阵同时召唤，体型 %.0fx" % boss_stage_scale

# Spawns the unit hidden below its resting spot; VFXSummonSpawn3D fires
# reveal_requested at the moment the column and smoke are thickest.
func _begin_formation_summon(slot: Node3D, entry: Dictionary, side: int, profile: VFXProfile3D) -> void:
	var before := units.size()
	_spawn_unit(slot, entry, side)
	if units.size() <= before:
		return
	var unit: Dictionary = units[units.size() - 1]
	unit["base_pos"] = Vector3(float(side) * BOSS_STAGE_SLOT_X, 0.0, 0.0)
	slot.position = unit["base_pos"]
	slot.scale = Vector3.ONE * boss_stage_scale
	var runtime: VFXProfile3D = profile.duplicate_runtime()
	var model := unit.get("model") as Node3D
	if model != null:
		runtime.size = _summon_size_for(model)
		unit["boss_stage_rest_y"] = model.position.y
		# Divide by slot scale so the visual rise stays constant in world units.
		model.position.y -= BOSS_STAGE_RISE / maxf(boss_stage_scale, 0.01)
		model.visible = false
	var fx: Node3D = VFX_SUMMON_SPAWN.new()
	fx.name = "FormationSummon_%s" % ("A" if side == SIDE_LEFT else "B")
	boss_stage_root.add_child(fx)
	fx.reveal_requested.connect(_on_formation_reveal.bind(unit))
	fx.play_summon(slot.position, runtime)

func _on_formation_reveal(unit: Dictionary) -> void:
	var model := unit.get("model") as Node3D
	if model == null or not is_instance_valid(model):
		return
	model.visible = true
	_play_unit_action(unit, "idle", true)
	# EASE_IN_OUT keeps the model low for the first half of the rise, so it stays buried
	# in the core glow instead of shooting straight up into plain view.
	var rise := create_tween()
	rise.tween_property(model, "position:y", float(unit.get("boss_stage_rest_y", 0.0)), BOSS_STAGE_RISE_TIME).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

# The column has to be wider and taller than the unit, otherwise the model pops
# into view outside the light and the whole occlusion trick falls apart.
func _summon_size_for(model: Node3D) -> float:
	var bounds: AABB = _node_bounds_relative(model, $Stage)
	if bounds.size == Vector3.ZERO:
		return 1.25
	var width: float = maxf(bounds.size.x, bounds.size.z)
	return maxf(maxf(width * 0.92, bounds.size.y * 0.98), 0.7)

func _on_boss_stage_scale_pressed() -> void:
	boss_stage_scale = 2.0 if is_equal_approx(boss_stage_scale, 1.0) else 1.0
	if boss_stage_scale_button != null:
		boss_stage_scale_button.text = "体型 %.0fx" % boss_stage_scale
	if boss_stage_active:
		_on_boss_stage_pressed()
	elif vfx_status_label != null:
		vfx_status_label.text = "BossStage 体型：%.0fx（按 BossStage 播放）" % boss_stage_scale

func _on_boss_stage_reset_pressed() -> void:
	_clear_boss_stage()
	_apply_board_texture(board_default_texture)
	auto_fight_enabled = true
	_update_auto_button()
	_load_selected_pair()
	if vfx_status_label != null:
		vfx_status_label.text = "已还原普通预览战场"

func _clear_boss_stage() -> void:
	boss_stage_active = false
	if boss_stage_root != null and is_instance_valid(boss_stage_root):
		boss_stage_root.queue_free()
	boss_stage_root = null
	left_slot.scale = Vector3.ONE
	right_slot.scale = Vector3.ONE

func _apply_board_texture(texture: Texture2D) -> void:
	var floor_node := $Stage/Floor as MeshInstance3D
	if floor_node == null:
		return
	var material := floor_node.material_override as StandardMaterial3D
	if material == null:
		return
	if board_default_texture == null:
		board_default_texture = material.albedo_texture
	if texture != null:
		material.albedo_texture = texture

func _formation_ally_entries() -> Array:
	var result: Array = []
	for value in model_entries:
		var entry: Dictionary = value
		if str(entry.get("source", "")) == FORMATION_SOURCE_TAG and str(entry.get("model", "")).begins_with("res://"):
			result.append(entry)
	return result

func _find_formation_ally_entry() -> Dictionary:
	var allies := _formation_ally_entries()
	if allies.is_empty():
		return {}
	return allies[boss_stage_ally_index % allies.size()]

func _on_boss_stage_ally_pressed() -> void:
	var allies := _formation_ally_entries()
	if allies.is_empty():
		return
	boss_stage_ally_index = (boss_stage_ally_index + 1) % allies.size()
	var entry: Dictionary = allies[boss_stage_ally_index]
	if boss_stage_ally_button != null:
		boss_stage_ally_button.text = "友军 %d/%d" % [boss_stage_ally_index + 1, allies.size()]
	if boss_stage_active:
		_on_boss_stage_pressed()
	elif vfx_status_label != null:
		vfx_status_label.text = "法阵友军：%s（按 BossStage 播放）" % str(entry.get("name", ""))

func _add_button(parent: Control, text: String, callable: Callable) -> Button:
	var button := Button.new()
	button.text = text
	button.focus_mode = Control.FOCUS_NONE
	button.pressed.connect(callable)
	parent.add_child(button)
	return button

func _load_model_entries() -> Array:
	var result: Array = []
	_append_entries_from_json(result, UNIT_DATA_PATH, "units", "棋子")
	_append_entries_from_json(result, MONSTER_DATA_PATH, "monsters", "怪物")
	_append_entries_from_json(result, MERCENARY_DATA_PATH, "mercenaries", "佣兵", true)
	_append_entries_from_json(result, BOSS_DATA_PATH, "bosses", "Boss", true)
	_append_entries_from_json(result, FORMATION_BOSS_DATA_PATH, "allies", "法阵Boss", true)
	if result.is_empty():
		result = FALLBACK_MODELS.duplicate(true)
	for i in range(result.size()):
		var entry: Dictionary = result[i]
		var model_path := str(entry.get("model", ""))
		var model_state := "" if model_path.begins_with("res://") else "｜未接入模型"
		var variant_text := str(entry.get("preview_variant", ""))
		var variant_suffix := " [%s]" % variant_text if not variant_text.is_empty() else ""
		entry["display_name"] = "%s｜%s%s (%s)%s" % [str(entry.get("source", "模型")), str(entry.get("name", "未命名")), variant_suffix, str(entry.get("id", "no_id")), model_state]
		result[i] = entry
	return result

func _append_entries_from_json(result: Array, path: String, list_key: String, source: String, include_without_model: bool = false) -> void:
	if not FileAccess.file_exists(path):
		return
	var text := FileAccess.get_file_as_string(path)
	var parsed: Variant = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	var root: Dictionary = parsed
	var list_value: Variant = root.get(list_key, [])
	if typeof(list_value) != TYPE_ARRAY:
		return
	var list: Array = list_value
	for value in list:
		if typeof(value) != TYPE_DICTIONARY:
			continue
		var entry: Dictionary = value.duplicate(true)
		var variants_value: Variant = entry.get("model_by_element", {})
		if typeof(variants_value) == TYPE_DICTIONARY and not (variants_value as Dictionary).is_empty():
			var variants: Dictionary = variants_value
			for element_key in variants.keys():
				var variant_entry := entry.duplicate(true)
				variant_entry["model"] = str(variants[element_key])
				variant_entry["element"] = str(element_key)
				variant_entry["preview_variant"] = _element_display_name(str(element_key))
				variant_entry["source"] = source
				result.append(variant_entry)
			continue
		var model_path := str(entry.get("model", ""))
		if not include_without_model and not model_path.begins_with("res://"):
			continue
		entry["source"] = source
		result.append(entry)

func _element_display_name(element: String) -> String:
	match element:
		"land":
			return "地"
		"sky":
			return "天"
		_:
			return element

func _populate_model_selects() -> void:
	left_model_select.clear()
	right_model_select.clear()
	for i in range(model_entries.size()):
		var entry: Dictionary = model_entries[i]
		var label := str(entry.get("display_name", entry.get("name", "模型")))
		left_model_select.add_item(label, i)
		right_model_select.add_item(label, i)

func _select_default_models() -> void:
	selected_left_index = _find_entry_index("god_guard", 0)
	selected_right_index = _find_entry_index("dark_imp", 1 if model_entries.size() > 1 else 0)
	if selected_left_index == selected_right_index and model_entries.size() > 1:
		selected_right_index = 1 if selected_left_index != 1 else 0
	left_model_select.select(selected_left_index)
	right_model_select.select(selected_right_index)

func _find_entry_index(id: String, fallback: int) -> int:
	for i in range(model_entries.size()):
		var entry: Dictionary = model_entries[i]
		if str(entry.get("id", "")) == id:
			return i
	return clampi(fallback, 0, maxi(model_entries.size() - 1, 0))

func _load_random_pair() -> void:
	if model_entries.size() < 2:
		return
	selected_left_index = rng.randi_range(0, model_entries.size() - 1)
	selected_right_index = rng.randi_range(0, model_entries.size() - 1)
	while selected_right_index == selected_left_index and model_entries.size() > 1:
		selected_right_index = rng.randi_range(0, model_entries.size() - 1)
	left_model_select.select(selected_left_index)
	right_model_select.select(selected_right_index)
	_load_selected_pair()

func _load_selected_pair() -> void:
	_clear_all_preview_nodes()
	_clear_boss_stage()
	_clear_slot(left_slot)
	_clear_slot(right_slot)
	units.clear()
	phase_time = 0.0
	last_cycle = -1
	last_attack_cycle = -1
	hit_flash.visible = false
	left_slot.position = Vector3(-1.35, 0.0, float(SIDE_LEFT) * SPAWN_DEPTH)
	right_slot.position = Vector3(1.35, 0.0, float(SIDE_RIGHT) * SPAWN_DEPTH)
	if model_entries.is_empty():
		_update_label()
		return
	var left_entry: Dictionary = model_entries[selected_left_index]
	var right_entry: Dictionary = model_entries[selected_right_index]
	_spawn_unit(left_slot, left_entry, SIDE_LEFT)
	_spawn_unit(right_slot, right_entry, SIDE_RIGHT)
	preview_names = "%s  vs  %s" % [str(left_entry.get("name", "模型A")), str(right_entry.get("name", "模型B"))]
	_frame_preview_camera()
	_update_label()

func _spawn_unit(slot: Node3D, entry: Dictionary, side: int) -> void:
	var path := str(entry.get("model", ""))
	if not path.begins_with("res://"):
		units.append(_make_missing_unit(slot, entry, side, "尚未在数据表配置模型资源"))
		return
	if not ResourceLoader.exists(path):
		units.append(_make_missing_unit(slot, entry, side, "模型路径不存在"))
		return
	var scene := ResourceLoader.load(path) as PackedScene
	if scene == null:
		units.append(_make_missing_unit(slot, entry, side, "模型加载失败"))
		return
	var model := scene.instantiate() as Node3D
	if model == null:
		units.append(_make_missing_unit(slot, entry, side, "实例不是 Node3D"))
		return
	slot.add_child(model)
	_cleanup_imported_preview_visuals(model)
	model.position = Vector3.ZERO
	model.rotation_degrees = Vector3(0.0, float(entry.get("model_base_yaw", 180.0)), 0.0)
	model.scale = Vector3.ONE * float(entry.get("model_visual_scale", 1.0))
	_fit_model_to_slot(model)

	var target := right_slot.global_position if side < 0 else left_slot.global_position
	slot.look_at(Vector3(target.x, slot.global_position.y, target.z), Vector3.UP)
	var player := _find_animation_player(model)
	var animations := _animation_list(player)
	var actions := {
		"idle": _resolve_action_animation(player, entry, "idle", ["idle", "Idle", "mixamo_com", "breath", "stand"]),
		"attack": _resolve_action_animation(player, entry, "attack", ["attack", "Attack", "punch", "Punch", "slash", "Slash", "hit", "Hit"]),
		"run": _resolve_action_animation(player, entry, "run", ["run", "Run", "walk", "Walk", "running", "Running"])
	}
	_mark_script_action_methods(model, actions)
	var unit := {
		"slot": slot,
		"model": model,
		"base_pos": Vector3(slot.position.x, slot.position.y, float(side) * SPAWN_DEPTH),
		"side": side,
		"name": str(entry.get("name", "模型")),
		"id": str(entry.get("id", "")),
		"source": str(entry.get("source", "")),
		"skill_id": str(entry.get("skill_id", "none")),
		"path": path,
		"player": player,
		"animations": animations,
		"actions": actions,
		"current_action": "idle",
		"load_note": ""
	}
	units.append(unit)
	slot.position = unit["base_pos"]
	_play_unit_action(unit, "idle", false)

func _make_missing_unit(slot: Node3D, entry: Dictionary, side: int, note: String) -> Dictionary:
	return {
		"slot": slot,
		"model": null,
		"base_pos": slot.position,
		"side": side,
		"name": str(entry.get("name", "模型")),
		"id": str(entry.get("id", "")),
		"source": str(entry.get("source", "")),
		"skill_id": str(entry.get("skill_id", "none")),
		"path": str(entry.get("model", "")),
		"player": null,
		"animations": [],
		"actions": {"idle": "", "attack": "", "run": ""},
		"current_action": "missing",
		"load_note": note
	}

func _resolve_action_animation(player: AnimationPlayer, entry: Dictionary, action: String, candidates: Array) -> String:
	if player == null:
		return ""
	var explicit_key := "model_%s_animation_name" % action
	var explicit_name := str(entry.get(explicit_key, ""))
	if not explicit_name.is_empty() and player.has_animation(explicit_name):
		return explicit_name
	for candidate in candidates:
		var name := str(candidate)
		if player.has_animation(name):
			return name
	for anim in player.get_animation_list():
		var lower := String(anim).to_lower()
		for candidate in candidates:
			if lower.contains(str(candidate).to_lower()):
				return String(anim)
	return ""

func _animation_list(player: AnimationPlayer) -> Array:
	var result: Array = []
	if player == null:
		return result
	for anim in player.get_animation_list():
		result.append(String(anim))
	return result

func _play_action_for_side(action: String, side: int, manual: bool) -> void:
	if manual:
		auto_fight_enabled = false
		_update_auto_button()
	for unit in units:
		if side == SIDE_BOTH or int(unit.get("side", 0)) == side:
			_play_unit_action(unit, action, true)
	_update_label()

func _play_unit_action(unit: Dictionary, action: String, restart: bool) -> void:
	unit["current_action"] = action
	var model := unit.get("model") as Node
	var method_name := _action_method_name(action)
	if model != null and model.has_method(method_name):
		model.call(method_name)
		unit["last_method_call"] = method_name
		unit["wrapper_current_action"] = _wrapper_current_action(model)
		unit["visible_action_nodes"] = _visible_action_nodes(model)
		return
	var player := unit.get("player") as AnimationPlayer
	var actions: Dictionary = unit.get("actions", {})
	var animation_name := str(actions.get(action, ""))
	if player == null or animation_name.is_empty() or not player.has_animation(animation_name):
		return
	if restart:
		player.stop()
	player.play(animation_name)
	if action == "attack":
		player.seek(0.0, true)
		player.advance(0.001)

func _mark_script_action_methods(model: Node, actions: Dictionary) -> void:
	if model == null:
		return
	for action in ["idle", "attack", "run"]:
		var method_name := _action_method_name(action)
		if model.has_method(method_name):
			actions[action] = "%s()" % method_name

func _action_method_name(action: String) -> String:
	match action:
		"idle":
			return "play_idle"
		"attack":
			return "play_attack"
		"run":
			return "play_run"
		_:
			return ""
func _frame_preview_camera() -> void:
	var bounds: AABB = _combined_unit_bounds()
	if bounds.size == Vector3.ZERO:
		camera_target = Vector3(0.0, 0.68, 0.0)
		camera_height = 5.4
		camera_distance = 8.4
		camera_yaw_deg = 0.0
		camera_fov = 7.2
		_apply_preview_camera()
		return
	var center: Vector3 = bounds.get_center()
	var width: float = maxf(bounds.size.x, bounds.size.z) + CAMERA_FRAME_MARGIN
	var height: float = bounds.size.y + CAMERA_FRAME_MARGIN * 0.5
	var frame_size: float = maxf(width, height * 1.55)
	var target_y: float = maxf(center.y + height * 0.02, 0.58)
	camera_target = Vector3(center.x, target_y, center.z)
	camera_height = maxf(CAMERA_MIN_HEIGHT, 4.6 + frame_size * 0.16)
	camera_distance = maxf(CAMERA_MIN_DISTANCE, 6.8 + frame_size * 0.28)
	camera_yaw_deg = 0.0
	camera_fov = 7.2
	_apply_preview_camera()

func _apply_preview_camera() -> void:
	camera_height = clampf(camera_height, 0.35, 18.0)
	camera_distance = clampf(camera_distance, 1.0, 30.0)
	if camera.projection == Camera3D.PROJECTION_ORTHOGONAL:
		camera_fov = clampf(camera_fov, 5.8, 12.0)
		camera.size = camera_fov
	else:
		camera_fov = clampf(camera_fov, 18.0, 85.0)
	var yaw_basis := Basis(Vector3.UP, deg_to_rad(camera_yaw_deg))
	var offset: Vector3 = yaw_basis * Vector3(0.0, camera_height, camera_distance)
	camera.fov = camera_fov
	camera.global_position = camera_target + offset
	camera.look_at(camera_target, Vector3.UP)
	_ensure_preview_camera_current()

func _update_camera_controls(delta: float) -> void:
	var changed := false
	var distance_step: float = 4.0 * delta
	var height_step: float = 3.0 * delta
	var yaw_step: float = 68.0 * delta
	var fov_step: float = 28.0 * delta
	if Input.is_key_pressed(KEY_W):
		camera_distance -= distance_step
		changed = true
	if Input.is_key_pressed(KEY_S):
		camera_distance += distance_step
		changed = true
	if Input.is_key_pressed(KEY_Q):
		camera_height -= height_step
		changed = true
	if Input.is_key_pressed(KEY_E):
		camera_height += height_step
		changed = true
	if Input.is_key_pressed(KEY_A):
		camera_yaw_deg += yaw_step
		changed = true
	if Input.is_key_pressed(KEY_D):
		camera_yaw_deg -= yaw_step
		changed = true
	if Input.is_key_pressed(KEY_Z):
		camera_fov -= fov_step
		changed = true
	if Input.is_key_pressed(KEY_X):
		camera_fov += fov_step
		changed = true
	if changed:
		camera_yaw_deg = wrapf(camera_yaw_deg, -180.0, 180.0)
		_apply_preview_camera()
		_update_label()

func _ensure_preview_camera_current() -> void:
	if camera == null:
		return
	var active_camera: Camera3D = get_viewport().get_camera_3d()
	if active_camera != camera:
		camera.make_current()

func _combined_unit_bounds() -> AABB:
	var has_bounds := false
	var combined := AABB()
	for unit in units:
		var model := unit.get("model") as Node3D
		if model == null:
			continue
		var bounds: AABB = _node_bounds_relative(model, self)
		if bounds.size == Vector3.ZERO:
			continue
		if not has_bounds:
			combined = bounds
			has_bounds = true
		else:
			combined = combined.merge(bounds)
	return combined if has_bounds else AABB()

func _clear_slot(slot: Node) -> void:
	for child in slot.get_children():
		child.queue_free()

func _animate_units() -> void:
	if boss_stage_active:
		return
	var cycle_pos: float = fmod(phase_time, ATTACK_PERIOD)
	var walk_t: float = clampf(cycle_pos / WALK_IN_TIME, 0.0, 1.0)
	walk_t = walk_t * walk_t * (3.0 - 2.0 * walk_t)
	var attack_t: float = clampf((cycle_pos - WALK_IN_TIME) / ATTACK_WINDOW, 0.0, 1.0)
	var in_attack: bool = auto_fight_enabled and cycle_pos >= WALK_IN_TIME and cycle_pos <= WALK_IN_TIME + ATTACK_WINDOW
	for unit in units:
		var slot := unit.get("slot") as Node3D
		if slot == null:
			continue
		var base_pos: Vector3 = unit.get("base_pos", Vector3.ZERO)
		var side: int = int(unit.get("side", 1))
		var action := str(unit.get("current_action", "idle"))
		var bob: float = sin(phase_time * TAU * 0.9) * 0.035
		var engage_pos := Vector3(base_pos.x, base_pos.y, float(side) * ENGAGE_DEPTH)
		var current_base := base_pos
		if auto_fight_enabled:
			current_base = base_pos.lerp(engage_pos, walk_t)
		var lunge: float = 0.0
		if in_attack or action == "attack":
			lunge = sin(attack_t * PI) * 0.46
		elif action == "run":
			lunge = sin(phase_time * TAU * 0.85) * 0.12
		slot.position = current_base + Vector3(0.0, bob, float(-side) * lunge)

func _update_hit_flash() -> void:
	if boss_stage_active:
		hit_flash.visible = false
		return
	var show_flash := false
	if auto_fight_enabled:
		var cycle_pos: float = fmod(phase_time, ATTACK_PERIOD)
		var hit_t: float = absf(cycle_pos - (WALK_IN_TIME + ATTACK_WINDOW * 0.52))
		show_flash = hit_t < 0.08
		if show_flash:
			var pulse: float = 1.0 - hit_t / 0.08
			hit_flash.scale = Vector3.ONE * lerpf(0.18, 0.52, pulse)
	else:
		for unit in units:
			if str(unit.get("current_action", "")) == "attack":
				show_flash = true
				break
		if show_flash:
			hit_flash.scale = Vector3.ONE * 0.32
	hit_flash.visible = show_flash

func _update_label() -> void:
	var left_text := _unit_debug_text(SIDE_LEFT)
	var right_text := _unit_debug_text(SIDE_RIGHT)
	info_label.text = "%s\n%s\n%s\n镜头 W/S 远近  Q/E 高低  A/D 左右旋转  Z/X FOV  鼠标滚轮缩放  右键拖拽旋转/高低  H 重置\n动作快捷键：1 Idle  2 Attack  3 Run  Space Attack  R 随机  Esc 退出\n自动战斗：%s  高度 %.2f  距离 %.2f  旋转 %.0f  FOV %.0f" % [preview_names, left_text, right_text, "ON" if auto_fight_enabled else "OFF", camera_height, camera_distance, camera_yaw_deg, camera_fov]

func _unit_debug_text(side: int) -> String:
	var unit: Dictionary = _unit_for_side(side)
	if unit.is_empty():
		return "%s：未加载" % ("左" if side == SIDE_LEFT else "右")
	var actions: Dictionary = unit.get("actions", {})
	var animations: Array = unit.get("animations", [])
	var anim_text := ", ".join(animations) if not animations.is_empty() else "无 AnimationPlayer / 无动画"
	var note := str(unit.get("load_note", ""))
	var prefix := "左" if side == SIDE_LEFT else "右"
	var action_text := "idle=%s  attack=%s  run=%s" % [_fmt_action(actions.get("idle", "")), _fmt_action(actions.get("attack", "")), _fmt_action(actions.get("run", ""))]
	var base := "%s：%s [%s/%s] 当前=%s | %s | 动画列表：%s" % [prefix, str(unit.get("name", "模型")), str(unit.get("source", "")), str(unit.get("id", "")), str(unit.get("current_action", "")), action_text, anim_text]
	var model := unit.get("model") as Node
	if model != null and _supports_action_methods(model):
		base += " | wrapper当前=%s 可见=%s 最近调用=%s" % [str(unit.get("wrapper_current_action", _wrapper_current_action(model))), str(unit.get("visible_action_nodes", _visible_action_nodes(model))), str(unit.get("last_method_call", "无"))]
	if not note.is_empty():
		base += " | " + note
	return base

func _supports_action_methods(model: Node) -> bool:
	return model.has_method("play_idle") or model.has_method("play_attack") or model.has_method("play_run")

func _wrapper_current_action(model: Node) -> String:
	var value: Variant = model.get("current_action")
	return str(value) if value != null else "未知"

func _visible_action_nodes(model: Node) -> String:
	var visible_names: Array[String] = []
	var stack: Array[Node] = [model]
	while not stack.is_empty():
		var node: Node = stack.pop_back()
		if node != model and node is Node3D and (node as Node3D).visible:
			var name_text := str(node.name)
			if name_text.ends_with("_model"):
				visible_names.append(name_text)
		for child in node.get_children():
			stack.append(child)
	return ",".join(visible_names) if not visible_names.is_empty() else "无"
func _fmt_action(value: Variant) -> String:
	var text := str(value)
	return text if not text.is_empty() else "缺失"

func _unit_for_side(side: int) -> Dictionary:
	for unit in units:
		if int(unit.get("side", 0)) == side:
			return unit
	return {}

func _find_animation_player(root: Node) -> AnimationPlayer:
	if root is AnimationPlayer:
		return root as AnimationPlayer
	for child in root.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null

func _fit_model_to_slot(model: Node3D) -> void:
	var bounds: AABB = _node_bounds_relative(model, model)
	if bounds.size == Vector3.ZERO:
		return
	var height: float = maxf(bounds.size.y, 0.001)
	var width: float = maxf(maxf(bounds.size.x, bounds.size.z), 0.001)
	var fit_scale: float = minf(TARGET_HEIGHT / height, TARGET_WIDTH / width)
	model.scale *= fit_scale
	bounds = _node_bounds_relative(model, model)
	var center: Vector3 = bounds.get_center()
	model.position -= Vector3(center.x, bounds.position.y, center.z)

func _node_bounds_relative(root: Node3D, relative_to: Node3D) -> AABB:
	var has_bounds := false
	var bounds := AABB()
	var to_relative := relative_to.global_transform.affine_inverse()
	var stack: Array[Node] = [root]
	while not stack.is_empty():
		var node: Node = stack.pop_back()
		if node is MeshInstance3D:
			var mesh_node := node as MeshInstance3D
			var aabb := mesh_node.get_aabb()
			var points := [
				aabb.position,
				aabb.position + Vector3(aabb.size.x, 0.0, 0.0),
				aabb.position + Vector3(0.0, aabb.size.y, 0.0),
				aabb.position + Vector3(0.0, 0.0, aabb.size.z),
				aabb.position + Vector3(aabb.size.x, aabb.size.y, 0.0),
				aabb.position + Vector3(aabb.size.x, 0.0, aabb.size.z),
				aabb.position + Vector3(0.0, aabb.size.y, aabb.size.z),
				aabb.position + aabb.size
			]
			for p in points:
				var rel_point: Vector3 = to_relative * (mesh_node.global_transform * p)
				if not has_bounds:
					bounds = AABB(rel_point, Vector3.ZERO)
					has_bounds = true
				else:
					bounds = bounds.expand(rel_point)
		for child in node.get_children():
			stack.append(child)
	return bounds if has_bounds else AABB()

func _cleanup_imported_preview_visuals(root: Node) -> void:
	var stack: Array[Node] = [root]
	while not stack.is_empty():
		var node: Node = stack.pop_back()
		for child in node.get_children():
			stack.append(child)
		if node is Light3D or node is Camera3D:
			node.queue_free()

func _update_auto_button() -> void:
	if auto_button != null:
		auto_button.text = "自动战斗 ON" if auto_fight_enabled else "自动战斗 OFF"

func _on_left_model_selected(index: int) -> void:
	selected_left_index = index
	_load_selected_pair()

func _on_right_model_selected(index: int) -> void:
	selected_right_index = index
	_load_selected_pair()

func _on_left_idle_pressed() -> void:
	_play_action_for_side("idle", SIDE_LEFT, true)

func _on_left_attack_pressed() -> void:
	_play_action_for_side("attack", SIDE_LEFT, true)

func _on_left_run_pressed() -> void:
	_play_action_for_side("run", SIDE_LEFT, true)

func _on_right_idle_pressed() -> void:
	_play_action_for_side("idle", SIDE_RIGHT, true)

func _on_right_attack_pressed() -> void:
	_play_action_for_side("attack", SIDE_RIGHT, true)

func _on_right_run_pressed() -> void:
	_play_action_for_side("run", SIDE_RIGHT, true)

func _on_both_idle_pressed() -> void:
	_play_action_for_side("idle", SIDE_BOTH, true)

func _on_both_attack_pressed() -> void:
	_play_action_for_side("attack", SIDE_BOTH, true)

func _on_both_run_pressed() -> void:
	_play_action_for_side("run", SIDE_BOTH, true)

func _on_random_pressed() -> void:
	_load_random_pair()

func _on_auto_fight_pressed() -> void:
	_clear_all_preview_nodes()
	auto_fight_enabled = not auto_fight_enabled
	_update_auto_button()
	if auto_fight_enabled:
		phase_time = 0.0
		last_cycle = -1
		last_attack_cycle = -1
	else:
		_play_action_for_side("idle", SIDE_BOTH, false)
	_update_label()

func _on_skill_pressed() -> void:
	# Preview-only trigger: it does not alter simulation state or cooldowns.
	# Fire each selected unit's authored skill at the opposing preview slot.
	_clear_all_preview_nodes()
	var fired:=[]
	for unit in units:
		var skill_id:=str(unit.get("skill_id", "none"))
		if skill_id.is_empty() or skill_id=="none":
			continue
		var slot:=unit.get("slot") as Node3D
		if slot==null:
			continue
		var side:=int(unit.get("side", SIDE_LEFT))
		var target_slot:=right_slot if side==SIDE_LEFT else left_slot
		if target_slot==null:
			continue
		var origin:=slot.global_position+Vector3(0.0,.24,0.0)
		var target:=target_slot.global_position+Vector3(0.0,.24,0.0)
		var context:={"target_node":target_slot,"origin_node":slot}
		context["source_unit_id"]=str(unit.get("id",""))
		context["target_unit_id"]=str((right_slot if side==SIDE_LEFT else left_slot).name)
		context["targets"]=[target]
		context["heal_target"]=origin
		var composer:=UNIT_SKILL_COMPOSER.new()
		composer.name="PreviewSkill_%s_%s"%[skill_id,str(unit.get("id","unit"))]
		vfx_preview_root.add_child(composer)
		composer.play_skill(skill_id,origin,target,context)
		fired.append(str(unit.get("name",skill_id))+" → "+skill_id)
	if fired.is_empty():
		vfx_status_label.text="Skill: 当前模型没有配置可预览技能"
	else:
		vfx_status_label.text="Skill Preview: "+" | ".join(fired)
