extends "res://scenes/battle/BattleUI.gd"

const BossProceduralVFX3D := preload("res://effects/BossProceduralVFX3D.gd")

const FIRE_GLOW_TEXTURE_PATH := "res://assets/vfx/battlefield/fire_glow_soft.png"
const FIRE_SPARK_TEXTURE_PATH := "res://assets/vfx/battlefield/fire_spark_dot.png"
const BATTLE_2_5D_BASE_PATH := "res://assets/board/2_5d/battlefield_jungle_pve.png"
const BATTLE_2_5D_PVP_BASE_PATH := "res://assets/board/2_5d/battlefield_snow_pvp.png"
const BATTLE_2_5D_FINAL_BASE_PATH := "res://assets/board/2_5d/battlefield_final_round.png"
const BATTLE_2_5D_FRONT_PATH := "res://assets/board/2_5d/battlefield_front_occlusion_full.png"
const BATTLE_2_5D_FIRE_PATH := "res://assets/board/2_5d/fire_single_source.png"
const FIRE_FLAME_SOURCE_RECT := Rect2(555.0, 20.0, 125.0, 120.0)
const FIRE_FLAME_POINTS := [Vector2(526.0, 82.0), Vector2(1162.0, 82.0)]
const BATTLE_PVP_BACKGROUND_SCALE := 1.0
const BATTLE_VISUAL_SPACE_SCALE := 0.88
const BATTLE_VISUAL_DOWN_SHIFT_RATIO := 0.1
const BLUE_CRYSTAL_MODEL_PATH := "res://assets/models/battle_crystals/blue/Meshy_AI_Blue_Crystal_Spire_0717152101_texture_fbx/Meshy_AI_Blue_Crystal_Spire_0717152101_texture.fbx"
const RED_CRYSTAL_MODEL_PATH := "res://assets/models/battle_crystals/red/Meshy_AI_Crimson_Prism_0717152324_texture_fbx/Meshy_AI_Crimson_Prism_0717152324_texture.fbx"
const BATTLE_CRYSTAL_TARGET_HEIGHT := 1.55
const BATTLE_CRYSTAL_BLUE_POSITION := Vector3(0.0, -0.14, -5.55)
const BATTLE_CRYSTAL_RED_POSITION := Vector3(0.0, -0.14, 5.55)
const CRYSTAL_GLOW_POINTS := [
	Vector3(165.0, 155.0, 1.0),
	Vector3(1505.0, 155.0, 1.0),
]

var _3v3_lines: Array[CPUParticles2D] = []
var _3v3_line_cores: Array[Line2D] = []
var _battlefield_2_5d_root: Node2D
var _battlefield_2_5d_size := Vector2(1672.0, 941.0)
var _looping_tweens: Array[Tween] = []

func _exit_tree() -> void:
	# Infinite set_loops() tweens must be killed explicitly so none survive
	# the battle scene and keep ticking in the tween manager.
	for tween in _looping_tweens:
		if tween != null and tween.is_valid():
			tween.kill()
	_looping_tweens.clear()

func _build() -> void:
	if _battle_arena_ready:
		return
	_battle_arena_ready = true
	var screen_bg := ColorRect.new()
	screen_bg.color = Color(0.018, 0.026, 0.022)
	screen_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(screen_bg)
	screen_bg.z_index = -20

	# Arena fills the entire screen (full-screen battlefield).
	var arena_wrap := Control.new()
	arena_wrap.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	arena_wrap.clip_contents = true
	add_child(arena_wrap)
	_arena = arena_wrap

	_add_layered_battle_background(arena_wrap)

	var arena_tint := ColorRect.new()
	var battlefield_kind := _battlefield_kind()
	if battlefield_kind == "final":
		arena_tint.color = Color(0.055, 0.035, 0.060, 0.08)
	elif battlefield_kind == "pvp":
		arena_tint.color = Color(0.045, 0.070, 0.110, 0.08)
	else:
		arena_tint.color = Color(0.012, 0.030, 0.022, 0.08)
	arena_tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	arena_wrap.add_child(arena_tint)
	arena_tint.z_index = -10

	_add_battle_grid_overlay(arena_wrap)

	_setup_battle_3d_view(arena_wrap)
	_add_battle_3v3_dividers(arena_wrap)
	_add_result_overlay(arena_wrap)

	# Title / state / summary kept alive (other code updates their text) but hidden.
	_title_lbl = Label.new()
	_title_lbl.visible = false
	add_child(_title_lbl)

	_battle_state_lbl = Label.new()
	_battle_state_lbl.visible = false
	add_child(_battle_state_lbl)

	_summary_lbl = RichTextLabel.new()
	_summary_lbl.bbcode_enabled = true
	_summary_lbl.fit_content = true
	_summary_lbl.visible = false
	add_child(_summary_lbl)

	# (8) Live "top ATK" leaderboard on the left-middle: top 5 units by attack,
	# each name in its owner/team color, plus its dealt damage.
	_top5_atk_lbl = RichTextLabel.new()
	_top5_atk_lbl.bbcode_enabled = true
	_top5_atk_lbl.fit_content = true
	_top5_atk_lbl.scroll_active = false
	_top5_atk_lbl.anchor_left = 0.0
	_top5_atk_lbl.anchor_right = 0.0
	_top5_atk_lbl.anchor_top = 0.5
	_top5_atk_lbl.anchor_bottom = 0.5
	_top5_atk_lbl.offset_left = 12
	_top5_atk_lbl.offset_right = 232
	_top5_atk_lbl.offset_top = -96
	_top5_atk_lbl.offset_bottom = 96
	_top5_atk_lbl.add_theme_font_size_override("normal_font_size", 15)
	_top5_atk_lbl.add_theme_font_size_override("bold_font_size", 16)
	_top5_atk_lbl.add_theme_color_override("default_color", Color(0.95, 0.95, 0.98))
	_top5_atk_lbl.add_theme_constant_override("outline_size", 4)
	_top5_atk_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.92))
	_top5_atk_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_top5_atk_lbl.z_index = 90
	add_child(_top5_atk_lbl)

	# Floating skip button (top-right corner, above the full-screen arena).
	var skip := Button.new()
	skip.text = tr("battle_skip")
	skip.custom_minimum_size = Vector2(120, 36)
	skip.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	skip.offset_left = -136
	skip.offset_top = 12
	skip.offset_right = -16
	skip.offset_bottom = 48
	skip.pressed.connect(_skip_animation)
	add_child(skip)
	skip.z_index = 100

	if GameState.team_mode:
		var team_hp_lbl := Label.new()
		team_hp_lbl.text = tr("battle_team_hp") % [GameState.team_hp, GameState.START_FORMATION_HP]
		team_hp_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
		team_hp_lbl.offset_left = -150
		team_hp_lbl.offset_right = 150
		team_hp_lbl.offset_top = 10
		team_hp_lbl.offset_bottom = 42
		team_hp_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		team_hp_lbl.add_theme_font_size_override("font_size", 22)
		team_hp_lbl.add_theme_color_override("font_color", Color(0.5, 1.0, 0.62))
		team_hp_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
		team_hp_lbl.add_theme_constant_override("outline_size", 4)
		team_hp_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		team_hp_lbl.z_index = 100
		add_child(team_hp_lbl)

const BATTLE_3V3_BOUNDS := [1.0 / 3.0, 2.0 / 3.0]


func _add_layered_battle_background(arena_wrap: Control) -> void:
	if BATTLE_USE_3D_ARENA:
		return
	_battlefield_2_5d_root = Node2D.new()
	_battlefield_2_5d_root.name = "Battlefield2_5D"
	arena_wrap.add_child(_battlefield_2_5d_root)
	_add_battlefield_sprite("BaseBackground", _battlefield_base_path(), 0)
	_fit_battlefield_2_5d()
	arena_wrap.resized.connect(_fit_battlefield_2_5d)


func _battlefield_kind() -> String:
	var kind := str(_state.get("kind", _kind))
	# 3v3 组队：首次 _build() 时服务器 replay 还没到，_state 为空、_kind 只是 "team"，
	# 拿不到真实回合类型。_build() 只建一次（有 _battle_arena_ready 守卫），所以必须在
	# 这里用赛程表提前判断真实回合类型，确保 PVE、PVP 和 final 各自使用正确战场。
	if kind == "team" or kind == "":
		kind = RoundService.schedule_kind_for_round(GameState.round_index)
	return kind


func _uses_pvp_battlefield() -> bool:
	return _battlefield_kind() == "pvp"


func _battlefield_base_path() -> String:
	match _battlefield_kind():
		"final":
			return BATTLE_2_5D_FINAL_BASE_PATH
		"pvp":
			return BATTLE_2_5D_PVP_BASE_PATH
		_:
			return BATTLE_2_5D_BASE_PATH

func _add_battlefield_sprite(sprite_name: String, texture_path: String, layer_z: int) -> Sprite2D:
	var sprite := Sprite2D.new()
	sprite.name = sprite_name
	sprite.texture = load(texture_path) as Texture2D
	if sprite_name == "BaseBackground" and sprite.texture != null:
		_battlefield_2_5d_size = Vector2(sprite.texture.get_width(), sprite.texture.get_height())
	sprite.centered = false
	sprite.position = Vector2.ZERO
	sprite.z_index = layer_z
	_battlefield_2_5d_root.add_child(sprite)
	return sprite


func _fit_battlefield_2_5d() -> void:
	if _battlefield_2_5d_root == null or _arena == null:
		return
	var arena_size := _arena.size
	if arena_size.x <= 0.0 or arena_size.y <= 0.0:
		return
	var fit_scale := maxf(arena_size.x / _battlefield_2_5d_size.x, arena_size.y / _battlefield_2_5d_size.y)
	if _battlefield_kind() == "pvp":
		fit_scale *= BATTLE_PVP_BACKGROUND_SCALE
	_battlefield_2_5d_root.scale = Vector2.ONE * fit_scale
	_battlefield_2_5d_root.position = (arena_size - _battlefield_2_5d_size * fit_scale) * 0.5


func _add_fire_layer() -> void:
	var texture := load(BATTLE_2_5D_FIRE_PATH) as Texture2D
	if texture == null:
		return
	var fire_scale := Vector2(
		_battlefield_2_5d_size.x / float(texture.get_width()),
		_battlefield_2_5d_size.y / float(texture.get_height())
	)
	var flame_size := FIRE_FLAME_SOURCE_RECT.size * fire_scale
	for i in FIRE_FLAME_POINTS.size():
		var flame := Sprite2D.new()
		flame.name = "FireEffects%d" % i
		flame.texture = texture
		flame.region_enabled = true
		flame.region_rect = FIRE_FLAME_SOURCE_RECT
		flame.centered = false
		flame.position = FIRE_FLAME_POINTS[i] - flame_size * 0.5
		flame.scale = fire_scale
		flame.z_index = 25
		_battlefield_2_5d_root.add_child(flame)
		var tween := flame.create_tween()
		_looping_tweens.append(tween)
		tween.set_loops()
		tween.tween_property(flame, "modulate:a", 0.72, 0.22 + float(i) * 0.03)
		tween.parallel().tween_property(flame, "scale", fire_scale * 1.04, 0.22 + float(i) * 0.03)
		tween.tween_property(flame, "modulate:a", 1.0, 0.28 + float(i) * 0.03)
		tween.parallel().tween_property(flame, "scale", fire_scale, 0.28 + float(i) * 0.03)
	for point in FIRE_FLAME_POINTS:
		_add_fire_spark_particles(point)


func _add_fire_spark_particles(point: Vector2) -> void:
	var sparks := GPUParticles2D.new()
	sparks.name = "FireSparks"
	sparks.position = point
	sparks.z_index = 26
	sparks.amount = 10
	sparks.lifetime = 0.75
	sparks.preprocess = 0.75
	sparks.texture = load(FIRE_SPARK_TEXTURE_PATH) as Texture2D
	var material := ParticleProcessMaterial.new()
	material.direction = Vector3(0.0, -1.0, 0.0)
	material.spread = 22.0
	material.gravity = Vector3(0.0, -24.0, 0.0)
	material.initial_velocity_min = 12.0
	material.initial_velocity_max = 34.0
	material.scale_min = 0.18
	material.scale_max = 0.38
	material.color = Color(1.0, 0.62, 0.14, 0.75)
	sparks.process_material = material
	_battlefield_2_5d_root.add_child(sparks)


func _add_crystal_glows() -> void:
	for i in CRYSTAL_GLOW_POINTS.size():
		var data: Vector3 = CRYSTAL_GLOW_POINTS[i]
		_add_crystal_particles(Vector2(data.x, data.y), data.z, i)


func _add_crystal_particles(point: Vector2, size_mul: float, index: int) -> void:
	var particles := GPUParticles2D.new()
	particles.name = "CrystalGlow%d" % index
	particles.position = point
	particles.z_index = 22
	particles.amount = int(26.0 * size_mul)
	particles.lifetime = 1.4
	particles.preprocess = 1.4
	particles.texture = load(FIRE_SPARK_TEXTURE_PATH) as Texture2D
	var add_mat := CanvasItemMaterial.new()
	add_mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	particles.material = add_mat
	var material := ParticleProcessMaterial.new()
	material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_SPHERE
	material.emission_sphere_radius = 28.0 * size_mul
	material.spread = 180.0
	material.gravity = Vector3.ZERO
	material.initial_velocity_min = 2.0
	material.initial_velocity_max = 10.0
	material.scale_min = 0.18 * size_mul
	material.scale_max = 0.52 * size_mul
	material.color = Color(0.25, 0.85, 1.0, 0.58)
	particles.process_material = material
	_battlefield_2_5d_root.add_child(particles)
	var tween := particles.create_tween()
	_looping_tweens.append(tween)
	tween.set_loops()
	tween.tween_property(particles, "modulate:a", 0.95, 0.9 + float(index) * 0.05)
	tween.tween_property(particles, "modulate:a", 0.38, 1.0 + float(index) * 0.05)


func _add_front_occlusion() -> void:
	for offset in [Vector2(-2.0, 0.0), Vector2(2.0, 0.0), Vector2(0.0, -2.0), Vector2(0.0, 2.0)]:
		_add_front_copy("FrontOcclusionOutline", offset, 58, Color(0.0, 0.0, 0.0, 0.46))
	_add_battlefield_sprite("FrontOcclusion", BATTLE_2_5D_FRONT_PATH, 60)


func _add_front_copy(sprite_name: String, offset: Vector2, layer_z: int, color: Color) -> void:
	var sprite := _add_battlefield_sprite(sprite_name, BATTLE_2_5D_FRONT_PATH, layer_z)
	sprite.position = offset
	sprite.modulate = color


func _add_battle_3v3_dividers(arena_wrap: Control) -> void:
	# Two particle streams split the standable field into 3 equal columns.
	_3v3_lines.clear()
	_3v3_line_cores.clear()
	for _i in BATTLE_3V3_BOUNDS.size():
		var core := Line2D.new()
		core.name = "Battle3v3DividerCore"
		core.width = 2
		core.default_color = Color(0.72, 0.94, 1.0, 0.12)
		core.z_index = 0
		arena_wrap.add_child(core)
		_3v3_line_cores.append(core)

		var glow := CPUParticles2D.new()
		glow.name = "Battle3v3DividerGlow"
		glow.amount = 58
		glow.lifetime = 2.0
		glow.preprocess = 1.0
		glow.texture = _make_battle_soft_dot_texture()
		glow.emission_shape = CPUParticles2D.EMISSION_SHAPE_POINTS
		glow.direction = Vector2(0.0, -1.0)
		glow.spread = 28.0
		glow.gravity = Vector2(0.0, -14.0)
		glow.initial_velocity_min = 4.0
		glow.initial_velocity_max = 13.0
		glow.scale_amount_min = 0.20
		glow.scale_amount_max = 0.58
		glow.color = Color(0.62, 0.88, 1.0, 0.72)
		var ramp := Gradient.new()
		ramp.offsets = PackedFloat32Array([0.0, 0.36, 1.0])
		ramp.colors = PackedColorArray([
			Color(0.45, 0.72, 1.0, 0.0),
			Color(0.78, 0.96, 1.0, 0.95),
			Color(0.40, 0.66, 1.0, 0.0),
		])
		glow.color_ramp = ramp
		var cmat := CanvasItemMaterial.new()
		cmat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		glow.material = cmat
		glow.z_index = 40
		arena_wrap.add_child(glow)
		_3v3_lines.append(glow)

func _make_battle_soft_dot_texture() -> ImageTexture:
	var s := 32
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	var c := Vector2(float(s) * 0.5, float(s) * 0.5)
	for y in s:
		for x in s:
			var d := Vector2(float(x) + 0.5, float(y) + 0.5).distance_to(c) / (float(s) * 0.5)
			var a := clampf(1.0 - d, 0.0, 1.0)
			img.set_pixel(x, y, Color(1.0, 1.0, 1.0, a * a))
	return ImageTexture.create_from_image(img)

func _update_3v3_dividers() -> void:
	if _3v3_lines.is_empty() or _arena == null or _battle_3d_camera == null:
		return
	var visual_min := _battle_visual_min()
	var visual_max := _battle_visual_max()
	var x0 := visual_min.x
	var x1 := visual_max.x
	for i in _3v3_lines.size():
		var sx := lerpf(x0, x1, BATTLE_3V3_BOUNDS[i])
		var p_top := _world_to_arena(_sim_to_world_pos(Vector2(sx, visual_min.y), false))
		var p_bot := _world_to_arena(_sim_to_world_pos(Vector2(sx, visual_max.y), false))
		var top_y := minf(p_top.y, p_bot.y)
		var bot_y := maxf(p_top.y, p_bot.y)
		var mid_x := (p_top.x + p_bot.x) * 0.5
		if i < _3v3_line_cores.size():
			_3v3_line_cores[i].points = PackedVector2Array([
				Vector2(mid_x, top_y),
				Vector2(mid_x, bot_y),
			])
		var glow: CPUParticles2D = _3v3_lines[i]
		glow.position = Vector2.ZERO
		var pts := PackedVector2Array()
		var n := 16
		for j in n:
			var t := float(j) / float(n - 1)
			pts.append(Vector2(mid_x, lerpf(top_y, bot_y, t)))
		glow.emission_points = pts
		glow.emitting = true

func _add_result_overlay(arena_wrap: Control) -> void:
	_result_overlay_lbl = Label.new()
	_result_overlay_lbl.visible = false
	_result_overlay_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_result_overlay_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_result_overlay_lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_result_overlay_lbl.add_theme_font_size_override("font_size", 58)
	_result_overlay_lbl.add_theme_color_override("font_color", Color(1.0, 0.94, 0.62))
	_result_overlay_lbl.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.85))
	_result_overlay_lbl.add_theme_constant_override("shadow_offset_x", 3)
	_result_overlay_lbl.add_theme_constant_override("shadow_offset_y", 3)
	_result_overlay_lbl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_result_overlay_lbl.z_index = 200
	arena_wrap.add_child(_result_overlay_lbl)

func _add_battle_grid_overlay(arena_wrap: Control) -> void:
	# Placement remains grid-based, but the combat arena no longer draws debug lines.
	pass

func _add_battle_3d_arena(world: Node3D) -> void:
	if not BATTLE_USE_3D_ARENA:
		return
	var scene := load(BATTLE_ARENA_MODEL_PATH)
	if scene == null or not (scene is PackedScene):
		push_warning("战斗 3D 场景模型加载失败：%s" % BATTLE_ARENA_MODEL_PATH)
		return
	var arena: Node3D = (scene as PackedScene).instantiate()
	arena.name = "BattleArenaBoard"
	arena.rotation_degrees.y = BATTLE_ARENA_YAW
	world.add_child(arena)
	_fit_battle_3d_arena(arena)
	_apply_forest_arena_style(arena)

func _apply_forest_arena_style(root: Node3D) -> void:
	if not BATTLE_ARENA_FOREST_TINT:
		return
	var stack: Array[Node] = [root]
	while not stack.is_empty():
		var node: Node = stack.pop_back()
		if node is MeshInstance3D:
			var mesh_instance := node as MeshInstance3D
			var mesh := mesh_instance.mesh
			if mesh != null:
				for surface in mesh.get_surface_count():
					var source_mat := mesh_instance.get_surface_override_material(surface)
					if source_mat == null:
						source_mat = mesh.surface_get_material(surface)
					var forest_mat := _forest_material_variant(source_mat)
					if forest_mat != null:
						mesh_instance.set_surface_override_material(surface, forest_mat)
		for child in node.get_children():
			stack.append(child)

func _forest_material_variant(source_mat: Material) -> Material:
	if source_mat == null or not (source_mat is BaseMaterial3D):
		return null
	var src := source_mat as BaseMaterial3D
	var mat := StandardMaterial3D.new()
	mat.albedo_texture = src.albedo_texture
	mat.albedo_color = src.albedo_color.lerp(BATTLE_ARENA_FOREST_ALBEDO, BATTLE_ARENA_FOREST_BLEND)
	mat.diffuse_mode = 3
	mat.specular_mode = 1
	mat.roughness = 1.0
	mat.metallic = 0.0
	mat.transparency = src.transparency
	return mat
func _fit_battle_3d_arena(arena: Node3D) -> void:
	var bounds := _node3d_bounds(arena)
	if bounds.size == Vector3.ZERO:
		return
	var scale_x := BATTLE_ARENA_TARGET_WIDTH / maxf(bounds.size.x, 0.01)
	var scale_z := BATTLE_ARENA_TARGET_DEPTH / maxf(bounds.size.z, 0.01)
	var scale_factor := minf(scale_x, scale_z)
	arena.scale = Vector3.ONE * scale_factor
	var fitted_bounds := _node3d_bounds(arena)
	var center := fitted_bounds.get_center()
	arena.position += Vector3(-center.x, BATTLE_ARENA_GROUND_Y - fitted_bounds.position.y, -center.z)

func _setup_battle_3d_view(arena_wrap: Control) -> void:
	var container := SubViewportContainer.new()
	container.name = "UnitsLayer"
	container.stretch = true
	container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	container.z_index = 40
	arena_wrap.add_child(container)

	_battle_3d_viewport = SubViewport.new()
	_battle_3d_viewport.size = Vector2i(960, 540)
	_battle_3d_viewport.transparent_bg = true
	_battle_3d_viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	container.add_child(_battle_3d_viewport)

	var world := Node3D.new()
	_battle_3d_viewport.add_child(world)
	_add_battle_3d_arena(world)
	_add_battle_crystals(world)
	_battle_3d_root = Node3D.new()
	_battle_3d_root.name = "BattleModelRoot"
	world.add_child(_battle_3d_root)
	_battle_3d_vfx_root = BossProceduralVFX3D.new()
	_battle_3d_vfx_root.name = "BossProceduralVFX3D"
	_battle_3d_root.add_child(_battle_3d_vfx_root)

	var light := DirectionalLight3D.new()
	light.light_color = Color(1.0, 0.84, 0.62)
	light.light_energy = 1.55
	light.rotation_degrees = Vector3(-55, 35, 0)
	world.add_child(light)
	var ambient := WorldEnvironment.new()
	var env := Environment.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.34, 0.42, 0.34)
	env.ambient_light_energy = 0.42
	ambient.environment = env
	world.add_child(ambient)

	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = BATTLE_CAMERA_SIZE
	camera.look_at_from_position(BATTLE_CAMERA_POS, Vector3(0.0, 0.0, 0.0), Vector3.UP)
	camera.current = true
	_battle_3d_camera = camera
	_battle_3d_viewport.add_child(camera)


func _add_battle_crystals(world: Node3D) -> void:
	_add_battle_crystal(world, "BlueCrystal12OClock", BLUE_CRYSTAL_MODEL_PATH, BATTLE_CRYSTAL_BLUE_POSITION, 180.0)
	_add_battle_crystal(world, "RedCrystal6OClock", RED_CRYSTAL_MODEL_PATH, BATTLE_CRYSTAL_RED_POSITION, 0.0)


func _add_battle_crystal(world: Node3D, crystal_name: String, model_path: String, target_position: Vector3, yaw: float) -> void:
	var packed := load(model_path) as PackedScene
	if packed == null:
		push_warning("Battle crystal model failed to load: %s" % model_path)
		return
	var crystal := packed.instantiate() as Node3D
	if crystal == null:
		push_warning("Battle crystal model is not a Node3D: %s" % model_path)
		return
	crystal.name = crystal_name
	world.add_child(crystal)
	_clamp_crystal_material_emission(crystal)
	var bounds := _node3d_bounds(crystal)
	var scale_factor := 1.0
	if bounds.size.y > 0.001:
		scale_factor = BATTLE_CRYSTAL_TARGET_HEIGHT / bounds.size.y
	var base_center := Vector3(
		bounds.position.x + bounds.size.x * 0.5,
		bounds.position.y,
		bounds.position.z + bounds.size.z * 0.5
	)
	crystal.scale = Vector3.ONE * scale_factor
	crystal.rotation_degrees.y = yaw
	var rotated_base_center := Basis(Vector3.UP, deg_to_rad(yaw)) * (base_center * scale_factor)
	crystal.position = target_position - rotated_base_center


func _clamp_crystal_material_emission(root: Node) -> void:
	for child in root.find_children("*", "MeshInstance3D", true, false):
		var mesh_instance := child as MeshInstance3D
		if mesh_instance == null or mesh_instance.mesh == null:
			continue
		var safe_mesh := mesh_instance.mesh.duplicate() as Mesh
		if safe_mesh == null:
			continue
		mesh_instance.mesh = safe_mesh
		for surface_index in safe_mesh.get_surface_count():
			var source_material := safe_mesh.surface_get_material(surface_index)
			if source_material is BaseMaterial3D:
				var safe_material := source_material.duplicate() as BaseMaterial3D
				safe_material.emission_energy_multiplier = minf(safe_material.emission_energy_multiplier, 0.45)
				safe_mesh.surface_set_material(surface_index, safe_material)

func _load_battle_background() -> Texture2D:
	var texture := load(BATTLE_BG_PATH)
	if texture is Texture2D:
		return texture
	var image := Image.new()
	if image.load(BATTLE_BG_PATH) == OK:
		return ImageTexture.create_from_image(image)
	push_warning("战斗背景加载失败：%s" % BATTLE_BG_PATH)
	return null

func _world_to_arena(world_pos: Vector3) -> Vector2:
	if _battle_3d_camera == null or _battle_3d_viewport == null or _arena == null:
		return Vector2.ZERO
	var viewport_pos := _battle_3d_camera.unproject_position(world_pos)
	var viewport_size := Vector2(_battle_3d_viewport.size)
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return viewport_pos
	var arena_size := _arena.size
	if arena_size.x <= 0.0 or arena_size.y <= 0.0:
		arena_size = viewport_size
	return Vector2(
		viewport_pos.x / viewport_size.x * arena_size.x,
		viewport_pos.y / viewport_size.y * arena_size.y
	)

func _sim_to_arena(sim_pos: Vector2) -> Vector2:
	sim_pos = _clamp_visual_sim_pos(sim_pos)
	# Map simulator coordinate space (SIM_W x SIM_H) to actual arena pixel size
	var arena_size := _arena.size
	if arena_size.x <= 0 or arena_size.y <= 0:
		arena_size = Vector2(SIM_W, SIM_H)
	return Vector2(
		sim_pos.x / SIM_W * arena_size.x,
		sim_pos.y / SIM_H * arena_size.y
	)

func _battle_visual_min() -> Vector2:
	return BATTLE_VISUAL_MIN


func _battle_visual_max() -> Vector2:
	return BATTLE_VISUAL_MAX


func _clamp_visual_sim_pos(sim_pos: Vector2) -> Vector2:
	var visual_min := _battle_visual_min()
	var visual_max := _battle_visual_max()
	return Vector2(
		clampf(sim_pos.x, visual_min.x, visual_max.x),
		clampf(sim_pos.y, visual_min.y, visual_max.y)
	)

func _sim_to_world_pos(sim_pos: Vector2, apply_down_shift: bool = true) -> Vector3:
	sim_pos = _clamp_visual_sim_pos(sim_pos)
	var ny := sim_pos.y / SIM_H
	if _arena_flip_y:
		ny = 1.0 - ny
	var x := (sim_pos.x / SIM_W - 0.5) * BATTLE_PLAYABLE_WIDTH * BATTLE_VISUAL_SPACE_SCALE + BATTLE_PLAYABLE_OFFSET.x
	var z := (ny - 0.5) * BATTLE_PLAYABLE_DEPTH * BATTLE_VISUAL_SPACE_SCALE + BATTLE_PLAYABLE_OFFSET.z
	if apply_down_shift:
		z += BATTLE_PLAYABLE_DEPTH * BATTLE_VISUAL_DOWN_SHIFT_RATIO
	return Vector3(x, 0.0, z)

func _node3d_bounds(root: Node3D) -> AABB:
	var bounds := AABB()
	var has_bounds := false
	var stack: Array[Dictionary] = [{"node": root, "transform": Transform3D.IDENTITY}]
	while not stack.is_empty():
		var item: Dictionary = stack.pop_back()
		var node: Node = item.get("node")
		var node_transform: Transform3D = item.get("transform", Transform3D.IDENTITY)
		if node is MeshInstance3D:
			var mesh_node := node as MeshInstance3D
			var mesh_bounds := _transformed_aabb(mesh_node.get_aabb(), node_transform)
			if not has_bounds:
				bounds = mesh_bounds
				has_bounds = true
			else:
				bounds = bounds.merge(mesh_bounds)
		for child in node.get_children():
			var child_transform := node_transform
			if child is Node3D:
				child_transform = node_transform * (child as Node3D).transform
			stack.append({"node": child, "transform": child_transform})
	return bounds if has_bounds else AABB()

func _transformed_aabb(box: AABB, transform: Transform3D) -> AABB:
	if box.size == Vector3.ZERO:
		return box
	var corners := [
		box.position,
		box.position + Vector3(box.size.x, 0, 0),
		box.position + Vector3(0, box.size.y, 0),
		box.position + Vector3(0, 0, box.size.z),
		box.position + Vector3(box.size.x, box.size.y, 0),
		box.position + Vector3(box.size.x, 0, box.size.z),
		box.position + Vector3(0, box.size.y, box.size.z),
		box.position + box.size,
	]
	var out := AABB(transform * corners[0], Vector3.ZERO)
	for i in range(1, corners.size()):
		out = out.expand(transform * corners[i])
	return out
