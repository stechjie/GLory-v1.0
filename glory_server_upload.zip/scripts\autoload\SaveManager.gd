﻿extends Node

const SAVE_PATH := "user://glory_beta_004.save"
const RECONNECT_PATH := "user://glory_reconnect.json"
const PUBLIC_TOKEN_PATH := "user://glory_public_token.txt"
const SAVE_DEBOUNCE_SEC := 0.5

var _save_pending := false

# --- 原子写（C21）------------------------------------------------------------
# `FileAccess.open(path, WRITE)` 会先把目标文件截断成 0 字节再写。进程在这中间被杀
# （手机锁屏后被系统回收、崩溃、玩家强退）就留下空文件或半截 JSON，而读取方拿到坏
# 内容只能当"没有存档"——一次本来可以恢复的断线因此升级成永久丢档。
# 顺序：写临时文件 → flush → 回读校验 → 旧文件转 .bak → 临时文件转正。
# 任何一步失败都保留原文件不动，绝不用半成品覆盖一份好的存档。
const TMP_SUFFIX := ".tmp"
const BAK_SUFFIX := ".bak"

func _atomic_write(path: String, content: String) -> bool:
	var tmp := path + TMP_SUFFIX
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("[SAVE] cannot open temp file: %s" % tmp)
		return false
	f.store_string(content)
	f.flush()
	f = null   # 句柄归零即关闭落盘
	# 回读校验：确认完整落地后才碰正式文件
	if FileAccess.get_file_as_string(tmp) != content:
		push_warning("[SAVE] temp verify failed, keeping previous file: %s" % path)
		DirAccess.remove_absolute(tmp)
		return false
	var bak := path + BAK_SUFFIX
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(bak)
		DirAccess.rename_absolute(path, bak)
	if DirAccess.rename_absolute(tmp, path) != OK:
		# 转正失败：把上一份换回来，宁可回退一步也不留下空档
		if FileAccess.file_exists(bak):
			DirAccess.rename_absolute(bak, path)
		push_warning("[SAVE] atomic rename failed: %s" % path)
		return false
	return true

# 读取时先试正式文件，坏了再试 .bak。返回 "" 表示两份都不可用。
func _read_with_fallback(path: String) -> String:
	for candidate in [path, path + BAK_SUFFIX]:
		if not FileAccess.file_exists(candidate):
			continue
		var text := FileAccess.get_file_as_string(candidate)
		if not text.strip_edges().is_empty():
			return text
	return ""

# 二进制版原子写（服务器房间快照用）。
# 房间数据里有大量 int，走 JSON 会在 parse 时全变成 float，读回来每个字段都得手动
# int() 一遍，漏一个就是静默的类型错误。`var_to_bytes` 保留类型，也更紧凑。
func atomic_write_bytes(path: String, data: PackedByteArray) -> bool:
	var tmp := path + TMP_SUFFIX
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("[SAVE] cannot open temp file: %s" % tmp)
		return false
	f.store_buffer(data)
	f.flush()
	f = null
	if FileAccess.get_file_as_bytes(tmp) != data:
		push_warning("[SAVE] temp verify failed: %s" % path)
		DirAccess.remove_absolute(tmp)
		return false
	var bak := path + BAK_SUFFIX
	if FileAccess.file_exists(path):
		DirAccess.remove_absolute(bak)
		DirAccess.rename_absolute(path, bak)
	if DirAccess.rename_absolute(tmp, path) != OK:
		if FileAccess.file_exists(bak):
			DirAccess.rename_absolute(bak, path)
		push_warning("[SAVE] atomic rename failed: %s" % path)
		return false
	return true

func read_bytes_with_fallback(path: String) -> PackedByteArray:
	for candidate in [path, path + BAK_SUFFIX]:
		if not FileAccess.file_exists(candidate):
			continue
		var data := FileAccess.get_file_as_bytes(candidate)
		if not data.is_empty():
			return data
	return PackedByteArray()

func remove_all_variants(path: String) -> void:
	_remove_all_variants(path)

func _remove_all_variants(path: String) -> void:
	for candidate in [path, path + BAK_SUFFIX, path + TMP_SUFFIX]:
		if FileAccess.file_exists(candidate):
			DirAccess.remove_absolute(candidate)

# --- 断线重连凭证（token + 服务器地址），app 被杀重开后凭它恢复对局 ---
# port 必须一起存（多进程）。座位 token 是**进程内**的字典，连错进程就等于凭证失效。
# 此前只存 address，app 重开时端口被填成 DEFAULT_PORT —— 单进程时碰巧对，
# 多进程时是 (N-1)/N 的概率连错。
func save_reconnect(token: String, address: String, port: int = NetworkConfig.SERVER_PORT) -> void:
	_atomic_write(RECONNECT_PATH, JSON.stringify({"token": token, "address": address, "port": port}))

# 标记"这一局是玩家主动退的，还没拿到服务端回执"（状态信封 E3 / R1）。
# 落盘的意义：进程在发出退出意图后被杀，下次启动能凭它知道**不要提示重连**，
# 并用同一个 request_id 重发 —— 服务端按幂等重放同一份回执。
func mark_pending_leave(request_id: String) -> void:
	var rc := load_reconnect()
	if rc.is_empty():
		return
	rc["pending_leave"] = request_id
	_atomic_write(RECONNECT_PATH, JSON.stringify(rc))

func has_pending_leave() -> bool:
	return not str(load_reconnect().get("pending_leave", "")).is_empty()

func load_reconnect() -> Dictionary:
	var text := _read_with_fallback(RECONNECT_PATH)
	if text.is_empty():
		return {}
	var parsed = JSON.parse_string(text)
	return parsed if typeof(parsed) == TYPE_DICTIONARY else {}

func clear_reconnect() -> void:
	# 凭证作废必须连 .bak/.tmp 一起清，否则下次启动会从兜底文件里把死 token 读回来。
	_remove_all_variants(RECONNECT_PATH)

func save_public_token(token_id: String) -> void:
	_atomic_write(PUBLIC_TOKEN_PATH, token_id.strip_edges().to_upper())

func load_public_token() -> String:
	return _read_with_fallback(PUBLIC_TOKEN_PATH).strip_edges().to_upper()

# 合并短时间内的多次存档请求（拖拽/连买会连续触发 save_run），
# 真正的磁盘写入最多每 SAVE_DEBOUNCE_SEC 一次。
func save_run() -> void:
	if GameState.tutorial_mode:
		return
	if _save_pending:
		return
	_save_pending = true
	get_tree().create_timer(SAVE_DEBOUNCE_SEC).timeout.connect(_flush_pending_save)

# 应用被切后台/关闭时必须立即落盘，否则去抖会在进程被杀时丢进度。
func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_WM_CLOSE_REQUEST, NOTIFICATION_APPLICATION_FOCUS_OUT:
			_flush_pending_save()

func _flush_pending_save() -> void:
	if not _save_pending:
		return
	_save_pending = false
	_write_now()

func _write_now() -> void:
	if GameState.tutorial_mode:
		return
	var payload := {
		"round_index": GameState.round_index,
		"player_formation_hp": GameState.player_formation_hp,
		"enemy_formation_hp": GameState.enemy_formation_hp,
		"gold": GameState.gold,
		"board_slots": GameState.board_slots,
		"bench_slots": GameState.bench_slots,
		"mercenary_slots": GameState.mercenary_slots,
		"shop_offers": GameState.shop_offers,
		"shop_sold": GameState.shop_sold,
		"shop_refresh_uses_this_round": GameState.shop_refresh_uses_this_round,
		"owned_treasures": GameState.owned_treasures,
		"claimed_treasure_rounds": GameState.claimed_treasure_rounds,
		"pending_treasure": GameState.pending_treasure,
		"pve_completed": GameState.pve_completed,
		"boss_completed": GameState.boss_completed,
		"loss_streak": GameState.loss_streak,
		"golden_altar_uses": GameState.golden_altar_uses,
		"gamble_used": GameState.gamble_used,
		# 组队局字段（重连恢复用；team_mode 本身由 Main 显式控制，不入档）
		"team_hp": GameState.team_hp,
		"enemy_team_hp": GameState.enemy_team_hp,
	}
	_atomic_write(SAVE_PATH, JSON.stringify(payload))

func has_save() -> bool:
	return not _read_with_fallback(SAVE_PATH).is_empty()

func load_run() -> bool:
	var text := _read_with_fallback(SAVE_PATH)
	if text.is_empty():
		return false
	var parsed = JSON.parse_string(text)
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	GameState.round_index = int(parsed.get("round_index", 1))
	GameState.player_formation_hp = int(parsed.get("player_formation_hp", GameState.START_FORMATION_HP))
	GameState.enemy_formation_hp = int(parsed.get("enemy_formation_hp", GameState.START_FORMATION_HP))
	GameState.gold = int(parsed.get("gold", GameState.START_GOLD))
	GameState.board_slots = parsed.get("board_slots", [])
	GameState.bench_slots = parsed.get("bench_slots", [])
	GameState.mercenary_slots = parsed.get("mercenary_slots", [])
	GameState.shop_offers = parsed.get("shop_offers", [])
	GameState.shop_sold = parsed.get("shop_sold", [])
	GameState.shop_refresh_uses_this_round = int(parsed.get("shop_refresh_uses_this_round", 0))
	GameState.owned_treasures.assign(parsed.get("owned_treasures", []))
	GameState.claimed_treasure_rounds.clear()
	for round_value in parsed.get("claimed_treasure_rounds", []):
		GameState.claimed_treasure_rounds.append(int(round_value))
	GameState.pending_treasure = parsed.get("pending_treasure", {"active": false, "round": 0, "candidates": [], "refresh_index": 0})
	GameState.pve_completed = int(parsed.get("pve_completed", 0))
	GameState.boss_completed = int(parsed.get("boss_completed", 0))
	GameState.loss_streak = int(parsed.get("loss_streak", 0))
	GameState.golden_altar_uses = int(parsed.get("golden_altar_uses", 0))
	GameState.gamble_used = bool(parsed.get("gamble_used", false))
	GameState.team_hp = int(parsed.get("team_hp", GameState.team_hp))
	GameState.enemy_team_hp = int(parsed.get("enemy_team_hp", GameState.enemy_team_hp))
	_normalize_arrays()
	return true

func new_run() -> void:
	GameState.reset_run()
	save_run()

func _normalize_arrays() -> void:
	GameState.board_slots = _normalize_board_slots(GameState.board_slots)
	GameState.bench_slots.resize(GameState.BENCH_SLOTS)
	GameState.mercenary_slots.resize(GameState.MERCENARY_SLOTS)
	GameState.shop_offers.resize(GameState.SHOP_UNIT_SLOTS)
	GameState.shop_sold.resize(GameState.SHOP_UNIT_SLOTS)

func _normalize_board_slots(raw_slots: Array) -> Array:
	var normalized: Array = []
	normalized.resize(GameConstants.CELL_COUNT)
	normalized.fill(null)
	var overflow: Array = []
	for index in raw_slots.size():
		var cell = raw_slots[index]
		if cell == null:
			continue
		if index < GameConstants.CELL_COUNT and normalized[index] == null:
			normalized[index] = cell
		else:
			overflow.append(cell)
	for cell in overflow:
		var empty_index := normalized.find(null)
		if empty_index < 0:
			break
		normalized[empty_index] = cell
	return normalized
