﻿class_name TreasureService
extends RefCounted

const MAX_OWNED := 5
const REFRESH_COSTS := [50, 100, 200, 400]

static func refresh_cost(index: int, money_set_active: bool) -> int:
	if money_set_active:
		return 0
	var i := maxi(index, 0)
	# 50, 100, 200, 400, then keep doubling with no cap: 800, 1600, ...
	if i < REFRESH_COSTS.size():
		return int(REFRESH_COSTS[i])
	var cost := int(REFRESH_COSTS[REFRESH_COSTS.size() - 1])
	for _step in range(i - (REFRESH_COSTS.size() - 1)):
		cost *= 2
	return cost

static func can_draw() -> bool:
	return GameState.owned_treasures.size() < MAX_OWNED

# 用服务端权威持有列表覆盖本地（联机 resume / grant 用）。
# 不能直接 `GameState.owned_treasures = server_owned`：那会绕过 add_owned 里的
# PlayerProfile.mark_seen 与联动解锁，玩家重连一次就少解锁一批图鉴条目。
# 这里先算差集、逐个走 add_owned 拿到副作用，再按服务端列表裁掉本地多出来的项
# （服务端说没有就是没有——本地多出来的只可能来自过期存档或未走 intent 的路径）。
static func sync_owned_from_server(server_owned: Array) -> void:
	var authoritative: Array = []
	for value in server_owned:
		var tid := str(value)
		if not tid.is_empty() and not authoritative.has(tid):
			authoritative.append(tid)
	for tid in authoritative:
		if tid not in GameState.owned_treasures:
			add_owned(tid)
	# 裁掉服务端不认的条目。就地改数组而不是整体替换，避免别处持有的引用失效。
	for i in range(GameState.owned_treasures.size() - 1, -1, -1):
		if str(GameState.owned_treasures[i]) not in authoritative:
			GameState.owned_treasures.remove_at(i)

static func tag_counts() -> Dictionary:
	var counts := {"defense": 0, "control": 0, "attack": 0, "money": 0, "element": 0}
	var treasures: Array = DataRegistry.get_table("treasures").get("treasures", [])
	for tid in GameState.owned_treasures:
		for t in treasures:
			if str(t.get("id", "")) == tid:
				var cat := str(t.get("category", ""))
				if counts.has(cat):
					counts[cat] += 1
				break
	return counts

static func has_set(category: String) -> bool:
	return int(tag_counts().get(category, 0)) >= 4

static func has_linkage(link_id: String) -> bool:
	return has_linkage_in(GameState.owned_treasures, link_id)

# Owner-aware versions (3v3: each unit uses ITS owner's treasures, not GameState).
static func tag_counts_for(owned: Array) -> Dictionary:
	var counts := {"defense": 0, "control": 0, "attack": 0, "money": 0, "element": 0}
	var treasures: Array = DataRegistry.get_table("treasures").get("treasures", [])
	for tid in owned:
		for t in treasures:
			if str(t.get("id", "")) == str(tid):
				var cat := str(t.get("category", ""))
				if counts.has(cat):
					counts[cat] += 1
				break
	return counts

static func has_set_in(owned: Array, category: String) -> bool:
	return int(tag_counts_for(owned).get(category, 0)) >= 4

static func has_linkage_in(owned: Array, link_id: String) -> bool:
	var links: Array = DataRegistry.get_table("treasures").get("linkages", [])
	for link in links:
		var d: Dictionary = link
		if str(d.get("id", "")) != link_id:
			continue
		for required_id in d.get("requires", []):
			if not owned.has(str(required_id)):
				return false
		return true
	return false

static func unowned_ids() -> Array[String]:
	var out: Array[String] = []
	var treasures: Array = DataRegistry.get_table("treasures").get("treasures", [])
	for t in treasures:
		var tid := str(t.get("id", ""))
		if not tid.is_empty() and tid not in GameState.owned_treasures:
			out.append(tid)
	return out

static func roll_candidates(count: int = 3) -> Array[String]:
	var pool := unowned_ids()
	_shuffle_strings(pool)
	return pool.slice(0, mini(count, pool.size()))

static func random_unowned() -> String:
	var pool := unowned_ids()
	if pool.is_empty():
		return ""
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	return pool[rng.randi_range(0, pool.size() - 1)]

static func treasure_by_id(tid: String) -> Dictionary:
	var treasures: Array = DataRegistry.get_table("treasures").get("treasures", [])
	for t in treasures:
		if str(t.get("id", "")) == tid:
			return t
	return {}

static func add_owned(tid: String) -> void:
	if tid.is_empty() or tid in GameState.owned_treasures or GameState.owned_treasures.size() >= MAX_OWNED:
		return
	GameState.owned_treasures.append(tid)
	PlayerProfile.mark_seen(tid)
	# A linkage has no pickup of its own: it activates the moment its two treasures
	# are both owned, so that is when it enters the codex.
	_mark_active_linkages()

static func _mark_active_linkages() -> void:
	var unlocked: Array = []
	for raw in DataRegistry.get_table("treasures").get("linkages", []):
		var d := raw as Dictionary
		if d == null:
			continue
		var link_id := str(d.get("id", ""))
		if not link_id.is_empty() and has_linkage(link_id):
			unlocked.append(link_id)
	if not unlocked.is_empty():
		PlayerProfile.mark_seen_many(unlocked)

static func _shuffle_strings(items: Array[String]) -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in range(items.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp := items[i]
		items[i] = items[j]
		items[j] = tmp




