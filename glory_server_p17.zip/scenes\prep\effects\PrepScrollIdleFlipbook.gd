extends Control
class_name PrepScrollIdleFlipbook

const FRAME_SIZE := Vector2i(256, 128)
const FRAME_COLUMNS := 8
const FRAME_COUNT := 16
const FRAME_RATE := 16.0
const FLOAT_DISTANCE := 3.0
const SWAY_RADIANS := deg_to_rad(0.8)
const HALF_CYCLE_SECONDS := 1.55
const HALO_MARGIN := 22.0

var _target: Control
var _halo: TextureRect
var _shine_current: TextureRect
var _shine_next: TextureRect
var _atlas_current: AtlasTexture
var _atlas_next: AtlasTexture
var _animation_time := 0.0
var _frame_index := -1
var _float_tween: Tween
var _glow_tween: Tween
var _rest_position := Vector2.ZERO
var _rest_position_initialized := false
var _active := true


func setup(target: Control, atlas: Texture2D, halo_texture: Texture2D) -> void:
	_target = target
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	z_index = 2

	_atlas_current = AtlasTexture.new()
	_atlas_current.atlas = atlas
	_atlas_next = AtlasTexture.new()
	_atlas_next.atlas = atlas

	_halo = TextureRect.new()
	_halo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_halo.texture = halo_texture
	_halo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_halo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	_halo.anchor_right = 1.0
	_halo.anchor_bottom = 1.0
	_halo.offset_left = -HALO_MARGIN
	_halo.offset_top = -HALO_MARGIN
	_halo.offset_right = HALO_MARGIN
	_halo.offset_bottom = HALO_MARGIN
	_halo.modulate = Color(1.0, 0.86, 0.38, 0.62)
	add_child(_halo)

	_shine_current = _make_shine_layer(_atlas_current)
	_shine_next = _make_shine_layer(_atlas_next)
	_update_flipbook_layers(0, 0.0)

	call_deferred("_start_float")


func set_effect_active(value: bool) -> void:
	_active = value
	visible = value
	set_process(value)
	if value:
		_start_float()
	else:
		_stop_float()


func _process(delta: float) -> void:
	if not _active or _atlas_current == null or _atlas_next == null:
		return
	_animation_time = fmod(_animation_time + delta, float(FRAME_COUNT) / FRAME_RATE)
	var frame_value: float = _animation_time * FRAME_RATE
	var current_index := int(floor(frame_value)) % FRAME_COUNT
	var blend: float = frame_value - floor(frame_value)
	_update_flipbook_layers(current_index, blend)


func _make_shine_layer(texture: Texture2D) -> TextureRect:
	var layer := TextureRect.new()
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.texture = texture
	layer.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	layer.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(layer)
	return layer


func _update_flipbook_layers(current_index: int, blend: float) -> void:
	_frame_index = current_index
	_set_atlas_frame(_atlas_current, current_index)
	_set_atlas_frame(_atlas_next, (current_index + 1) % FRAME_COUNT)
	_shine_current.modulate = Color(1.0, 1.0, 1.0, 0.88 * (1.0 - blend))
	_shine_next.modulate = Color(1.0, 1.0, 1.0, 0.88 * blend)


func _set_atlas_frame(texture: AtlasTexture, index: int) -> void:
	var column := index % FRAME_COLUMNS
	var row := index / FRAME_COLUMNS
	texture.region = Rect2(
		Vector2(column * FRAME_SIZE.x, row * FRAME_SIZE.y),
		FRAME_SIZE
	)


func _start_float() -> void:
	if not _active or not is_instance_valid(_target):
		return
	_kill_tweens()
	if not _rest_position_initialized:
		_rest_position = _target.position
		_rest_position_initialized = true
	_target.pivot_offset = _target.size * 0.5
	_float_tween = create_tween().set_loops()
	_float_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_float_tween.tween_property(
		_target,
		"position",
		_rest_position + Vector2(0.0, -FLOAT_DISTANCE),
		HALF_CYCLE_SECONDS
	)
	_float_tween.parallel().tween_property(
		_target,
		"rotation",
		SWAY_RADIANS,
		HALF_CYCLE_SECONDS
	)
	_float_tween.tween_property(
		_target,
		"position",
		_rest_position + Vector2(0.0, FLOAT_DISTANCE * 0.35),
		HALF_CYCLE_SECONDS
	)
	_float_tween.parallel().tween_property(
		_target,
		"rotation",
		-SWAY_RADIANS,
		HALF_CYCLE_SECONDS
	)
	_glow_tween = create_tween().set_loops()
	_glow_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_glow_tween.tween_property(_halo, "modulate:a", 0.88, 0.95)
	_glow_tween.tween_property(_halo, "modulate:a", 0.48, 1.25)


func _stop_float() -> void:
	_kill_tweens()
	if is_instance_valid(_target) and _rest_position_initialized:
		_target.position = _rest_position
		_target.rotation = 0.0
	if is_instance_valid(_halo):
		_halo.modulate.a = 0.62


func _kill_tweens() -> void:
	if _float_tween != null and _float_tween.is_valid():
		_float_tween.kill()
	_float_tween = null
	if _glow_tween != null and _glow_tween.is_valid():
		_glow_tween.kill()
	_glow_tween = null


func _exit_tree() -> void:
	_stop_float()
