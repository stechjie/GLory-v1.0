extends VFXBlockRoot
class_name VFXStatusEffect3D
const SHADER_CACHE := preload("res://effects/vfx3d/core/VFXShaderCache.gd")

const CURVES := preload("res://effects/vfx3d/core/VFXCurveLibrary3D.gd")
const TEX_WISP := preload("res://assets/vfx_textures/smoke_wisp.png")
const TEX_DOT := preload("res://assets/vfx_textures/soft_dot.png")
const TEX_NOISE := preload("res://assets/vfx_textures/noise_tile.png")
const TEX_STUN := preload("res://assets/vfx/skills/distinct_v2/stun_star_mark_v2.png")
const TEX_SILENCE := preload("res://assets/vfx/status/status_silence_emblem.png")
const TEX_POISON := preload("res://assets/vfx/status/status_poison_emblem.png")

const STATUS_SHADER := """
shader_type spatial;
render_mode unshaded,cull_disabled,depth_draw_never,blend_mix;
uniform sampler2D mask_tex:filter_linear_mipmap,repeat_disable;
uniform sampler2D noise_tex:filter_linear_mipmap,repeat_enable;
uniform vec4 dark_color:source_color;
uniform vec4 main_color:source_color;
uniform vec4 core_color:source_color;
uniform float life=0.0;
uniform float opacity=1.0;
uniform float phase=0.0;
uniform float energy=2.5;
void vertex(){MODELVIEW_MATRIX=VIEW_MATRIX*mat4(INV_VIEW_MATRIX[0],INV_VIEW_MATRIX[1],INV_VIEW_MATRIX[2],MODEL_MATRIX[3]);}
void fragment(){
	vec2 p=UV-vec2(.5);float r=length(p)*2.0;float a=atan(p.y,p.x);
	float n=texture(noise_tex,UV*2.1+vec2(TIME*.09+phase,-TIME*.13)).r;
	float mask=texture(mask_tex,UV).a;
	float torn=mask*smoothstep(.16,-.08,r-1.0-(n-.5)*.18);
	float hot=pow(mask,2.6)*(.80+.20*sin(TIME*7.0+phase));
	float fade=smoothstep(0.0,.11,life)*(1.0-smoothstep(.78,1.0,life));
	vec3 col=mix(dark_color.rgb,main_color.rgb,clamp(mask*1.25,0.0,1.0));
	col=mix(col,core_color.rgb,hot*.72);
	ALBEDO=col;EMISSION=col*energy*(.25+hot*1.35);
	ALPHA=clamp(torn*(.55+hot*.35)*fade*opacity,0.0,.94);
}
"""

var _materials:Array[ShaderMaterial]=[]
var _target_node:Node3D
var _fallback_target:=Vector3.ZERO
var _status_offset:=Vector3.ZERO

func play_profile(profile:VFXProfile3D,context:Dictionary)->void:
	var target_value:Variant = context.get("target_node")
	var safe_target:Node3D = target_value if is_instance_valid(target_value) and target_value is Node3D else null
	play_status(context.get("target",Vector3.ZERO),str(profile.parameters.get("status_type","stun")),profile,safe_target)

func play_status(at:Vector3,status_type:String,profile:VFXProfile3D=null,target_node:Node3D=null)->void:
	begin();_target_node=target_node;_fallback_target=at
	var active:=profile if profile!=null else _fallback_profile(status_type)
	var status_slot:=int(active.parameters.get("status_slot",0))
	_status_offset=Vector3(float(status_slot)*active.size*.52,0.0,0.0)
	_apply_status_palette(active,status_type)
	_update_anchor()
	var d:=active.duration;var s:=active.size
	var icon_texture:Texture2D = null
	var icon_size:=Vector2.ZERO
	if status_type=="stun":
		icon_texture=TEX_STUN;icon_size=Vector2(s*.46,s*.46)
	elif status_type=="silence":
		icon_texture=TEX_SILENCE;icon_size=Vector2(s*1.05,s*1.05)
	elif status_type=="poison":
		icon_texture=TEX_POISON;icon_size=Vector2(s*1.10,s*1.10)
	if icon_texture != null:
		var crown:=_make_card("StatusReadableIcon",icon_texture,icon_size,active,0.3)
		crown.position.y=s*.84;crown.scale=Vector3.ONE*.16
		var tw:=track_tween(create_tween());tw.tween_property(crown,"scale",Vector3.ONE,d*.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		_tween_life(crown,d,0.0)
	for i in range(clampi(active.particle_count,6,12)):
		var mote:=_make_card("StatusMote_%d"%i,TEX_DOT,Vector2(s*.10,s*.16),active,float(i)*1.31)
		_animate_mote(mote,active,i)
	await get_tree().create_timer(d+.08).timeout
	finish()

func _process(_delta:float)->void:
	if not _finished:_update_anchor()

func _update_anchor()->void:
	if _target_node!=null and is_instance_valid(_target_node):
		global_position=_target_node.global_position+_status_offset
	else:position=_fallback_target+_status_offset

func _animate_orbit(node:MeshInstance3D,profile:VFXProfile3D,index:int)->void:
	var start:=float(index)/3.0*TAU;var radius:=profile.size*(.42+.09*float(index));var d:=profile.duration
	var tw:=track_tween(create_tween())
	tw.tween_method(func(t:float)->void:
		if not is_instance_valid(node):return
		var a:=start+t*TAU*(1.15+float(index)*.17)
		node.position.x=cos(a)*radius;node.position.y=profile.size*(.50+sin(a)*.10);node.position.z=.04+float(index)*.006
		node.rotation.z=a+PI*.5
		node.scale=Vector3.ONE*(.72+.20*sin(t*PI)),0.0,1.0,d).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_tween_life(node,d,0.0)

func _animate_mote(node:MeshInstance3D,profile:VFXProfile3D,index:int)->void:
	var a:=float(index)*2.399;var r:=profile.size*(.28+.16*float(index%3));var delay:=profile.duration*(.04+.045*float(index%4))
	node.position=Vector3(cos(a)*r,profile.size*(.42+.06*float(index%3)),.06)
	node.visible=false
	var tw:=track_tween(create_tween());tw.tween_interval(delay);tw.tween_callback(func():if is_instance_valid(node):node.visible=true)
	tw.set_parallel(true);tw.tween_property(node,"position:y",profile.size*(1.02+.08*float(index%2)),profile.duration*.54).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT);tw.tween_property(node,"position:x",node.position.x*.55,profile.duration*.54).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	_tween_life(node,profile.duration*.54,delay)

func _make_card(node_name:String,texture:Texture2D,size:Vector2,profile:VFXProfile3D,phase:float)->MeshInstance3D:
	var q:=QuadMesh.new();q.size=size
	var n:=MeshInstance3D.new();n.name=node_name;n.mesh=q;n.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var m:=ShaderMaterial.new();m.shader = SHADER_CACHE.get_shader(STATUS_SHADER)
	m.set_shader_parameter("mask_tex",texture);m.set_shader_parameter("noise_tex",TEX_NOISE);m.set_shader_parameter("dark_color",profile.dark_color);m.set_shader_parameter("main_color",profile.main_color);m.set_shader_parameter("core_color",profile.core_color);m.set_shader_parameter("phase",phase);m.set_shader_parameter("energy",profile.emission_energy);m.set_shader_parameter("opacity",vfx_alpha)
	n.material_override=m;add_child(n);_materials.append(m);return n

func _tween_life(node:MeshInstance3D,duration:float,delay:float)->void:
	var m:=node.material_override as ShaderMaterial
	var tw:=track_tween(create_tween())
	if delay>0.0:
		tw.tween_interval(delay)
	tw.tween_method(func(t:float):if is_instance_valid(m):m.set_shader_parameter("life",t),0.0,1.0,duration)

func _apply_status_palette(profile:VFXProfile3D,status_type:String)->void:
	match status_type:
		"poison":profile.dark_color=Color(.05,.10,.025);profile.main_color=Color(.36,.72,.08);profile.core_color=Color(.82,1.0,.28)
		"silence":profile.dark_color=Color(.07,.025,.12);profile.main_color=Color(.42,.16,.72);profile.core_color=Color(.84,.58,1.0)
		"fear":profile.dark_color=Color(.055,.008,.03);profile.main_color=Color(.46,.035,.12);profile.core_color=Color(1.0,.24,.38)
		"defense_down":profile.dark_color=Color(.12,.025,.008);profile.main_color=Color(.80,.20,.04);profile.core_color=Color(1.0,.72,.20)
		_:pass

func set_vfx_alpha(value:float)->void:
	super.set_vfx_alpha(value)
	for m in _materials:if is_instance_valid(m):m.set_shader_parameter("opacity",vfx_alpha)

func _fallback_profile(status_type:String)->VFXProfile3D:
	var p:=VFXProfile3D.new();p.dark_color=Color(.055,.07,.13);p.main_color=Color(.18,.58,.95);p.core_color=Color(.82,.96,1.0);p.size=.72;p.duration=1.8;p.particle_count=9;p.emission_energy=2.8;_apply_status_palette(p,status_type);return p
