extends Node

signal completed
signal skip_requested

const GOLD_TEXT := "∞"
const TUTORIAL_GOLD := 9999
const TUTORIAL_HP := 10

enum Step {
	BUY_3,
	PLACE_3,
	START_PVE_1,
	UPGRADE_2,
	START_PVE_2,
	TAKE_TREASURE_1,
	UPGRADE_3,
	UPGRADE_OTHERS,
	BOND_HINT,
	VIEW_TREASURE,
	START_BOSS,
	TAKE_TREASURE_2,
	HIRE_MERC,
	FILL_7,
	FORMATION_HP,
	START_PVP,
	DONE,
}

# 进度显示用的「实际到访顺序」，不是枚举顺序。FORMATION_HP 会被走两次
# （VIEW_TREASURE 之后讲一次、FILL_7 之后 PVP 前再讲一次），所以它在表里出现两回；
# 配合 _progress_index 只向前走，步数就不会倒退。增删步骤时这张表要同步改。
const STEP_SEQUENCE: Array = [
	Step.BUY_3,
	Step.PLACE_3,
	Step.START_PVE_1,
	Step.UPGRADE_2,
	Step.START_PVE_2,
	Step.TAKE_TREASURE_1,
	Step.UPGRADE_3,
	Step.UPGRADE_OTHERS,
	Step.BOND_HINT,
	Step.VIEW_TREASURE,
	Step.FORMATION_HP,
	Step.START_BOSS,
	Step.TAKE_TREASURE_2,
	Step.HIRE_MERC,
	Step.FILL_7,
	Step.FORMATION_HP,
	Step.START_PVP,
]

enum ArrowDir { DOWN, UP, LEFT }

# 放大2倍后的向下箭头（字号84）比原来高，往上多抬一些，箭尖仍指向目标顶部。
const ARROW_DOWN_Y_OFFSET := -100.0
# 向上箭头贴在目标底边下方的间隙。
const ARROW_UP_GAP := 6.0
# 箭头 Label（字号 84）的大致高度/宽度，用来把气泡排在箭尾之后、不跟箭头叠上。
const ARROW_HEIGHT := 104.0
const ARROW_WIDTH := 76.0
# 向左箭头跟目标右边缘的间隙。
const ARROW_LEFT_GAP := 8.0

# 气泡尺寸。气泡是浮在 overlay 上的自由控件，没有父容器约束它，
# 所以宽高必须显式钉死：autowrap 的 Label 在宽度未定时，最小高度会按
# 「每行一个词」算成巨值，把气泡撑到半屏、盖掉商店和按钮。
const BUBBLE_WIDTH := 400.0
const BUBBLE_MARGIN_X := 14.0
const BUBBLE_TEXT_WIDTH := BUBBLE_WIDTH - BUBBLE_MARGIN_X * 2.0
const BUBBLE_MIN_HEIGHT := 72.0
const BUBBLE_MAX_HEIGHT := 200.0

var active := false
var step: int = Step.BUY_3
var bought_units := 0
# 进度条指针，指向 STEP_SEQUENCE 的下标；只增不减。
var _progress_index := 0
# 教学 PVP 步的伪造对手棋盘（原先借用 NetworkService.opponent_board_snapshot，
# 1v1 联机删除后由教学模式自持，BattleSimulator 的教学 PVP 路径从这里读）。
var opponent_snapshot: Dictionary = {}
var _prep: Control
var _overlay: Control
var _arrow: Label
var _bubble: PanelContainer
var _text: Label
var _progress_label: Label
var _step_key_label: Label
var _progress_bar: ProgressBar
var _continue_btn: Button
var _hotspot: Button
var _skip_btn: Button
var _skip_confirm: ColorRect

const START_SHOP := ["human_militia", "human_archer", "human_merchant", "human_swordsman"]
const FILL_SHOP := ["human_swordsman", "human_mage", "human_cleric", "human_death_servant"]
# 升星步：商店铺满玩家要凑的同名棋子，让玩家自己买 + 刷新
const UPGRADE_2_SHOP := ["human_militia", "human_militia", "human_militia", "human_militia"]
const UPGRADE_OTHERS_SHOP := ["human_archer", "human_archer", "human_merchant", "human_merchant"]
const PVP_OPPONENT := ["human_militia", "human_archer", "human_merchant", "human_swordsman", "human_mage"]
const TREASURE_1 := ["def_iron_wall", "atk_blood_pact", "ctrl_shockwave"]
const TREASURE_2 := ["atk_fury_roster", "def_formation_heal", "money_discount"]

func start() -> void:
	active = true
	step = Step.BUY_3
	bought_units = 0
	_progress_index = 0
	GameState.reset_run()
	GameState.tutorial_mode = true
	GameState.player_formation_hp = TUTORIAL_HP
	GameState.enemy_formation_hp = TUTORIAL_HP
	GameState.gold = TUTORIAL_GOLD
	_apply_shop(START_SHOP)

func finish() -> void:
	active = false
	GameState.tutorial_mode = false
	opponent_snapshot = {}
	_detach()
	completed.emit()

func attach(prep: Control) -> void:
	if not active:
		return
	_prep = prep
	_ensure_overlay()
	sync()
	update_overlay()

func sync() -> void:
	if not active:
		return
	GameState.gold = TUTORIAL_GOLD
	# 按「实际拥有 3 个」推进，不按采购次数：自动合成下重复买同名会融合，
	# 买满 3 次也可能只剩 2 个棋子，那样 PLACE_3 的 3 个上阵条件永远达不到。
	if step == Step.BUY_3 and _owned_normal_count() >= 3:
		step = Step.PLACE_3
	if step == Step.PLACE_3 and GameState.normal_unit_count() >= 3:
		step = Step.START_PVE_1
	if step == Step.UPGRADE_2 and _unit_star("human_militia") >= 2:
		step = Step.START_PVE_2
	if step == Step.TAKE_TREASURE_1 and GameState.owned_treasures.size() >= 1:
		# 只送 1 个 2 星（送 2 个会和场上那个凑满 3 个、当场自动合成到 3 星，
		# UPGRADE_3 就被跳过了）。剩下 1 个 2 星让玩家自己买 2 个 1 星凑。
		_grant_units("human_militia", 1, 2)
		step = Step.UPGRADE_3
		_refresh_prep()
	if step == Step.UPGRADE_3 and _unit_star("human_militia") >= 3:
		# 弓手/商人升 2 星也让玩家自己在商店买，不再直接发材料。
		_apply_shop(UPGRADE_OTHERS_SHOP)
		step = Step.UPGRADE_OTHERS
		_refresh_prep()
	if step == Step.UPGRADE_OTHERS and _unit_star("human_archer") >= 2 and _unit_star("human_merchant") >= 2:
		step = Step.BOND_HINT
	if step == Step.TAKE_TREASURE_2 and GameState.owned_treasures.size() >= 2:
		step = Step.HIRE_MERC
	if step == Step.HIRE_MERC and _mercenary_count() >= 2:
		if _prep != null and _prep.has_method("_close_merc_picker"):
			_prep.call("_close_merc_picker")
		_apply_shop(FILL_SHOP)
		step = Step.FILL_7
	if step == Step.FILL_7 and GameState.normal_unit_count() >= 7:
		step = Step.FORMATION_HP
	update_overlay()

func can_start_battle() -> bool:
	return step in [Step.START_PVE_1, Step.START_PVE_2, Step.START_BOSS, Step.START_PVP]

func follow_arrow_hint() -> String:
	return _t("先完成箭头指示的操作。", "Follow the arrow first.")

func begin_battle() -> bool:
	if not can_start_battle():
		if _prep != null and _prep.has_method("show_message"):
			_prep.show_message(follow_arrow_hint())
		return false
	if step == Step.START_PVP:
		opponent_snapshot = _tutorial_opponent_snapshot()
	_detach()
	return true

func battle_kind() -> String:
	match step:
		Step.START_BOSS:
			return "boss"
		Step.START_PVP:
			return "pvp"
		_:
			return "pve"

func pve_enemy_count() -> int:
	return 4 if step == Step.START_PVE_2 else 3

func after_battle(result: Dictionary) -> void:
	match step:
		Step.START_PVE_1:
			# 升 2 星的民兵材料让玩家自己在商店买，不再直接发。
			_apply_shop(UPGRADE_2_SHOP)
			step = Step.UPGRADE_2
		Step.START_PVE_2:
			_start_treasure(TREASURE_1)
			step = Step.TAKE_TREASURE_1
		Step.START_BOSS:
			_start_treasure(TREASURE_2)
			step = Step.TAKE_TREASURE_2
		Step.START_PVP:
			result["kind"] = "pvp"
			result["player_wins"] = true
			result["enemy_alive"] = 0
			result["enemy_hp_current"] = 0
			GameState.enemy_formation_hp = 0
			step = Step.DONE
	GameState.gold = TUTORIAL_GOLD

func current_text() -> String:
	match step:
		Step.BUY_3:
			return _t("点击下方「商店」按钮打开商店，点击商店棋子，再点击采购按钮。买到的棋子会先进入待命区。已拥有：%d/3" % mini(_owned_normal_count(), 3), "Tap the Shop button at the bottom to open the shop, tap a unit, then tap Buy. Bought units go to standby first. Owned: %d/3" % mini(_owned_normal_count(), 3))
		Step.PLACE_3:
			return _t("从待命区把 3 个棋子拖到棋盘。棋盘上的棋子才会参战。", "Drag 3 units from standby onto the board. Only board units fight.")
		Step.START_PVE_1:
			return _t("已经上阵 3 个棋子，点击开始战斗，打 3 个小怪。", "You placed 3 units. Start battle to fight 3 monsters.")
		Step.UPGRADE_2:
			return _t("在商店买 1 个「民兵」（不够就点刷新）。凑够 2 个相同棋子会自动合成，民兵就升到 2 星。", "Buy 1 Militia from the shop (refresh if needed). Two matching units merge automatically, taking your Militia to 2-star.")
		Step.START_PVE_2:
			return _t("主力已经 2 星了。再开始战斗，这次打 4 个小怪。", "Your main unit is 2-star. Start battle again against 4 monsters.")
		Step.TAKE_TREASURE_1:
			return _t("选择一个宝藏。拿到的宝藏会显示在左下角。", "Choose a treasure. Owned treasures appear at the bottom-left.")
		Step.UPGRADE_3:
			return _t("已经送你 1 个 2 星民兵。再去商店买 2 个民兵（不够就刷新），它们会先合成 2 星，凑够 3 个 2 星就自动升到 3 星。", "You received one 2-star Militia. Buy 2 more Militia from the shop (refresh if needed) — they merge into a 2-star, and three 2-stars merge into a 3-star.")
		Step.UPGRADE_OTHERS:
			return _t("在商店买弓手和商人各 1 个（不够就刷新），会各自和场上的同名棋子自动合成到 2 星。", "Buy 1 Archer and 1 Merchant from the shop (refresh if needed). Each merges automatically with its matching board unit to reach 2-star.")
		Step.BOND_HINT:
			return _t("同族数量够了会激活羁绊。看看左侧的羁绊效果，点一下继续。", "Matching races activate bonds. Check the bond effects on the left, then tap to continue.")
		Step.VIEW_TREASURE:
			return _t("点击左下角的宝藏图标，看看已获得宝藏的效果。", "Tap the treasure icon at the bottom-left to see your treasure's effect.")
		Step.START_BOSS:
			return _t("阵容变强了，点击开始战斗挑战 Boss。", "Your team is stronger. Start battle to challenge the Boss.")
		Step.TAKE_TREASURE_2:
			return _t("Boss 打完后，再选择一个宝藏强化阵容。", "After the Boss, choose another treasure to strengthen your team.")
		Step.HIRE_MERC:
			return _t("打开佣兵面板，召唤 2 个佣兵。佣兵是额外战力，但不算羁绊。", "Open the mercenary panel and hire 2 mercenaries. They are extra power but do not count for bonds.")
		Step.FILL_7:
			return _t("PVP 前把普通棋子放满 7 个。", "Before PVP, fill the board with 7 normal units.")
		Step.FORMATION_HP:
			return _t("看上方血条——教学局法阵 HP 是 10，把敌方法阵打到归零就胜利。点一下继续。", "See the HP bar above — tutorial formation HP is 10. Bring the enemy's to 0 to win. Tap to continue.")
		Step.START_PVP:
			return _t("点击开始战斗进入 PVP，赢下最后一战。", "Start battle for PVP and win the final fight.")
		_:
			return _t("教学胜利。", "Tutorial victory.")

func update_overlay() -> void:
	if not active or _prep == null or _overlay == null:
		return
	var target := _target_control()
	var rect := Rect2(Vector2(540, 290), Vector2(200, 80))
	if target is Control and target.is_inside_tree():
		rect = (target as Control).get_global_rect()
	var dir := _arrow_dir()
	_apply_arrow(rect, dir)
	# 先填内容再定位：气泡高度随文案和进度条变化，定位要用刷新后的尺寸。
	_text.text = current_text()
	_update_progress()
	_fit_bubble()
	_bubble.position = _bubble_position(rect, dir)
	_continue_btn.visible = false
	_bubble.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_position_hotspot(rect)

func total_steps() -> int:
	return STEP_SEQUENCE.size()

# 步骤序号从 1 开始。指针只向前找下一个匹配项，所以同一个 Step 被重复走到时
# 拿到的是后一个位置，不会出现「15 跳回 11」。
func _sync_progress_index() -> void:
	if step == Step.DONE:
		_progress_index = STEP_SEQUENCE.size() - 1
		return
	if _progress_index < STEP_SEQUENCE.size() and STEP_SEQUENCE[_progress_index] == step:
		return
	for i in range(_progress_index + 1, STEP_SEQUENCE.size()):
		if STEP_SEQUENCE[i] == step:
			_progress_index = i
			return
	# 前面找不到（理论上只有回退流程才会），退回全表首次匹配。
	var first := STEP_SEQUENCE.find(step)
	if first >= 0:
		_progress_index = first

func step_number() -> int:
	return _progress_index + 1

# 步骤代号（枚举名，如 UPGRADE_2）。
func step_key() -> String:
	var keys: Array = Step.keys()
	if step >= 0 and step < keys.size():
		return str(keys[step])
	return "?"

func progress_text() -> String:
	var total := total_steps()
	if step == Step.DONE:
		return _t("教学完成 %d/%d" % [total, total], "Complete %d/%d" % [total, total])
	return _t("步骤 %d/%d" % [step_number(), total], "Step %d/%d" % [step_number(), total])

func _update_progress() -> void:
	if _progress_label == null or not is_instance_valid(_progress_label):
		return
	_sync_progress_index()
	_progress_label.text = progress_text()
	_step_key_label.text = step_key()
	_progress_bar.value = float(step_number())

# 箭头朝向：目标在屏幕上方（开始战斗按钮、法阵水晶）要从下往上指，
# 左侧面板（羁绊、已获宝藏）从右往左指，其余目标（商店、棋盘、待命区）从上往下指。
func _arrow_dir() -> int:
	match step:
		Step.BOND_HINT, Step.VIEW_TREASURE:
			return ArrowDir.LEFT
		# HIRE_MERC 的两个目标（右上角佣兵按钮、面板里的佣兵手牌）都在上半屏，
		# 箭头压在它们下面朝上指，气泡再排到箭尾下方，才不会盖住要点的东西。
		Step.START_PVE_1, Step.START_PVE_2, Step.START_BOSS, Step.START_PVP, Step.FORMATION_HP, Step.HIRE_MERC:
			return ArrowDir.UP
	return ArrowDir.DOWN

func _apply_arrow(rect: Rect2, dir: int) -> void:
	match dir:
		ArrowDir.LEFT:
			_arrow.text = "◀"
			_arrow.position = Vector2(rect.position.x + rect.size.x + ARROW_LEFT_GAP, rect.position.y + rect.size.y * 0.5 - 48.0)
		ArrowDir.UP:
			# 箭尖贴目标底边，箭身朝下延伸，气泡再排在箭尾下方。
			_arrow.text = "▲"
			_arrow.position = Vector2(rect.position.x + rect.size.x * 0.5 - 36.0, rect.position.y + rect.size.y + ARROW_UP_GAP)
		_:
			_arrow.text = "▼"
			_arrow.position = rect.position + Vector2(rect.size.x * 0.5 - 36.0, ARROW_DOWN_Y_OFFSET)

func _position_hotspot(rect: Rect2) -> void:
	# 点击推进的步用透明热区拦截点击（不再依赖会被子节点吞掉的 gui_input）。
	if _hotspot == null:
		return
	match step:
		Step.BOND_HINT, Step.VIEW_TREASURE:
			_hotspot.visible = true
			var pad := 10.0
			_hotspot.position = rect.position - Vector2(pad, pad)
			_hotspot.size = rect.size + Vector2(pad, pad) * 2.0
		Step.FORMATION_HP:
			# 讲解 HP 后，点屏幕任意处一次即可继续。
			_hotspot.visible = true
			_hotspot.position = Vector2.ZERO
			_hotspot.size = _overlay.size
		_:
			_hotspot.visible = false

func _on_skip_pressed() -> void:
	if not active:
		return
	_show_skip_confirm()

func _show_skip_confirm() -> void:
	if _overlay == null or not is_instance_valid(_overlay):
		return
	if _skip_confirm != null and is_instance_valid(_skip_confirm):
		return
	# 半透明遮罩 + 居中确认框（防手滑）。
	_skip_confirm = ColorRect.new()
	_skip_confirm.name = "TutorialSkipConfirm"
	_skip_confirm.color = Color(0.0, 0.0, 0.0, 0.6)
	_skip_confirm.mouse_filter = Control.MOUSE_FILTER_STOP
	_skip_confirm.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.add_child(_skip_confirm)

	var panel := PanelContainer.new()
	panel.anchor_left = 0.5
	panel.anchor_top = 0.5
	panel.anchor_right = 0.5
	panel.anchor_bottom = 0.5
	panel.custom_minimum_size = Vector2(420, 0)
	panel.offset_left = -210
	panel.offset_top = -90
	panel.offset_right = 210
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.05, 0.06, 0.08, 0.96)
	panel_style.border_color = Color(1.0, 0.86, 0.28, 0.95)
	panel_style.set_border_width_all(2)
	panel_style.set_corner_radius_all(10)
	panel_style.set_content_margin_all(18)
	panel.add_theme_stylebox_override("panel", panel_style)
	_skip_confirm.add_child(panel)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	panel.add_child(box)
	var msg := Label.new()
	msg.text = _t("确定跳过整段新手教学吗？将直接回到主菜单。", "Skip the whole tutorial and return to the main menu?")
	msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg.add_theme_font_size_override("font_size", 18)
	msg.add_theme_color_override("font_color", Color(0.98, 0.96, 0.86))
	box.add_child(msg)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 20)
	box.add_child(row)
	var cancel_btn := Button.new()
	cancel_btn.text = _t("取消", "Cancel")
	cancel_btn.focus_mode = Control.FOCUS_NONE
	cancel_btn.custom_minimum_size = Vector2(140, 40)
	cancel_btn.pressed.connect(_close_skip_confirm)
	row.add_child(cancel_btn)
	var confirm_btn := Button.new()
	confirm_btn.text = _t("跳过", "Skip")
	confirm_btn.focus_mode = Control.FOCUS_NONE
	confirm_btn.custom_minimum_size = Vector2(140, 40)
	confirm_btn.pressed.connect(_on_skip_confirmed)
	row.add_child(confirm_btn)

func _close_skip_confirm() -> void:
	if _skip_confirm != null and is_instance_valid(_skip_confirm):
		_skip_confirm.queue_free()
	_skip_confirm = null

func _on_skip_confirmed() -> void:
	_close_skip_confirm()
	if not active:
		return
	skip_requested.emit()

func _on_hotspot_pressed() -> void:
	match step:
		Step.BOND_HINT:
			step = Step.VIEW_TREASURE
		Step.VIEW_TREASURE:
			step = Step.FORMATION_HP
		Step.FORMATION_HP:
			step = Step.START_PVP if GameState.normal_unit_count() >= 7 and _mercenary_count() >= 2 else Step.START_BOSS
		_:
			return
	update_overlay()

func record_shop_purchase() -> void:
	if active and step == Step.BUY_3:
		bought_units += 1
		sync()

# 按当前文案把气泡收到内容高度，并限死在 BUBBLE_MAX_HEIGHT 内，
# 避免任何一步的长文案再次把气泡撑成半屏。
func _fit_bubble() -> void:
	if _bubble == null or not is_instance_valid(_bubble):
		return
	_bubble.reset_size()
	_bubble.size = Vector2(BUBBLE_WIDTH, clampf(_bubble.size.y, BUBBLE_MIN_HEIGHT, BUBBLE_MAX_HEIGHT))

func _bubble_position(target_rect: Rect2, dir: int) -> Vector2:
	var margin := 18.0
	# 宽度已钉死，高度取 _fit_bubble() 收完的实际值。
	var bubble_size := Vector2(BUBBLE_WIDTH, maxf(_bubble.size.y, BUBBLE_MIN_HEIGHT))
	var max_x := maxf(margin, _overlay.size.x - bubble_size.x - margin)
	var max_y := maxf(margin, _overlay.size.y - bubble_size.y - margin)
	var center_x := clampf(target_rect.position.x + target_rect.size.x * 0.5 - bubble_size.x * 0.5, margin, max_x)
	match dir:
		ArrowDir.LEFT:
			# 箭头 ◀ 指向左侧面板/宝藏图标，气泡整体让到箭头右边（原来的 46 比箭头还窄，会叠上）。
			var bx := target_rect.position.x + target_rect.size.x + ARROW_LEFT_GAP + ARROW_WIDTH + 12.0
			var by := target_rect.position.y + target_rect.size.y * 0.5 - bubble_size.y * 0.5
			return Vector2(clampf(bx, margin, max_x), clampf(by, margin, max_y))
		ArrowDir.UP:
			# 目标在屏幕顶部：箭头在气泡上方指向目标，气泡排在箭尾下面。
			var uy := target_rect.position.y + target_rect.size.y + ARROW_UP_GAP + ARROW_HEIGHT
			return Vector2(center_x, clampf(uy, margin, max_y))
	# 向下箭头的步：气泡放在箭头「上方」，整体不压住箭头和目标（修复升星箭头被黑字挡）。
	var arrow_top := target_rect.position.y + ARROW_DOWN_Y_OFFSET - 8.0
	var y := arrow_top - bubble_size.y
	if y < margin:
		# 上方放不下就落到目标下方，仍然不与箭头重叠。
		y = target_rect.position.y + target_rect.size.y + 18.0
	return Vector2(center_x, clampf(y, margin, max_y))

func _target_control() -> Control:
	if _prep == null:
		return null
	match step:
		Step.BUY_3:
			# 商店还关着：先指底部的卷轴按钮，玩家点开后才轮到卡片/采购键。
			var closed_shop := _shop_entry_control()
			if closed_shop != null:
				return closed_shop
			var selected := int(_prep_shop_field("selected"))
			if _shop_index_available(selected):
				return _prep_shop_field("buy_button") as Control
			return _first_available_shop_control()
		Step.PLACE_3:
			return _first_empty_board_control_middle() if _placing_from_bench() else _first_occupied_bench_control()
		Step.UPGRADE_2, Step.UPGRADE_3, Step.UPGRADE_OTHERS:
			# 自动合成接管升星后玩家不用再拖材料，三步都只需要在商店买够同名棋子，
			# 箭头一路指商店（关着就先指卷轴）。
			return _upgrade_shop_control()
		Step.START_PVE_1, Step.START_PVE_2, Step.START_BOSS, Step.START_PVP:
			return _prep.get("_start_battle_button") as Control
		Step.FORMATION_HP:
			# _enemy_formation_bar 早已被置 null（红条删了只留数字），指水晶本体。
			return _prep.get("_enemy_formation_art") as Control
		Step.TAKE_TREASURE_1, Step.TAKE_TREASURE_2:
			var row := _treasure_field("_treasure_choice_row") as Control
			return row.get_child(0) as Control if row != null and row.get_child_count() > 0 else row
		Step.HIRE_MERC:
			if not bool(_prep.get("_merc_picker_open")):
				return _prep.get("_merc_button") as Control
			var grid := _prep.get("_merc_overlay_grid") as Control
			if grid != null and grid.get_child_count() > 0:
				return grid.get_child(0) as Control
			return _prep.get("_merc_button") as Control
		Step.FILL_7:
			if _owned_normal_count() > GameState.normal_unit_count():
				return _first_empty_board_control() if _placing_from_bench() else _first_occupied_bench_control()
			var closed_shop := _shop_entry_control()
			if closed_shop != null:
				return closed_shop
			var selected := int(_prep_shop_field("selected"))
			if _shop_index_available(selected):
				return _prep_shop_field("buy_button") as Control
			return _first_available_shop_control()
		Step.BOND_HINT:
			return _first_bond_row_control()
		Step.VIEW_TREASURE:
			return _treasure_logo_control()
	return null

# 第一条羁绊行（_add_current_synergy_widgets 往 _left_panel 塞的 HBoxContainer，
# 标题之后的第一个）。指整个 _left_panel 会落到面板中部、离羁绊图标很远。
func _first_bond_row_control() -> Control:
	# 左面板已随 D2 搬进 SynergyPanel 节点（scenes/prep/panels/SynergyPanel.gd）。
	var synergy: Variant = _prep.get("_synergy")
	var panel: Control = null if synergy == null else synergy.get("_left_panel") as Control
	if panel == null:
		return null
	for child in panel.get_children():
		if child is HBoxContainer and (child as Control).visible:
			return child as Control
	return panel

func _treasure_logo_control() -> Control:
	var box := _treasure_field("_owned_treasure_box") as Control
	if box != null and box.get_child_count() > 0 and box.get_child(0) is Control:
		return box.get_child(0) as Control
	return box

# 商店关着时返回底部卷轴按钮（先让玩家开店），已经开着返回 null 交给后续分支。
# 备战界面的商店/棋盘成员在 D2 里收进了 PrepShared 的 ShopPanel / BoardPanel 内部类，
# 不能再用 _prep.get("_shop_open_button") 这种旧名字 —— Object.get() 取不到就返回 null，
# 而 null 会一路传下去（bool(null) 直接报 "Nonexistent bool constructor"，实测踩到过）。
# 这两个辅助函数统一走「先取簇、再取字段」。
func _prep_shop_field(name: String) -> Variant:
	if _prep == null:
		return null
	var shop: Variant = _prep.get("_shop")
	return null if shop == null else shop.get(name)

func _prep_board_field(name: String) -> Variant:
	if _prep == null:
		return null
	var board: Variant = _prep.get("_board_hud")
	return null if board == null else board.get(name)

func _shop_entry_control() -> Control:
	if _prep == null or bool(_prep_shop_field("picker_open")):
		return null
	return _prep_shop_field("open_button") as Control

func _upgrade_shop_control() -> Control:
	var closed_shop := _shop_entry_control()
	if closed_shop != null:
		return closed_shop
	var selected := int(_prep_shop_field("selected"))
	if _shop_index_available(selected):
		return _prep_shop_field("buy_button") as Control
	return _first_available_shop_control()

# Total copies of the target unit at the target star across board + standby.
# Compared against GameState.copies_to_upgrade() to decide whether the upgrade
# arrow keeps pointing at the shop (not enough) or moves to standby (enough).
func _upgrade_total_copies() -> int:
	var id := _upgrade_id()
	var star := _upgrade_star()
	var count := 0
	for cell in GameState.board_slots + GameState.bench_slots:
		if _cell_matches_upgrade(cell, id, star):
			count += 1
	return count

func _first_empty_board_control_middle() -> Control:
	# 引导摆放到中间排：优先第 2 排（中间偏前），再第 1 排，最后任意空位。
	var buttons := _prep_board_field("buttons") as Array
	for pref_row in [2, 1]:
		for col in GameConstants.BOARD_COLUMNS:
			var i: int = int(pref_row) * GameConstants.BOARD_COLUMNS + col
			if i >= 0 and i < GameState.board_slots.size() and GameState.board_slots[i] == null:
				var item = buttons[i]
				if item is Control and (item as Control).visible:
					return item as Control
	return _first_empty_board_control()

func _ensure_overlay() -> void:
	if _overlay != null and is_instance_valid(_overlay):
		return
	_overlay = Control.new()
	_overlay.name = "TutorialOverlay"
	_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_overlay.z_index = 500
	_prep.add_child(_overlay)

	_arrow = Label.new()
	_arrow.text = "▼"
	_arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_arrow.add_theme_font_size_override("font_size", 84)
	_arrow.add_theme_color_override("font_color", Color(0.95, 0.13, 0.10))
	_arrow.add_theme_color_override("font_outline_color", Color(0.12, 0.0, 0.0))
	_arrow.add_theme_constant_override("outline_size", 8)
	_overlay.add_child(_arrow)

	_bubble = PanelContainer.new()
	_bubble.mouse_filter = Control.MOUSE_FILTER_STOP
	# 只定宽不定高，高度由 _fit_bubble() 按内容算完再钉死。
	_bubble.custom_minimum_size = Vector2(BUBBLE_WIDTH, 0)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.04, 0.05, 0.06, 0.88)
	style.border_color = Color(1.0, 0.86, 0.28, 0.95)
	style.set_border_width_all(2)
	style.set_corner_radius_all(8)
	_bubble.add_theme_stylebox_override("panel", style)
	_overlay.add_child(_bubble)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 14)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_right", 14)
	margin.add_theme_constant_override("margin_bottom", 10)
	_bubble.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)

	# 进度指示：左边「步骤 n/16」，右边步骤代号（如 UPGRADE_2）。
	# 代号是枚举名，改流程时按代号沟通，不受插入/删除步骤导致的编号漂移影响。
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	box.add_child(header)
	_progress_label = Label.new()
	_progress_label.add_theme_font_size_override("font_size", 14)
	_progress_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.28))
	header.add_child(_progress_label)
	_step_key_label = Label.new()
	_step_key_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_step_key_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_step_key_label.add_theme_font_size_override("font_size", 12)
	_step_key_label.add_theme_color_override("font_color", Color(0.60, 0.65, 0.72))
	header.add_child(_step_key_label)

	_progress_bar = ProgressBar.new()
	_progress_bar.custom_minimum_size = Vector2(0, 6)
	_progress_bar.min_value = 0.0
	_progress_bar.max_value = float(total_steps())
	_progress_bar.show_percentage = false
	var bar_bg := StyleBoxFlat.new()
	bar_bg.bg_color = Color(0.16, 0.17, 0.20, 0.9)
	bar_bg.set_corner_radius_all(3)
	var bar_fill := StyleBoxFlat.new()
	bar_fill.bg_color = Color(1.0, 0.86, 0.28, 0.95)
	bar_fill.set_corner_radius_all(3)
	_progress_bar.add_theme_stylebox_override("background", bar_bg)
	_progress_bar.add_theme_stylebox_override("fill", bar_fill)
	box.add_child(_progress_bar)

	_text = Label.new()
	_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	# 定宽后 autowrap 才能算出正确的最小高度（否则气泡会被撑爆）。
	_text.custom_minimum_size = Vector2(BUBBLE_TEXT_WIDTH, 0)
	_text.add_theme_font_size_override("font_size", 18)
	_text.add_theme_color_override("font_color", Color(0.98, 0.96, 0.86))
	box.add_child(_text)
	_continue_btn = Button.new()
	_continue_btn.text = _t("继续", "Continue")
	_continue_btn.custom_minimum_size = Vector2(120, 34)
	_continue_btn.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	_continue_btn.visible = false
	_continue_btn.pressed.connect(_on_continue_pressed)
	box.add_child(_continue_btn)

	# 透明点击热区：覆盖在目标上，点一下推进（BOND_HINT / VIEW_TREASURE / FORMATION_HP）。
	_hotspot = Button.new()
	_hotspot.name = "TutorialHotspot"
	_hotspot.flat = true
	_hotspot.focus_mode = Control.FOCUS_NONE
	_hotspot.mouse_filter = Control.MOUSE_FILTER_STOP
	_hotspot.modulate = Color(1, 1, 1, 0)   # 不可见但可点击
	_hotspot.visible = false
	_hotspot.pressed.connect(_on_hotspot_pressed)
	_overlay.add_child(_hotspot)

	# 「跳过教学」按钮：固定在左上角，任何步都能一键跳过整段教学。
	_skip_btn = Button.new()
	_skip_btn.name = "TutorialSkipButton"
	_skip_btn.text = _t("跳过教学", "Skip Tutorial")
	_skip_btn.focus_mode = Control.FOCUS_NONE
	_skip_btn.mouse_filter = Control.MOUSE_FILTER_STOP
	_skip_btn.anchor_left = 0.0
	_skip_btn.anchor_top = 0.0
	_skip_btn.anchor_right = 0.0
	_skip_btn.anchor_bottom = 0.0
	_skip_btn.position = Vector2(16, 44)
	_skip_btn.custom_minimum_size = Vector2(112, 34)
	_skip_btn.add_theme_font_size_override("font_size", 15)
	_skip_btn.add_theme_color_override("font_color", Color(0.98, 0.96, 0.86))
	var skip_style := StyleBoxFlat.new()
	skip_style.bg_color = Color(0.04, 0.05, 0.06, 0.88)
	skip_style.border_color = Color(1.0, 0.86, 0.28, 0.95)
	skip_style.set_border_width_all(2)
	skip_style.set_corner_radius_all(8)
	skip_style.set_content_margin_all(6)
	_skip_btn.add_theme_stylebox_override("normal", skip_style)
	_skip_btn.add_theme_stylebox_override("hover", skip_style)
	_skip_btn.add_theme_stylebox_override("pressed", skip_style)
	_skip_btn.add_theme_stylebox_override("focus", skip_style)
	_skip_btn.pressed.connect(_on_skip_pressed)
	_overlay.add_child(_skip_btn)

	var tween := _arrow.create_tween()
	tween.set_loops()
	tween.tween_property(_arrow, "modulate:a", 0.35, 0.45)
	tween.tween_property(_arrow, "modulate:a", 1.0, 0.45)

func _detach() -> void:
	if _overlay != null and is_instance_valid(_overlay):
		_overlay.queue_free()
	_overlay = null
	_prep = null

func tutorial_shop_ids() -> Array:
	# 刷新商店时按当前步铺货：升星步铺满要凑的同名棋子。
	match step:
		Step.UPGRADE_2, Step.UPGRADE_3:
			return UPGRADE_2_SHOP
		Step.UPGRADE_OTHERS:
			return UPGRADE_OTHERS_SHOP
		_:
			return FILL_SHOP if step >= Step.HIRE_MERC else START_SHOP

func _apply_shop(ids: Array) -> void:
	var offers: Array = []
	for id in ids:
		var def := _unit_def(str(id))
		if not def.is_empty():
			offers.append(def)
	GameState.shop_offers.resize(GameState.SHOP_UNIT_SLOTS)
	GameState.shop_sold.resize(GameState.SHOP_UNIT_SLOTS)
	for i in GameState.SHOP_UNIT_SLOTS:
		GameState.shop_offers[i] = offers[i % offers.size()].duplicate(true) if not offers.is_empty() else {}
		GameState.shop_sold[i] = false

func _grant_units(id: String, count: int, star: int = 1) -> void:
	var def := _unit_def(id)
	if def.is_empty():
		return
	for n in count:
		var index := GameState.bench_slots.find(null)
		if index < 0:
			return
		GameState.bench_slots[index] = {"id": id, "star": star, "def": def.duplicate(true)}

func _on_continue_pressed() -> void:
	if step == Step.BOND_HINT:
		step = Step.START_BOSS
	elif step == Step.FORMATION_HP:
		step = Step.START_PVP
	update_overlay()

func _refresh_prep() -> void:
	if _prep != null and _prep.has_method("_refresh_all"):
		_prep.call_deferred("_refresh_all")

func _start_treasure(ids: Array) -> void:
	GameState.pending_treasure = {"active": true, "round": GameState.round_index, "candidates": ids.duplicate(), "refresh_index": 0}

func _tutorial_opponent_snapshot() -> Dictionary:
	var board := []
	board.resize(GameConstants.CELL_COUNT)
	board.fill(null)
	var slots := [1, 2, 5, 6, 9]
	for i in mini(PVP_OPPONENT.size(), slots.size()):
		var id := str(PVP_OPPONENT[i])
		var def := _unit_def(id)
		if not def.is_empty():
			board[int(slots[i])] = {"id": id, "star": 1, "def": def}
	return {
		"version": NetProtocol.SNAPSHOT_VERSION,
		"round": GameState.round_index,
		"board": NetProtocol.sanitize_board(board),
		"mercenaries": [],
		"treasures": [],
		"syn": {},
	}

func _unit_def(id: String) -> Dictionary:
	var units: Array = DataRegistry.get_table("race_units").get("units", [])
	for unit in units:
		if str((unit as Dictionary).get("id", "")) == id:
			return (unit as Dictionary).duplicate(true)
	return {}

func _owned_normal_count() -> int:
	var count := 0
	for cell in GameState.board_slots + GameState.bench_slots:
		if typeof(cell) == TYPE_DICTIONARY:
			count += 1
	return count

func _unit_star(id: String) -> int:
	var best := 0
	for cell in GameState.board_slots + GameState.bench_slots:
		if typeof(cell) == TYPE_DICTIONARY and str((cell as Dictionary).get("id", "")) == id:
			best = maxi(best, int((cell as Dictionary).get("star", 1)))
	return best

func _mercenary_count() -> int:
	var count := 0
	for cell in GameState.mercenary_slots:
		if cell != null:
			count += 1
	return count

func _first_live_control(items: Array) -> Control:
	for item in items:
		if item is Control and (item as Control).visible:
			return item as Control
	return null

func _first_occupied_bench_control() -> Control:
	var buttons := _prep_board_field("bench_buttons") as Array
	for i in buttons.size():
		if i < GameState.bench_slots.size() and GameState.bench_slots[i] != null:
			var item = buttons[i]
			if item is Control and (item as Control).visible:
				return item as Control
	return null

func _first_empty_board_control() -> Control:
	var buttons := _prep_board_field("buttons") as Array
	for i in buttons.size():
		if i < GameState.board_slots.size() and GameState.board_slots[i] == null:
			var item = buttons[i]
			if item is Control and (item as Control).visible:
				return item as Control
	return null

func _placing_from_bench() -> bool:
	if _prep == null:
		return false
	if int(_board_hud_field("_selected_bench")) >= 0:
		return true
	var payload = _prep.get("_active_drag_payload")
	return typeof(payload) == TYPE_DICTIONARY and str((payload as Dictionary).get("kind", "")) == "bench"

func _upgrade_material_control() -> Control:
	var id := _upgrade_id()
	var star := _upgrade_star()
	var buttons := _prep_board_field("bench_buttons") as Array
	for i in buttons.size():
		if i < GameState.bench_slots.size() and _cell_matches_upgrade(GameState.bench_slots[i], id, star):
			var item = buttons[i]
			if item is Control and (item as Control).visible:
				return item as Control
	return _first_occupied_bench_control()

func _upgrade_target_control() -> Control:
	var id := _upgrade_id()
	var star := _upgrade_star()
	var material_index := _held_upgrade_bench_index()
	var board_buttons := _prep_board_field("buttons") as Array
	for i in board_buttons.size():
		if i < GameState.board_slots.size() and _cell_matches_upgrade(GameState.board_slots[i], id, star):
			var item = board_buttons[i]
			if item is Control and (item as Control).visible:
				return item as Control
	var bench_buttons := _prep_board_field("bench_buttons") as Array
	for i in bench_buttons.size():
		if i == material_index:
			continue
		if i < GameState.bench_slots.size() and _cell_matches_upgrade(GameState.bench_slots[i], id, star):
			var item = bench_buttons[i]
			if item is Control and (item as Control).visible:
				return item as Control
	return _upgrade_material_control()

func _holding_upgrade_piece() -> bool:
	return _held_upgrade_bench_index() >= 0

func _held_upgrade_bench_index() -> int:
	var id := _upgrade_id()
	var star := _upgrade_star()
	var selected := int(_board_hud_field("_selected_bench"))
	if selected >= 0 and selected < GameState.bench_slots.size() and _cell_matches_upgrade(GameState.bench_slots[selected], id, star):
		return selected
	var payload = _prep.get("_active_drag_payload")
	if typeof(payload) == TYPE_DICTIONARY and str((payload as Dictionary).get("kind", "")) == "bench":
		var index := int((payload as Dictionary).get("index", -1))
		if index >= 0 and index < GameState.bench_slots.size() and _cell_matches_upgrade(GameState.bench_slots[index], id, star):
			return index
	return -1

func _upgrade_id() -> String:
	if step == Step.UPGRADE_OTHERS:
		return "human_archer" if _unit_star("human_archer") < 2 else "human_merchant"
	return "human_militia"

func _upgrade_star() -> int:
	return 2 if step == Step.UPGRADE_3 else 1

func _cell_matches_upgrade(cell: Variant, id: String, star: int) -> bool:
	return typeof(cell) == TYPE_DICTIONARY and str((cell as Dictionary).get("id", "")) == id and int((cell as Dictionary).get("star", 1)) == star

func _first_available_shop_control() -> Control:
	var buttons := _prep_shop_field("buttons") as Array
	if buttons == null:
		return null
	for i in buttons.size():
		if _shop_index_available(i):
			var item = buttons[i]
			if item is Control and (item as Control).visible:
				return item as Control
	return null

func _shop_index_available(index: int) -> bool:
	if index < 0 or index >= GameState.shop_offers.size() or index >= GameState.shop_sold.size():
		return false
	if bool(GameState.shop_sold[index]):
		return false
	var offer = GameState.shop_offers[index]
	return typeof(offer) == TYPE_DICTIONARY and not (offer as Dictionary).is_empty()

func _t(zh: String, en: String) -> String:
	return en if LocaleManager.get_locale() == "en" else zh


# 宝物面板的控件已随 D2 搬进 TreasureChoicePanel 节点。
# 和 _prep_shop_field 同样的形状：面板取不到就返回 null，不让空指针往下走。
func _treasure_field(name: String) -> Variant:
	if _prep == null:
		return null
	var panel: Variant = _prep.get("_treasure")
	return null if panel == null else panel.get(name)


# 棋盘选中态已随 D2 搬进 BoardHud 节点。形状同 _prep_shop_field / _treasure_field。
func _board_hud_field(name: String) -> Variant:
	if _prep == null:
		return null
	var panel: Variant = _prep.get("_board_hud")
	return null if panel == null else panel.get(name)
